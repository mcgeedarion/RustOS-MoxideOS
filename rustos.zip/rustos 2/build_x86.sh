#!/usr/bin/env bash
# build_x86.sh — Build the x86_64 UEFI kernel and test under QEMU.
#
# Requirements:
#   rustup target add x86_64-unknown-uefi
#   apt install qemu-system-x86 ovmf       (Debian/Ubuntu)
#   brew install qemu                      (macOS + download OVMF)
set -euo pipefail

EFI_OUT="target/x86_64-unknown-uefi/debug/rustos_uefi.efi"
EFI_DIR="esp/EFI/BOOT"
OVMF="/usr/share/OVMF/OVMF_CODE.fd"   # adjust if needed

echo "==> Building x86_64 UEFI kernel..."
cargo build \
    --target x86_64-unknown-uefi \
    --features uefi_boot \
    --bin rustos_uefi

echo "==> Staging ESP image..."
mkdir -p "$EFI_DIR"
cp "$EFI_OUT" "$EFI_DIR/BOOTX64.EFI"

echo "==> Launching QEMU..."
qemu-system-x86_64 \
    -machine q35 \
    -cpu host \
    -enable-kvm \
    -m 256M \
    -bios "$OVMF" \
    -drive if=none,id=esp,format=raw,file=fat:rw:esp \
    -device virtio-blk-pci,drive=esp \
    -serial stdio \
    -display none \
    -no-reboot
