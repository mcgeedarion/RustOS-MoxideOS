#!/usr/bin/env bash
# Build a 64 MiB ext2 disk image with full directory hierarchy.
set -euo pipefail

IMG=disk.img
SIZE_MB=64
MNT=$(mktemp -d)
trap 'sudo umount "$MNT" 2>/dev/null || true; rmdir "$MNT"' EXIT

dd if=/dev/zero of="$IMG" bs=1M count="$SIZE_MB" status=progress
mkfs.ext2 -t ext2 -b 4096 -L rustos "$IMG"
sudo mount -o loop "$IMG" "$MNT"

# ── Directory structure ───────────────────────────────────────────────────
sudo mkdir -p "$MNT"/{bin,lib,dev,proc,sys,tmp,etc,var/log,home/root,usr/bin}

# ── Binaries ──────────────────────────────────────────────────────────────
BASE=target/x86_64-unknown-none/release
for BIN in init sh hello cat echo ls true devtest; do
    [ -f "userspace/$BASE/$BIN" ] && sudo cp "userspace/$BASE/$BIN" "$MNT/bin/$BIN"
done
sudo ln -sf /bin/sh "$MNT/bin/bash"   # musl compat
sudo ln -sf /bin/init "$MNT/init"

# ── /etc ─────────────────────────────────────────────────────────────────
echo "root:x:0:0:root:/root:/bin/sh" | sudo tee "$MNT/etc/passwd" > /dev/null
echo "root:x:0:"                     | sudo tee "$MNT/etc/group"  > /dev/null
printf "rustos\\n"                    | sudo tee "$MNT/etc/hostname" > /dev/null
printf "127.0.0.1 localhost\\n10.0.2.15 rustos\\n" | sudo tee "$MNT/etc/hosts" > /dev/null

# ── /dev nodes (kernel devfs handles these virtually, but mknod helps
#    tools that stat(2) device files before opening them) ──────────────────
sudo mknod "$MNT/dev/null"    c 1 3
sudo mknod "$MNT/dev/zero"    c 1 5
sudo mknod "$MNT/dev/full"    c 1 7
sudo mknod "$MNT/dev/random"  c 1 8
sudo mknod "$MNT/dev/urandom" c 1 9
sudo mknod "$MNT/dev/tty"     c 5 0
sudo mknod "$MNT/dev/ptmx"    c 5 2
sudo mkdir -p "$MNT/dev/pts"
sudo chmod 1777 "$MNT/tmp"

sudo umount "$MNT"
echo "Created $IMG (${SIZE_MB} MiB ext2)"
echo "QEMU: bash tools/run_qemu.sh"
