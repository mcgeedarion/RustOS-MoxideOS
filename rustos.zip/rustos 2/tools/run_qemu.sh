#!/usr/bin/env bash
# Launch rustos in QEMU (x86_64 UEFI + VirtIO block + VirtIO net + serial).
set -euo pipefail

KERNEL=target/x86_64-unknown-uefi/release/rustos.efi
DISK=disk.img
OVMF=/usr/share/ovmf/OVMF.fd
[ -f "$OVMF" ] || OVMF=/usr/share/edk2-ovmf/x64/OVMF.fd

[ -f "$KERNEL" ] || { echo "Build kernel first"; exit 1; }
[ -f "$DISK"   ] || { echo "Build disk first: bash tools/mkdisk.sh"; exit 1; }
[ -f "$OVMF"   ] || { echo "Install OVMF: apt install ovmf"; exit 1; }

ESP=$(mktemp -d); trap 'rm -rf "$ESP"' EXIT
mkdir -p "$ESP/EFI/BOOT"
cp "$KERNEL" "$ESP/EFI/BOOT/BOOTX64.EFI"

qemu-system-x86_64 \
    -machine q35 -cpu qemu64,+fsgsbase \
    -m 512M \
    -bios "$OVMF" \
    -drive  "file=fat:rw:${ESP},format=raw,if=pflash,readonly=on" \
    -drive  "file=${DISK},format=raw,if=virtio" \
    -netdev "user,id=net0,net=10.0.2.0/24,host=10.0.2.2,dns=10.0.2.3,dhcpstart=10.0.2.15" \
    -device "virtio-net-pci,netdev=net0" \
    -serial stdio \
    -display none \
    -no-reboot \
    "$@"
