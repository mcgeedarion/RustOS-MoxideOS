#!/usr/bin/env bash
# Build a minimal CPIO newc initramfs containing userspace/hello as /init.
# Output: initramfs.cpio  (link into kernel with --format=binary)
#
# Usage:
#   bash tools/mkinitramfs.sh
#   # Then rebuild with the CPIO linked in:
#   cargo rustc -- -C link-arg=-Wl,--format=binary \
#                  -C link-arg=initramfs.cpio       \
#                  -C link-arg=-Wl,--format=default
set -euo pipefail

BIN=target/riscv64gc-unknown-none-elf/release/hello
OUT=initramfs.cpio

if [ ! -f "$BIN" ]; then
  echo "Build userspace first: (cd userspace && cargo build --release)"
  exit 1
fi

TMPDIR=$(mktemp -d)
trap 'rm -rf $TMPDIR' EXIT

cp "$BIN" "$TMPDIR/init"
chmod +x "$TMPDIR/init"

(cd "$TMPDIR" && echo init | cpio --create --format=newc -O "$(pwd)/$OUT")
cp "$TMPDIR/$OUT" "$OUT"
echo "Created $OUT ($(wc -c < $OUT) bytes)"
