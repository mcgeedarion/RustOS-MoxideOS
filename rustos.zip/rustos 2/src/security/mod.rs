//! Capability-based security model
use core::sync::atomic::{AtomicU64, Ordering};

/// Capability flags for a process
bitflags::bitflags! {
    pub struct Caps: u64 {
        const NET        = 1 << 0;  // open sockets
        const FS_READ    = 1 << 1;  // read filesystem
        const FS_WRITE   = 1 << 2;  // write filesystem
        const EXEC       = 1 << 3;  // execve
        const MMAP_EXEC  = 1 << 4;  // map executable pages
        const PTRACE     = 1 << 5;  // debug other processes
        const ADMIN      = 1 << 63; // all capabilities
    }
}

/// Per-process capability set (stored in PCB).
#[derive(Debug, Clone, Copy)]
pub struct CapSet(u64);

impl CapSet {
    pub const fn new(caps: Caps) -> Self { Self(caps.bits()) }
    pub const fn empty() -> Self { Self(0) }
    pub const fn all()   -> Self { Self(u64::MAX) }

    pub fn has(&self, cap: Caps) -> bool {
        (self.0 & cap.bits()) == cap.bits()
            || (self.0 & Caps::ADMIN.bits()) != 0
    }

    pub fn grant(&mut self, cap: Caps)  { self.0 |= cap.bits(); }
    pub fn revoke(&mut self, cap: Caps) { self.0 &= !cap.bits(); }
}

impl Default for CapSet {
    fn default() -> Self { Self::empty() }
}

/// Validate a syscall against required capabilities.
/// Returns Ok(()) or Err(EPERM).
pub fn check(caps: &CapSet, required: Caps) -> Result<(), i64> {
    if caps.has(required) { Ok(()) } else { Err(-1) /* EPERM */ }
}
