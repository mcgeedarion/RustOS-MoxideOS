//! Input event types
pub const EV_KEY:  u16 = 1;
pub const EV_REL:  u16 = 2;
pub const EV_ABS:  u16 = 3;

#[derive(Debug, Clone, Copy)]
pub struct InputEvent {
    pub kind:  u16,
    pub code:  u16,
    pub value: u32,
}
