//! Flattened device tree parser stub
pub fn parse(_fdt: &[u8]) {
    // TODO: walk FDT and register memory regions + devices
}
