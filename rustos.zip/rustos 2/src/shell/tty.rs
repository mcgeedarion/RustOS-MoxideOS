//! Interactive TTY shell over UART
use crate::drivers::uart;
use crate::proc::{process::Pcb, scheduler};
use crate::security::{CapSet, Caps};
use crate::fs::vfs;

pub fn run() -> ! {
    uart::puts("rustos> ");
    loop {
        let line = readline();
        if line.is_empty() { uart::puts("rustos> "); continue; }
        dispatch(line.trim());
        uart::puts("rustos> ");
    }
}

/// Read a line from UART, echoing characters. Returns a &'static str backed
/// by a fixed static buffer (single-threaded shell, so this is safe).
fn readline() -> &'static str {
    static mut BUF: [u8; 256] = [0u8; 256];
    let buf = unsafe { &mut BUF };
    let mut len = 0usize;
    loop {
        let c = uart::getc();
        match c {
            b'\r' | b'\n' => {
                uart::putc(b'\n');
                let s = core::str::from_utf8(&buf[..len]).unwrap_or("");
                // SAFETY: buf is 'static, valid UTF-8 or replaced with ""
                return unsafe {
                    core::str::from_utf8_unchecked(
                        core::slice::from_raw_parts(buf.as_ptr(), len)
                    )
                };
            }
            0x7f | 0x08 => {
                // Backspace
                if len > 0 {
                    len -= 1;
                    uart::puts("\x08 \x08");
                }
            }
            0x03 => {
                // Ctrl-C — discard line
                uart::puts("^C\n");
                len = 0;
            }
            c if c >= 0x20 && len < buf.len() - 1 => {
                buf[len] = c;
                len += 1;
                uart::putc(c);
            }
            _ => {}
        }
    }
}

fn dispatch(cmd: &str) {
    let mut parts = cmd.splitn(2, ' ');
    match parts.next().unwrap_or("") {
        "help" => {
            uart::puts("commands: help, exec <path>, ps, kill <pid>, reboot\n");
        }
        "exec" => {
            let path = parts.next().unwrap_or("").trim();
            cmd_exec(path);
        }
        "ps" => cmd_ps(),
        "kill" => {
            if let Some(pid_str) = parts.next() {
                if let Ok(pid) = pid_str.trim().parse::<u32>() {
                    scheduler::kill(pid);
                    uart::puts("[shell] sent SIGKILL\n");
                } else {
                    uart::puts("[shell] bad pid\n");
                }
            }
        }
        "reboot" => {
            uart::puts("[shell] rebooting...\n");
            unsafe { core::arch::asm!("wfi"); }
            loop {}
        }
        other => {
            uart::puts("[shell] unknown command: ");
            uart::puts(other);
            uart::putc(b'\n');
        }
    }
}

fn cmd_exec(path: &str) {
    if path.is_empty() { uart::puts("usage: exec <path>\n"); return; }
    match vfs::lookup(path) {
        None => { uart::puts("[exec] file not found\n"); }
        Some(data) => {
            let pid  = scheduler::next_pid();
            let mut pcb = Pcb::new(pid, 0);
            pcb.caps = CapSet::from_bits_truncate(
                Caps::FS_READ.bits() | Caps::EXEC.bits()
            );
            match pcb.load_elf(&data) {
                Ok(()) => {
                    uart::puts("[exec] loaded, enqueuing pid ");
                    print_u32(pid);
                    uart::putc(b'\n');
                    scheduler::enqueue(pcb);
                }
                Err(e) => {
                    uart::puts("[exec] ELF error: ");
                    uart::puts(e);
                    uart::putc(b'\n');
                }
            }
        }
    }
}

fn cmd_ps() {
    uart::puts("PID  STATE\n");
    // We can't iterate PROCS without importing scheduler internals;
    // a real impl would expose a snapshot API.
    uart::puts("(ps not yet wired to scheduler snapshot)\n");
}

fn print_u32(mut n: u32) {
    if n == 0 { uart::putc(b'0'); return; }
    let mut buf = [0u8; 10];
    let mut i = 10usize;
    while n > 0 { i -= 1; buf[i] = b'0' + (n % 10) as u8; n /= 10; }
    for &b in &buf[i..] { uart::putc(b); }
}
