//! GDB remote stub (placeholder)
pub fn attach() {}
