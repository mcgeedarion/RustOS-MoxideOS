//! Text console renderer
use crate::drivers::uart;

const COLS: usize = 80;
const ROWS: usize = 25;

static mut CURSOR_COL: usize = 0;
static mut CURSOR_ROW: usize = 0;

pub fn putc(c: char) {
    match c {
        '\n' => {
            unsafe {
                CURSOR_COL = 0;
                CURSOR_ROW += 1;
                if CURSOR_ROW >= ROWS { CURSOR_ROW = 0; }
            }
        }
        _ => {
            uart::putc(c as u8);
            unsafe {
                CURSOR_COL += 1;
                if CURSOR_COL >= COLS {
                    CURSOR_COL = 0;
                    CURSOR_ROW += 1;
                    if CURSOR_ROW >= ROWS { CURSOR_ROW = 0; }
                }
            }
        }
    }
}

pub fn puts(s: &str) {
    for c in s.chars() { putc(c); }
}
