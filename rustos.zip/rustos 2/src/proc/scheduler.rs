//! Round-robin preemptive scheduler.
//!
//! # Context-switch model
//!
//! RISC-V: tick() is called from trap_handler with a &mut TrapFrame.
//!         It rewrites the frame and calls switch_context() so the pending
//!         sret enters the next process.
//!
//! x86_64: tick() is called from the APIC timer ISR (vector 0x30).
//!         The IDT stub already saved all GP regs onto the kernel stack.
//!         tick() calls switch_context() which swaps RSP/callee-saved regs;
//!         on the new stack the IDT common stub pops regs and executes iretq,
//!         entering the next process in ring 3.

use alloc::vec::Vec;
use core::sync::atomic::{AtomicU32, Ordering};
use spin::Mutex;

use crate::proc::context::{Context, switch_context};
use crate::proc::process::{Pcb, State};

extern crate alloc;

static PROCS:       Mutex<Vec<Pcb>> = Mutex::new(Vec::new());
static NEXT_PID:    AtomicU32       = AtomicU32::new(1);
static CURRENT_PID: AtomicU32       = AtomicU32::new(0);

// Idle context — used when no process is running.
static mut IDLE_CTX: Context = Context::zero();

pub fn init() {}

pub fn next_pid() -> u32 {
    NEXT_PID.fetch_add(1, Ordering::SeqCst)
}

pub fn enqueue(pcb: Pcb) {
    PROCS.lock().push(pcb);
}

pub fn current_pid() -> u32 {
    CURRENT_PID.load(Ordering::SeqCst)
}

pub fn current_pid_nonzero() -> Option<u32> {
    let p = current_pid();
    if p == 0 { None } else { Some(p) }
}

/// Borrow the process list; returns None when idle (no current process).
pub fn current_mut() -> Option<spin::MutexGuard<'static, Vec<Pcb>>> {
    if current_pid() == 0 { return None; }
    Some(PROCS.lock())
}

/// Track a demand-paged physical page under the current PID.
pub fn track_page(pid: u32, pa: usize) {
    if let Some(p) = PROCS.lock().iter_mut().find(|p| p.pid == pid) {
        p.owned_pages.push(pa);
    }
}

// ── RISC-V tick ───────────────────────────────────────────────────────────

/// RISC-V: rewrite the in-progress trap frame so sret enters the next process.
#[cfg(target_arch = "riscv64")]
pub fn tick(tf: &mut crate::arch::riscv64::trap::TrapFrame) {
    use crate::arch::riscv64::csr;
    use crate::mm::vmm::TRAPFRAME_VA;

    let mut procs = PROCS.lock();
    if procs.is_empty() { return; }

    let cur_pid = current_pid();
    let n       = procs.len();

    let cur_idx: Option<usize> = if cur_pid == 0 {
        None
    } else {
        procs.iter().position(|p| p.pid == cur_pid)
    };

    let search_start = cur_idx.map_or(0, |i| i + 1);
    let next_idx = (0..n)
        .map(|i| (search_start + i) % n)
        .find(|&i| procs[i].state == State::Ready);

    let next_idx = match next_idx {
        Some(i) => i,
        None    => return,
    };

    if let Some(idx) = cur_idx {
        if procs[idx].state == State::Running {
            procs[idx].state = State::Ready;
        }
    }

    let next_pid         = procs[next_idx].pid;
    let next_kernel_satp = procs[next_idx].kernel_satp;
    let next_user_satp   = procs[next_idx].user_satp;
    let next_kstack_top  = procs[next_idx].kstack_top;
    let next_pc          = procs[next_idx].pc;
    let next_sp          = procs[next_idx].sp;
    procs[next_idx].state = State::Running;
    CURRENT_PID.store(next_pid, Ordering::SeqCst);
    drop(procs);

    tf.sepc        = next_pc;
    tf.regs[2]     = next_sp;
    tf.user_satp   = next_user_satp;
    tf.kernel_satp = next_kernel_satp;
    tf.kernel_sp   = next_kstack_top;

    unsafe {
        core::arch::asm!("csrw sscratch, {0}", in(reg) TRAPFRAME_VA);
    }
    csr::write_satp(next_kernel_satp);
    csr::sfence_vma();
}

// ── x86_64 tick ───────────────────────────────────────────────────────────

/// x86_64: called from the APIC timer ISR after all GP regs are saved.
///
/// Picks the next Ready process, swaps callee-saved context via
/// switch_context(), and sends EOI to the APIC.  The IDT common stub
/// then pops the new process's GP regs and executes iretq → ring 3.
#[cfg(target_arch = "x86_64")]
pub fn tick(frame: &mut crate::arch::x86_64::idt::InterruptFrame) {
    let _ = frame; // GP regs already saved on the kernel stack by isr_common

    let mut procs = PROCS.lock();
    if procs.is_empty() {
        crate::arch::x86_64::apic::eoi();
        return;
    }

    let cur_pid = current_pid();
    let n       = procs.len();

    let cur_idx: Option<usize> = if cur_pid == 0 {
        None
    } else {
        procs.iter().position(|p| p.pid == cur_pid)
    };

    let search_start = cur_idx.map_or(0, |i| i + 1);
    let next_idx = (0..n)
        .map(|i| (search_start + i) % n)
        .find(|&i| procs[i].state == State::Ready);

    let next_idx = match next_idx {
        Some(i) => i,
        None    => {
            crate::arch::x86_64::apic::eoi();
            return;
        }
    };

    // Mark previous process Ready.
    if let Some(idx) = cur_idx {
        if procs[idx].state == State::Running {
            procs[idx].state = State::Ready;
        }
    }

    // Snapshot what we need before we drop the lock.
    let next_pid  = procs[next_idx].pid;
    let next_cr3  = procs[next_idx].kernel_satp; // x86_64: CR3
    let next_rsp0 = procs[next_idx].kstack_top as u64;

    let old_ctx_ptr: *mut Context = match cur_idx {
        Some(idx) => &mut procs[idx].ctx as *mut Context,
        None      => unsafe { &mut IDLE_CTX as *mut Context },
    };
    let new_ctx_ptr: *const Context = &procs[next_idx].ctx as *const Context;

    procs[next_idx].state = State::Running;
    CURRENT_PID.store(next_pid, Ordering::SeqCst);
    drop(procs);

    // Update RSP0 in the TSS so ring-0 entry uses the new kernel stack.
    crate::arch::x86_64::gdt::set_rsp0(next_rsp0);

    // Switch CR3 to the new process's address space.
    unsafe {
        core::arch::asm!(
            "mov cr3, {0}",
            in(reg) next_cr3,
            options(nostack, preserves_flags),
        );
    }

    // EOI before the context switch so the APIC can fire again.
    crate::arch::x86_64::apic::eoi();

    // Swap kernel stacks + callee-saved registers.
    // Returns into the new process's kernel stack (eventually iretq → ring 3).
    unsafe { switch_context(old_ctx_ptr, new_ctx_ptr); }
}

// ── Exit / kill ───────────────────────────────────────────────────────────

/// Mark the current process as a zombie and yield the CPU.
pub fn exit(code: i32) {
    let cur_pid = current_pid();
    {
        let mut procs = PROCS.lock();
        if let Some(p) = procs.iter_mut().find(|p| p.pid == cur_pid) {
            p.state     = State::Zombie;
            p.exit_code = code;
        }
    }
    CURRENT_PID.store(0, Ordering::SeqCst);
    // TODO: wake parent (wait/waitpid), for now just reap immediately.
    reap(cur_pid);
}

/// Immediately reclaim all memory for `pid`.
pub fn reap(pid: u32) {
    let mut procs = PROCS.lock();
    if let Some(idx) = procs.iter().position(|p| p.pid == pid) {
        procs[idx].free_all();
        procs.swap_remove(idx);
    }
}

/// Kill a process by PID.
pub fn kill(pid: u32) {
    {
        let mut procs = PROCS.lock();
        if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
            p.state     = State::Zombie;
            p.exit_code = -1;
        }
    }
    reap(pid);
}

/// Voluntarily yield the CPU (used by SYS_YIELD).
/// Simply marks the current process Ready and triggers a reschedule.
pub fn current_yield() {
    let pid = current_pid();
    if pid == 0 { return; }
    let mut procs = PROCS.lock();
    if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
        if p.state == State::Running { p.state = State::Ready; }
    }
    CURRENT_PID.store(0, Ordering::SeqCst);
    drop(procs);
    // The next timer tick will call tick() and resume a Ready process.
    // On x86_64 we can force an immediate reschedule via a self-IPI.
    #[cfg(target_arch = "x86_64")]
    crate::arch::x86_64::apic::send_self_ipi(0x30);
}

/// Expose the PROCS lock for fork/cow_fault — returns a MutexGuard.
pub fn procs_lock() -> spin::MutexGuard<'static, alloc::vec::Vec<Pcb>> {
    PROCS.lock()
}

/// Mark current process as Zombie, deliver SIGCHLD to parent, wake it.
/// (Overrides the previous exit() that immediately freed pages.)
pub fn exit(code: i32) -> ! {
    let pid = CURRENT_PID.load(Ordering::SeqCst);
    let ppid = {
        let mut procs = PROCS.lock();
        if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
            p.state     = State::Zombie;
            p.exit_code = code;
            p.ppid
        } else { 0 }
    };

    // Send SIGCHLD to parent and wake it if it was blocked in waitpid.
    if ppid != 0 {
        let mut procs = PROCS.lock();
        if let Some(parent) = procs.iter_mut().find(|p| p.pid == ppid) {
            parent.signals.raise(crate::proc::signal::SIGCHLD);
            if parent.state == State::Blocked
               && (parent.wait_for_pid == 0 || parent.wait_for_pid == pid)
            {
                parent.state = State::Ready;
            }
        }
    }

    CURRENT_PID.store(0, Ordering::SeqCst);
    // Force immediate reschedule.
    #[cfg(target_arch = "x86_64")]
    crate::arch::x86_64::apic::send_self_ipi(0x30);
    loop { unsafe { core::arch::asm!("wfi", options(nostack, nomem)); } }
}

/// Free all pages owned by a zombie process (called from waitpid after
/// the exit code has been collected).
pub fn reap_zombie(pid: u32) {
    let mut procs = PROCS.lock();
    if let Some(idx) = procs.iter().position(|p| p.pid == pid) {
        let mut pcb = procs.remove(idx);
        for pa in pcb.owned_pages.drain(..) {
            crate::mm::pmm::free_page(pa);
        }
    }
}

/// Track a newly-allocated page as owned by `pid` (used by COW handler).
pub fn track_page(pid: u32, pa: usize) {
    let mut procs = PROCS.lock();
    if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
        p.owned_pages.push(pa);
    }
}

/// Snapshot of all live PIDs (for /proc listing).
pub fn all_pids() -> alloc::vec::Vec<u32> {
    RUNQ.lock().iter().map(|p| p.pid).collect()
}

/// Clone a minimal PCB snapshot for /proc/<pid>/status.
pub fn find_pcb(pid: u32) -> Option<crate::proc::process::PcbSnapshot> {
    RUNQ.lock().iter()
        .find(|p| p.pid == pid)
        .map(|p| crate::proc::process::PcbSnapshot {
            pid:   p.pid,
            ppid:  p.ppid,
            state: p.state,
            name:  p.name,
            pages: p.page_count,
        })
}

/// Return the PID of the currently scheduled (foreground) process.
pub fn foreground_pid() -> Option<u32> {
    RUNQ.lock().iter().find(|p| p.state == crate::proc::process::State::Running)
        .map(|p| p.pid)
}

// ── Thread-aware additions ────────────────────────────────────────────────

use crate::proc::thread::{Thread, ThreadState};

/// Global thread run queue (replaces simple PCB list when threads are active).
static THREAD_Q: spin::Mutex<alloc::vec::Vec<Thread>> = spin::Mutex::new(alloc::vec::Vec::new());
static NEXT_TID: core::sync::atomic::AtomicU32 = core::sync::atomic::AtomicU32::new(100);

pub fn next_tid() -> u32 {
    NEXT_TID.fetch_add(1, core::sync::atomic::Ordering::Relaxed)
}

pub fn enqueue_thread(t: Thread) {
    THREAD_Q.lock().push(t);
}

pub fn current_tid()   -> u32 { current_pid() }      // single-threaded: tid == pid
pub fn current_tgid()  -> u32 { current_pid() }
pub fn current_mm_root() -> usize {
    // Return cr3
    let cr3: usize;
    unsafe { core::arch::asm!("mov {}, cr3", out(reg) cr3); }
    cr3 & !0xFFF
}
pub fn current_name() -> &'static [u8] { b"sh" }

/// Block the current thread on a futex address; yield CPU.
pub fn block_current(futex_addr: usize) {
    // Mark running thread as Blocked
    let tid = current_tid();
    let mut q = THREAD_Q.lock();
    if let Some(t) = q.iter_mut().find(|t| t.tid == tid) {
        t.state = ThreadState::Blocked;
        t.futex_addr = Some(futex_addr);
    }
    drop(q);
    current_yield();
}

/// Unblock a thread waiting on a futex, making it Ready.
pub fn unblock_tid(tid: u32) {
    let mut q = THREAD_Q.lock();
    if let Some(t) = q.iter_mut().find(|t| t.tid == tid) {
        t.state = ThreadState::Ready;
        t.futex_addr = None;
    }
}

/// Collect all TIDs in the thread queue.
pub fn all_tids() -> alloc::vec::Vec<u32> {
    THREAD_Q.lock().iter().map(|t| t.tid).collect()
}
