pub mod clone;
pub mod context;
pub mod cow_fault;
pub mod fork;
pub mod futex;
pub mod process;
pub mod scheduler;
pub mod signal;
pub mod thread;
pub mod wait;

pub use scheduler::{enqueue, next_pid};

#[cfg(target_arch = "x86_64")]
pub fn init() {
    scheduler::init();
    crate::serial_println!("[proc] scheduler ready (threads/futex/clone)");
}

#[cfg(target_arch = "riscv64")]
pub fn init() {
    scheduler::init();
    extern "C" { fn _user_init(); }
    crate::serial_println!("[proc] scheduler ready (riscv64)");
}
