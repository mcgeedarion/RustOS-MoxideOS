//! Futex — fast userspace mutex.
//!
//! Implements the minimal set needed by musl pthread:
//!   FUTEX_WAIT      (0) — atomically check *uaddr==val, block if equal
//!   FUTEX_WAKE      (1) — wake up to `val` waiters on uaddr
//!   FUTEX_REQUEUE   (3) — wake `val` waiters, requeue `val2` to uaddr2
//!   FUTEX_WAIT_BITSET (9) / FUTEX_WAKE_BITSET (10) — masked variants
//!
//! All futex operations are O(n) in the number of waiters on the same
//! address — sufficient for the expected workload.  A hash-bucketed
//! implementation can replace this later.

extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;

// ── Futex operations ──────────────────────────────────────────────────────

pub const FUTEX_WAIT:      u32 = 0;
pub const FUTEX_WAKE:      u32 = 1;
pub const FUTEX_FD:        u32 = 2;
pub const FUTEX_REQUEUE:   u32 = 3;
pub const FUTEX_PRIVATE:   u32 = 128;
pub const FUTEX_WAIT_BITSET:u32 = 9;
pub const FUTEX_WAKE_BITSET:u32 = 10;
pub const FUTEX_BITSET_MATCH_ANY: u32 = 0xFFFF_FFFF;

// ── Waiter table ──────────────────────────────────────────────────────────

struct Waiter { tid: u32, addr: usize, bitset: u32 }
static WAITERS: Mutex<Vec<Waiter>> = Mutex::new(Vec::new());

// ── FUTEX_WAIT ────────────────────────────────────────────────────────────

/// Block the calling thread if `*uaddr == expected`.
/// Returns 0 on wake, -EAGAIN if value didn't match, -ETIMEDOUT on timeout.
pub fn futex_wait(uaddr: usize, expected: u32, bitset: u32) -> isize {
    // Atomic check: read current value
    let cur = unsafe { core::ptr::read_volatile(uaddr as *const u32) };
    if cur != expected { return -11; } // EAGAIN

    let tid = crate::proc::scheduler::current_tid();
    {
        let mut w = WAITERS.lock();
        w.push(Waiter { tid, addr: uaddr, bitset });
    }

    // Mark thread as blocked and yield
    crate::proc::scheduler::block_current(uaddr);

    // When we return here the thread was woken
    0
}

// ── FUTEX_WAKE ────────────────────────────────────────────────────────────

/// Wake up to `count` threads waiting on `uaddr` with matching bitset.
/// Returns number of threads woken.
pub fn futex_wake(uaddr: usize, count: u32, bitset: u32) -> isize {
    let mut waiters = WAITERS.lock();
    let mut woken = 0u32;
    let mut i = 0;
    while i < waiters.len() && woken < count {
        if waiters[i].addr == uaddr && (waiters[i].bitset & bitset != 0) {
            let tid = waiters[i].tid;
            waiters.remove(i);
            drop(waiters);
            crate::proc::scheduler::unblock_tid(tid);
            waiters = WAITERS.lock();
            woken += 1;
        } else {
            i += 1;
        }
    }
    woken as isize
}

// ── FUTEX_REQUEUE ─────────────────────────────────────────────────────────

/// Wake `wake_count` threads on uaddr, then requeue up to `requeue_count`
/// from uaddr → uaddr2.
pub fn futex_requeue(uaddr: usize, wake_count: u32, requeue_count: u32, uaddr2: usize) -> isize {
    let woken = futex_wake(uaddr, wake_count, FUTEX_BITSET_MATCH_ANY);
    let mut waiters = WAITERS.lock();
    let mut requeued = 0u32;
    for w in waiters.iter_mut() {
        if requeued >= requeue_count { break; }
        if w.addr == uaddr { w.addr = uaddr2; requeued += 1; }
    }
    woken
}

// ── Unblock all waiters on addr (called from futex_wake path) ─────────────

pub fn cancel_waiter(tid: u32) {
    WAITERS.lock().retain(|w| w.tid != tid);
}

// ── sys_futex entry point ─────────────────────────────────────────────────

pub fn sys_futex(uaddr: usize, op: u32, val: u32,
                 _timeout: usize, uaddr2: usize, val3: u32) -> isize
{
    let base_op = op & !FUTEX_PRIVATE;
    match base_op {
        FUTEX_WAIT       => futex_wait(uaddr, val, FUTEX_BITSET_MATCH_ANY),
        FUTEX_WAIT_BITSET => futex_wait(uaddr, val, val3),
        FUTEX_WAKE       => futex_wake(uaddr, val, FUTEX_BITSET_MATCH_ANY),
        FUTEX_WAKE_BITSET => futex_wake(uaddr, val, val3),
        FUTEX_REQUEUE    => futex_requeue(uaddr, val, val3, uaddr2),
        _                => -38, // ENOSYS
    }
}
