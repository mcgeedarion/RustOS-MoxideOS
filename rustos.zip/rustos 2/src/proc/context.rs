//! CPU context saved and restored on voluntary context switches.
//!
//! # RISC-V
//! Saves the 14 callee-saved registers (s0–s11, ra, sp) per the RISC-V ABI.
//!
//! # x86_64
//! Saves the 8 callee-saved registers defined by the System-V AMD64 ABI:
//!   rbx, rbp, r12, r13, r14, r15, rsp  (+  the return address as rip).
//! Volatile registers (rax, rcx, rdx, rsi, rdi, r8–r11) are not saved here
//! because the caller already saved them (they are caller-saved by the ABI).

// ── RISC-V context ────────────────────────────────────────────────────────

#[cfg(target_arch = "riscv64")]
#[repr(C)]
pub struct Context {
    pub ra:  usize,
    pub sp:  usize,
    pub s0:  usize,  pub s1:  usize,
    pub s2:  usize,  pub s3:  usize,
    pub s4:  usize,  pub s5:  usize,
    pub s6:  usize,  pub s7:  usize,
    pub s8:  usize,  pub s9:  usize,
    pub s10: usize,  pub s11: usize,
}

#[cfg(target_arch = "riscv64")]
impl Context {
    pub const fn zero() -> Self {
        Self { ra:0, sp:0,
               s0:0,  s1:0,  s2:0,  s3:0,
               s4:0,  s5:0,  s6:0,  s7:0,
               s8:0,  s9:0,  s10:0, s11:0 }
    }
}

#[cfg(target_arch = "riscv64")]
core::arch::global_asm!(r#"
.section .text
.global switch_context
# switch_context(old: *mut Context, new: *const Context)
switch_context:
    sd  ra,    0(a0)
    sd  sp,    8(a0)
    sd  s0,   16(a0)
    sd  s1,   24(a0)
    sd  s2,   32(a0)
    sd  s3,   40(a0)
    sd  s4,   48(a0)
    sd  s5,   56(a0)
    sd  s6,   64(a0)
    sd  s7,   72(a0)
    sd  s8,   80(a0)
    sd  s9,   88(a0)
    sd  s10,  96(a0)
    sd  s11, 104(a0)

    ld  ra,    0(a1)
    ld  sp,    8(a1)
    ld  s0,   16(a1)
    ld  s1,   24(a1)
    ld  s2,   32(a1)
    ld  s3,   40(a1)
    ld  s4,   48(a1)
    ld  s5,   56(a1)
    ld  s6,   64(a1)
    ld  s7,   72(a1)
    ld  s8,   80(a1)
    ld  s9,   88(a1)
    ld  s10,  96(a1)
    ld  s11, 104(a1)
    ret
"#);

// ── x86_64 context ────────────────────────────────────────────────────────

/// x86_64 callee-saved context (System-V AMD64 ABI).
///
/// Layout (matches the `switch_context` assembly exactly):
///   Offset  Register
///    0       rbx
///    8       rbp
///   16       r12
///   24       r13
///   32       r14
///   40       r15
///   48       rsp   (kernel stack pointer, saved BEFORE the call frame)
///   56       rip   (return address pushed by `call switch_context`)
#[cfg(target_arch = "x86_64")]
#[repr(C)]
pub struct Context {
    pub rbx: usize,
    pub rbp: usize,
    pub r12: usize,
    pub r13: usize,
    pub r14: usize,
    pub r15: usize,
    pub rsp: usize,  // saved kernel RSP
    pub rip: usize,  // where to return to after switch
}

#[cfg(target_arch = "x86_64")]
impl Context {
    pub const fn zero() -> Self {
        Self { rbx:0, rbp:0, r12:0, r13:0, r14:0, r15:0, rsp:0, rip:0 }
    }
}

/// Save callee-saved registers into `*old` and restore from `*new`.
///
/// # Safety
/// Both pointers must be valid, non-null, and properly aligned.
/// The stack must be 16-byte aligned at the call site (ABI requirement).
#[cfg(target_arch = "x86_64")]
core::arch::global_asm!(r#"
.section .text
.global switch_context
# switch_context(old: *mut Context, new: *const Context)
#   rdi = old,  rsi = new   (System-V AMD64 calling convention)
switch_context:
    # Save callee-saved registers of the outgoing context.
    mov  [rdi +  0], rbx
    mov  [rdi +  8], rbp
    mov  [rdi + 16], r12
    mov  [rdi + 24], r13
    mov  [rdi + 32], r14
    mov  [rdi + 40], r15
    # Save RSP *after* the call (return address is already on the stack).
    mov  [rdi + 48], rsp
    # Save the return address so we come back here after the next switch.
    mov  rax, [rsp]
    mov  [rdi + 56], rax

    # Restore callee-saved registers of the incoming context.
    mov  rbx, [rsi +  0]
    mov  rbp, [rsi +  8]
    mov  r12, [rsi + 16]
    mov  r13, [rsi + 24]
    mov  r14, [rsi + 32]
    mov  r15, [rsi + 40]
    # Restore RSP — this switches to the new kernel stack.
    mov  rsp, [rsi + 48]
    # Push the saved RIP so `ret` jumps into the new process.
    push qword ptr [rsi + 56]
    ret
"#);

// ── Shared extern declaration ─────────────────────────────────────────────

extern "C" {
    /// Save `*old` and restore `*new`.  Returns into `new.rip` / `new.ra`.
    pub fn switch_context(old: *mut Context, new: *const Context);
}

impl Context {
    /// Build a Context snapshot from a saved interrupt frame.
    /// Used by clone() to give the child the same register state as the parent.
    pub fn from_frame(frame: &crate::arch::x86_64::interrupts::InterruptFrame) -> Self {
        let mut ctx = Context::default();
        ctx.rip = frame.rip;
        ctx.rsp = frame.rsp;
        ctx.rbp = frame.rbp;
        ctx.rbx = frame.rbx;
        ctx.r12 = frame.r12;
        ctx.r13 = frame.r13;
        ctx.r14 = frame.r14;
        ctx.r15 = frame.r15;
        ctx.rax = frame.rax;
        ctx
    }
}
