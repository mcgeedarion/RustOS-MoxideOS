//! Copy-on-write page-fault handler for x86_64.
//!
//! Called from the IDT page-fault stub (vector 14) when:
//!   - error code bit 1 (W) is set  — write fault
//!   - error code bit 0 (P) is set  — page was present (so it's a COW hit)
//!
//! Procedure:
//!   1. Walk the current process's PML4 to find the faulting PTE.
//!   2. If the page has a COW ref-count > 1, allocate a fresh copy.
//!   3. If ref-count == 1 (only us), just re-enable the Write bit.
//!   4. Flush the TLB entry and return — the faulting instruction retries.

use crate::arch::x86_64::paging as pg;
use crate::mm::pmm::{self, PAGE_SIZE};
use crate::proc::{fork::cow_dec, scheduler};

/// Try to handle a write fault at `cr2_va` for the current process.
/// Returns `true` if handled (retry instruction), `false` if it's a real fault.
pub fn handle_cow(cr2_va: usize, error_code: u64) -> bool {
    // Only handle present + write faults.
    let is_write   = error_code & (1 << 1) != 0;
    let is_present = error_code & (1 << 0) != 0;
    if !is_write || !is_present { return false; }

    let pid = scheduler::current_pid();
    if pid == 0 { return false; }

    let cr3 = {
        let procs = scheduler::procs_lock();
        match procs.iter().find(|p| p.pid == pid) {
            Some(p) => p.user_satp,
            None    => return false,
        }
    };

    // Walk the page table to find the leaf PTE.
    let pml4i = (cr2_va >> 39) & 0x1FF;
    let pdpti = (cr2_va >> 30) & 0x1FF;
    let pdi   = (cr2_va >> 21) & 0x1FF;
    let pti   = (cr2_va >> 12) & 0x1FF;

    unsafe {
        let pml4 = cr3 as *mut u64;
        let pml4e = pml4.add(pml4i).read_volatile();
        if pml4e & 1 == 0 { return false; }

        let pdpt = (pml4e & !0xFFF) as *mut u64;
        let pdpte = pdpt.add(pdpti).read_volatile();
        if pdpte & 1 == 0 { return false; }

        let pd = (pdpte & !0xFFF) as *mut u64;
        let pde = pd.add(pdi).read_volatile();
        if pde & 1 == 0 { return false; }

        // 2 MiB huge page COW
        if pde & (1 << 7) != 0 {
            let old_pa = (pde & !0xFFF) as usize;
            if cow_dec(old_pa) {
                // Sole owner — just re-enable Write
                pd.add(pdi).write_volatile(pde | (1 << 1));
            } else {
                let new_pa = pmm::alloc_page().expect("OOM: COW huge");
                core::ptr::copy_nonoverlapping(
                    old_pa as *const u8, new_pa as *mut u8, PAGE_SIZE,
                );
                let new_pde = (new_pa as u64 & !0xFFF) | (pde & 0xFFF) | (1 << 1);
                pd.add(pdi).write_volatile(new_pde);
                track_page(pid, new_pa);
            }
            pg::flush(cr2_va as u64);
            return true;
        }

        let pt = (pde & !0xFFF) as *mut u64;
        let pte = pt.add(pti).read_volatile();
        if pte & 1 == 0 { return false; }

        let old_pa = (pte & !0xFFF) as usize;

        if cow_dec(old_pa) {
            // Only reference left — re-enable Write bit in place.
            pt.add(pti).write_volatile(pte | (1 << 1));
        } else {
            // Shared — make a private copy.
            let new_pa = pmm::alloc_page().expect("OOM: COW copy");
            core::ptr::copy_nonoverlapping(
                old_pa as *const u8, new_pa as *mut u8, PAGE_SIZE,
            );
            let new_pte = (new_pa as u64 & !0xFFF) | (pte & 0xFFF) | (1 << 1);
            pt.add(pti).write_volatile(new_pte);
            track_page(pid, new_pa);
        }

        pg::flush(cr2_va as u64);
    }
    true
}

fn track_page(pid: u32, pa: usize) {
    scheduler::track_page(pid, pa);
}
