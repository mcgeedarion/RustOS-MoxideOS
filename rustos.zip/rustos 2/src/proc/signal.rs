//! POSIX-subset signal delivery for x86_64 + RISC-V.
//!
//! # Supported signals
//!   SIGHUP  (1)   SIGINT  (2)   SIGQUIT (3)   SIGILL  (4)
//!   SIGABRT (6)   SIGFPE  (8)   SIGKILL (9)   SIGSEGV (11)
//!   SIGPIPE (13)  SIGALRM (14)  SIGTERM (15)  SIGCHLD (17)
//!   SIGCONT (18)  SIGSTOP (19)  SIGUSR1 (10)  SIGUSR2 (12)
//!
//! # Delivery model
//! Signals are stored as a bitmask in the PCB.  On every return from
//! kernel to user space the pending mask is checked.  If a non-blocked
//! signal is pending:
//!   - SIGKILL / SIGSTOP  — handled in-kernel (no user handler).
//!   - User-installed handler (SIG_DFL replaced) — build a signal frame
//!     on the user stack and redirect SYSRET / IRET to the handler.
//!   - SIG_DFL             — default action (term/core/ignore/stop).
//!
//! # x86_64 signal frame layout (on user stack)
//!
//!   ucontext_t-compatible layout so libc sigreturn() works:
//!   [rsp-0]    return address → sigreturn trampoline (in vDSO / user page)
//!   [rsp+8]    siginfo_t  (128 bytes)
//!   [rsp+136]  ucontext_t (mcontext: all 16 GP regs + rip + rflags)
//!   Total: 8 + 128 + 232 = 368 bytes, aligned to 16.

use core::sync::atomic::{AtomicU64, Ordering};
use spin::Mutex;

// ── Signal numbers ────────────────────────────────────────────────────────

pub const SIGHUP:  u8 = 1;   pub const SIGINT:  u8 = 2;
pub const SIGQUIT: u8 = 3;   pub const SIGILL:  u8 = 4;
pub const SIGABRT: u8 = 6;   pub const SIGFPE:  u8 = 8;
pub const SIGKILL: u8 = 9;   pub const SIGUSR1: u8 = 10;
pub const SIGSEGV: u8 = 11;  pub const SIGUSR2: u8 = 12;
pub const SIGPIPE: u8 = 13;  pub const SIGALRM: u8 = 14;
pub const SIGTERM: u8 = 15;  pub const SIGCHLD: u8 = 17;
pub const SIGCONT: u8 = 18;  pub const SIGSTOP: u8 = 19;
pub const NSIG:    usize = 32;

/// Signal disposition for one signal.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Disposition {
    Default,
    Ignore,
    Handler(usize),    // user-space handler VA
}

/// Per-process signal state stored in the PCB.
pub struct SigState {
    /// Bitmask of pending signals (bit N = signal N+1 pending).
    pub pending:  u64,
    /// Bitmask of blocked signals (signal mask / sigprocmask).
    pub blocked:  u64,
    /// Per-signal disposition table.
    pub actions:  [Disposition; NSIG],
}

impl SigState {
    pub const fn new() -> Self {
        Self {
            pending: 0,
            blocked: 0,
            actions: [Disposition::Default; NSIG],
        }
    }

    pub fn raise(&mut self, sig: u8) {
        if sig == 0 || sig as usize > NSIG { return; }
        self.pending |= 1u64 << (sig - 1);
    }

    pub fn is_pending_unblocked(&self) -> bool {
        self.pending & !self.blocked != 0
    }

    pub fn next_unblocked(&self) -> Option<u8> {
        let mask = self.pending & !self.blocked;
        if mask == 0 { return None; }
        Some(mask.trailing_zeros() as u8 + 1)
    }

    pub fn clear(&mut self, sig: u8) {
        if sig == 0 || sig as usize > NSIG { return; }
        self.pending &= !(1u64 << (sig - 1));
    }
}

// ── Default action table ──────────────────────────────────────────────────

#[derive(Clone, Copy)]
pub enum DefaultAction { Term, Core, Ign, Stop, Cont }

pub const fn default_action(sig: u8) -> DefaultAction {
    match sig {
        SIGHUP | SIGINT | SIGQUIT | SIGILL | SIGABRT | SIGFPE |
        SIGPIPE | SIGALRM | SIGTERM | SIGUSR1 | SIGUSR2 => DefaultAction::Term,
        SIGSEGV => DefaultAction::Core,
        SIGCHLD => DefaultAction::Ign,
        SIGSTOP => DefaultAction::Stop,
        SIGCONT => DefaultAction::Cont,
        SIGKILL => DefaultAction::Term,
        _       => DefaultAction::Ign,
    }
}

// ── Signal frame (x86_64) ─────────────────────────────────────────────────

/// Saved user context pushed onto the user stack at signal delivery.
/// Compatible with the Linux ucontext_t mcontext layout so musl/glibc
/// `sigreturn()` can restore it.
#[repr(C)]
pub struct MContext {
    pub r8:     u64, pub r9:     u64, pub r10:    u64, pub r11:    u64,
    pub r12:    u64, pub r13:    u64, pub r14:    u64, pub r15:    u64,
    pub rdi:    u64, pub rsi:    u64, pub rbp:    u64, pub rbx:    u64,
    pub rdx:    u64, pub rax:    u64, pub rcx:    u64, pub rsp:    u64,
    pub rip:    u64, pub rflags: u64,
    pub cs:     u16, pub gs:     u16, pub fs:     u16, pub _pad:   u16,
    pub err:    u64, pub trapno: u64, pub oldmask: u64, pub cr2:   u64,
}

/// Minimal siginfo_t (only si_signo matters for our purposes).
#[repr(C)]
pub struct SigInfo {
    pub signo: i32,
    pub errno: i32,
    pub code:  i32,
    pub _pad:  [u8; 116],
}

/// Full signal frame placed on the user stack.
#[repr(C, align(16))]
pub struct SignalFrame {
    pub ret_addr:  u64,        // → sigreturn trampoline
    pub info:      SigInfo,
    pub mctx:      MContext,
}

impl core::mem::MaybeUninit<SignalFrame> {}

// ── Deliver pending signal (x86_64 SYSRET path) ───────────────────────────

/// Check and deliver one pending signal to the current process.
///
/// `user_rip`  — where the process was about to return to (rcx before SYSRET).
/// `user_rsp`  — user stack pointer (frame.user_rsp).
/// `rflags`    — user RFLAGS (frame.r11).
///
/// Returns `Some((new_rip, new_rsp))` if a signal was delivered (caller
/// must update frame.rcx and frame.user_rsp), or `None` if nothing to do.
#[cfg(target_arch = "x86_64")]
pub fn deliver_pending(
    user_rip: u64,
    user_rsp: u64,
    rflags:   u64,
    all_regs: &crate::arch::x86_64::syscall::SyscallFrame,
) -> Option<(u64, u64)> {
    let pid = crate::proc::scheduler::current_pid();
    if pid == 0 { return None; }

    let (sig, disp, sigreturn_va) = {
        let mut procs = crate::proc::scheduler::procs_lock();
        let p = procs.iter_mut().find(|p| p.pid == pid)?;

        let sig = p.signals.next_unblocked()?;
        p.signals.clear(sig);
        let disp = p.signals.actions[(sig - 1) as usize];
        (sig, disp, p.sigreturn_va)
    };

    match disp {
        Disposition::Ignore => return None,

        Disposition::Default => {
            match default_action(sig) {
                DefaultAction::Term | DefaultAction::Core => {
                    crate::proc::scheduler::exit(-(sig as i32));
                }
                DefaultAction::Stop => {
                    // Mark blocked; real stop would require more scheduler work.
                    let mut procs = crate::proc::scheduler::procs_lock();
                    if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
                        p.state = crate::proc::process::State::Blocked;
                    }
                }
                DefaultAction::Cont | DefaultAction::Ign => {}
            }
            return None;
        }

        Disposition::Handler(handler_va) => {
            // Build signal frame on the user stack (16-byte aligned).
            let frame_size = core::mem::size_of::<SignalFrame>();
            let new_rsp = (user_rsp as usize - frame_size) & !15usize;
            let sf_ptr  = new_rsp as *mut SignalFrame;

            // Fill in MContext from the current user registers.
            let mctx = MContext {
                r8:  all_regs.r8,  r9:  all_regs.r9,  r10: all_regs.r10,
                r11: rflags,       r12: all_regs.r12,  r13: all_regs.r13,
                r14: all_regs.r14, r15: all_regs.r15,
                rdi: all_regs.rdi, rsi: all_regs.rsi,  rbp: all_regs.rbp,
                rbx: all_regs.rbx, rdx: all_regs.rdx,  rax: all_regs.rax,
                rcx: all_regs.rcx, rsp: user_rsp,
                rip: user_rip, rflags,
                cs: 0x1B, gs: 0, fs: 0, _pad: 0,
                err: 0, trapno: sig as u64, oldmask: 0, cr2: 0,
            };
            let info = SigInfo { signo: sig as i32, errno: 0, code: 0, _pad: [0; 116] };
            let sf = SignalFrame { ret_addr: sigreturn_va, info, mctx };

            // Validate user stack range.
            if !crate::uaccess::validate_user_ptr(new_rsp, frame_size) {
                crate::proc::scheduler::exit(-11); // SIGSEGV
                return None;
            }
            unsafe { core::ptr::write(sf_ptr, sf); }

            // rdi = sig number (first argument to handler per SysV ABI)
            // TODO: rsi = siginfo ptr, rdx = ucontext ptr (SA_SIGINFO)
            return Some((handler_va as u64, new_rsp as u64));
        }
    }
}

// ── sigaction syscall helpers ─────────────────────────────────────────────

/// Install a user-space handler for `sig`.  Returns old disposition.
pub fn sys_sigaction(sig: u8, handler_va: usize) -> isize {
    if sig == 0 || sig as usize > NSIG || sig == SIGKILL || sig == SIGSTOP {
        return -22; // EINVAL
    }
    let pid = crate::proc::scheduler::current_pid();
    let mut procs = crate::proc::scheduler::procs_lock();
    if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
        p.signals.actions[(sig - 1) as usize] = if handler_va == 0 {
            Disposition::Default
        } else if handler_va == 1 {
            Disposition::Ignore
        } else {
            Disposition::Handler(handler_va)
        };
    }
    0
}

/// Block/unblock signals (sigprocmask).
/// `how`: 0=SIG_BLOCK, 1=SIG_UNBLOCK, 2=SIG_SETMASK.
pub fn sys_sigprocmask(how: usize, set: u64) -> isize {
    let pid = crate::proc::scheduler::current_pid();
    let mut procs = crate::proc::scheduler::procs_lock();
    if let Some(p) = procs.iter_mut().find(|p| p.pid == pid) {
        match how {
            0 => p.signals.blocked |=  set,
            1 => p.signals.blocked &= !set,
            2 => p.signals.blocked  =  set,
            _ => return -22,
        }
        // SIGKILL and SIGSTOP cannot be blocked.
        p.signals.blocked &= !(1u64 << (SIGKILL - 1)) & !(1u64 << (SIGSTOP - 1));
    }
    0
}

/// Send signal `sig` to process `pid`.
pub fn sys_kill(pid: u32, sig: u8) -> isize {
    if sig as usize > NSIG { return -22; }
    let mut procs = crate::proc::scheduler::procs_lock();
    match procs.iter_mut().find(|p| p.pid == pid) {
        Some(p) => { p.signals.raise(sig); 0 }
        None    => -3, // ESRCH
    }
}

/// Send a signal to the foreground process group (current running process).
/// Called by the TTY driver on ^C / ^\.
pub fn send_foreground(sig: u8) {
    if let Some(pid) = crate::proc::scheduler::foreground_pid() {
        crate::proc::signal::send(pid, sig);
    }
}
