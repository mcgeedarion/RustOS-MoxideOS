//! clone(2) — the foundation of both fork() and pthread_create().
//!
//! Linux clone() flags relevant to threading:
//!
//!   CLONE_VM          (0x00000100)  share address space
//!   CLONE_FS          (0x00000200)  share filesystem root/cwd
//!   CLONE_FILES       (0x00000400)  share fd table
//!   CLONE_SIGHAND     (0x00000800)  share signal handlers
//!   CLONE_THREAD      (0x00010000)  same thread group (TGID)
//!   CLONE_SYSVSEM     (0x00040000)  share SysV semaphores
//!   CLONE_SETTLS      (0x00080000)  set TLS to ctid arg
//!   CLONE_PARENT_SETTID (0x00100000) write TID to ptid ptr
//!   CLONE_CHILD_CLEARTID(0x00200000) clear ctid on exit, futex wake
//!   CLONE_CHILD_SETTID  (0x01000000) write TID into child's ctid
//!
//! For fork(): none of the CLONE_* thread flags are set — child gets
//! its own copy of everything.

extern crate alloc;
use crate::proc::thread::{Thread, ThreadState};
use crate::proc::context::Context;
use crate::mm::pmm::{self, PAGE_SIZE};
use crate::arch::x86_64::paging;

// ── Flag constants ────────────────────────────────────────────────────────

pub const CLONE_VM:            u64 = 0x0000_0100;
pub const CLONE_FS:            u64 = 0x0000_0200;
pub const CLONE_FILES:         u64 = 0x0000_0400;
pub const CLONE_SIGHAND:       u64 = 0x0000_0800;
pub const CLONE_THREAD:        u64 = 0x0001_0000;
pub const CLONE_SYSVSEM:       u64 = 0x0004_0000;
pub const CLONE_SETTLS:        u64 = 0x0008_0000;
pub const CLONE_PARENT_SETTID: u64 = 0x0010_0000;
pub const CLONE_CHILD_CLEARTID:u64 = 0x0020_0000;
pub const CLONE_CHILD_SETTID:  u64 = 0x0100_0000;

// Kernel stack size per thread
pub const KSTACK_SIZE: usize = 16 * 1024; // 16 KiB

// ── Allocate a kernel stack ───────────────────────────────────────────────

fn alloc_kstack() -> Option<usize> {
    let pages = KSTACK_SIZE / PAGE_SIZE;
    let base = pmm::alloc_pages(pages)?;
    // Map into kernel address space (already identity-mapped in our layout)
    Some(base)
}

// ── Clone implementation ──────────────────────────────────────────────────

/// Perform a clone/fork.
///
/// `child_rsp` — user stack pointer for the new thread (0 = copy parent rsp)
/// `flags`     — CLONE_* bitmask
/// `ptid`      — parent TID pointer (CLONE_PARENT_SETTID)
/// `ctid`      — child TID pointer  (CLONE_CHILD_SETTID / CLONE_CHILD_CLEARTID)
/// `tls`       — FS base for new thread (CLONE_SETTLS)
/// `parent_ctx`— current CPU register state to copy into child
///
/// Returns child TID to parent, 0 to child (via scheduler).
pub fn do_clone(
    flags: u64,
    child_rsp: usize,
    ptid: usize,
    ctid: usize,
    tls: usize,
    parent_ctx: &Context,
    parent_rip: usize,
    parent_rax: usize,
) -> isize
{
    let kstack = match alloc_kstack() { Some(s) => s, None => return -12 };
    let kstack_top = kstack + KSTACK_SIZE;

    let new_tid = crate::proc::scheduler::next_tid();
    let parent_tid  = crate::proc::scheduler::current_tid();
    let parent_tgid = crate::proc::scheduler::current_tgid();

    // Determine TGID: same group if CLONE_THREAD, else new group
    let tgid = if flags & CLONE_THREAD != 0 { parent_tgid } else { new_tid };

    // Copy context; child returns 0 from clone()
    let mut child_ctx = *parent_ctx;
    child_ctx.rax = 0; // child sees return value 0
    child_ctx.rip = parent_rip;
    child_ctx.rsp = if child_rsp != 0 { child_rsp } else { parent_ctx.rsp };

    // PML4: share if CLONE_VM, else COW-copy
    let mm_root = if flags & CLONE_VM != 0 {
        crate::proc::scheduler::current_mm_root()
    } else {
        crate::proc::cow_fault::copy_address_space(
            crate::proc::scheduler::current_mm_root()
        )
    };

    let mut name = [0u8; 16];
    let pname = crate::proc::scheduler::current_name();
    name[..pname.len().min(15)].copy_from_slice(&pname[..pname.len().min(15)]);

    let thread = Thread {
        tid: new_tid, tgid, ppid: parent_tid,
        state: ThreadState::Ready,
        exit_code: 0,
        ctx: child_ctx,
        kstack, kstack_top,
        fs_base: if flags & CLONE_SETTLS != 0 { tls } else { 0 },
        mm_root,
        name,
        futex_addr: None, futex_val: 0,
        detached: false, join_tid: None,
    };

    // Write TIDs to user pointers
    if flags & CLONE_PARENT_SETTID != 0 && ptid != 0 {
        unsafe { *(ptid as *mut u32) = new_tid; }
    }
    if flags & (CLONE_CHILD_SETTID | CLONE_CHILD_CLEARTID) != 0 && ctid != 0 {
        unsafe { *(ctid as *mut u32) = new_tid; }
        // Store ctid VA so we can clear it on thread exit
        // (stored in thread after enqueue)
    }

    let child_tid = new_tid;
    crate::proc::scheduler::enqueue_thread(thread);

    crate::serial_println!("[clone] tid={} tgid={} flags={:#x}", child_tid, tgid, flags);
    child_tid as isize
}

// ── sys_clone entry (called from syscall dispatch) ────────────────────────

/// Linux x86-64 clone calling convention:
///   rdi=flags  rsi=child_stack  rdx=ptid  r10=ctid  r8=tls
pub fn sys_clone(flags: u64, child_stack: usize, ptid: usize,
                 ctid: usize, tls: usize,
                 ctx: &Context, rip: usize) -> isize
{
    do_clone(flags, child_stack, ptid, ctid, tls, ctx, rip, 0)
}
