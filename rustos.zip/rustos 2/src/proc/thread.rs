//! Kernel thread (task) — one schedulable unit.
//!
//! A POSIX process is a group of threads sharing:
//!   - Virtual address space (PML4 root)
//!   - File descriptor table
//!   - Signal dispositions
//!   - Thread group ID (TGID = PID of the leader)
//!
//! Each thread has its own:
//!   - TID (unique kernel task id)
//!   - Kernel stack
//!   - CPU register context
//!   - Thread-local storage FS base (set via arch_prctl ARCH_SET_FS)
//!   - Futex wait state
//!   - Detach state + exit value for pthread_join

extern crate alloc;
use alloc::sync::Arc;
use spin::Mutex;
use crate::proc::context::Context;
use crate::proc::signal::SigState;

// ── Thread state ──────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ThreadState {
    Ready,
    Running,
    Blocked,        // sleeping on futex / I/O
    WaitingChild,   // in waitpid()
    Zombie,         // exited, waiting for join/reap
}

// ── Thread control block ──────────────────────────────────────────────────

pub struct Thread {
    pub tid:       u32,          // unique thread ID
    pub tgid:      u32,          // thread group ID (== process PID)
    pub ppid:      u32,          // parent PID (thread group leader)

    pub state:     ThreadState,
    pub exit_code: i32,

    // CPU state
    pub ctx:       Context,      // callee-saved registers
    pub kstack:    usize,        // kernel stack base (8 KiB)
    pub kstack_top:usize,        // rsp when entering kernel
    pub fs_base:   usize,        // TLS pointer (FS segment base)

    // Shared resources (Arc = shared between threads in same process)
    pub mm_root:   usize,        // PML4 physical address
    pub name:      [u8; 16],

    // Futex
    pub futex_addr: Option<usize>,// waiting on this VA
    pub futex_val:  u32,

    // join / detach
    pub detached:  bool,
    pub join_tid:  Option<u32>,  // TID waiting to join us
}

impl Thread {
    /// Snapshot for /proc/<tid>/status reads.
    pub fn name_str(&self) -> &str {
        let end = self.name.iter().position(|&b| b==0).unwrap_or(16);
        core::str::from_utf8(&self.name[..end]).unwrap_or("?")
    }
    pub fn state_str(&self) -> &'static str {
        match self.state {
            ThreadState::Ready        => "R (running)",
            ThreadState::Running      => "R (running)",
            ThreadState::Blocked      => "S (sleeping)",
            ThreadState::WaitingChild => "S (sleeping)",
            ThreadState::Zombie       => "Z (zombie)",
        }
    }
    pub fn rss_kb(&self) -> usize {
        // Approximate: count mapped pages (future: walk PML4)
        64
    }
}
