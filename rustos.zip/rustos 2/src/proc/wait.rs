//! waitpid() implementation.
//!
//! A process that calls waitpid() either:
//!   - Finds a Zombie child  → collects exit code, frees PCB, returns PID.
//!   - Finds no child at all → returns -ECHILD.
//!   - Finds living children and WNOHANG is set → returns 0.
//!   - Finds living children and WNOHANG is clear → blocks (state=Blocked)
//!     until a SIGCHLD wakes it (see scheduler::reap).
//!
//! The scheduler's `exit()` path:
//!   1. Marks the process Zombie (does NOT free pages yet).
//!   2. Sends SIGCHLD to the parent.
//!   3. Wakes any Blocked parent waiting on this child.

use crate::proc::{process::State, scheduler};

pub const WNOHANG: usize = 1;

/// Collect status of child `target_pid` (0 = any child).
/// `status_va` — user-space `int *` to receive packed wait status; may be 0.
pub fn sys_waitpid(target_pid: i32, status_va: usize, options: usize) -> isize {
    let caller_pid = scheduler::current_pid();

    loop {
        // Check for a zombie matching our request.
        let found = {
            let mut procs = scheduler::procs_lock();
            let zombie_idx = procs.iter().position(|p| {
                p.ppid == caller_pid
                && p.state == State::Zombie
                && (target_pid <= 0 || p.pid == target_pid as u32)
            });

            if let Some(idx) = zombie_idx {
                let child = procs.remove(idx);
                Some((child.pid, child.exit_code))
            } else {
                None
            }
        };

        if let Some((child_pid, exit_code)) = found {
            // Write packed wait status to user space if requested.
            if status_va != 0 {
                // Linux encoding: (exit_code & 0xFF) << 8
                let wstatus: i32 = ((exit_code as i32) & 0xFF) << 8;
                let bytes = wstatus.to_le_bytes();
                let _ = crate::uaccess::copy_to_user(status_va, &bytes);
            }
            // Free the zombie's pages now that we've collected status.
            scheduler::reap_zombie(child_pid);
            return child_pid as isize;
        }

        // No zombie yet — do we have living children at all?
        let has_children = {
            let procs = scheduler::procs_lock();
            procs.iter().any(|p| {
                p.ppid == caller_pid
                && (target_pid <= 0 || p.pid == target_pid as u32)
            })
        };

        if !has_children {
            return -10; // ECHILD
        }

        if options & WNOHANG != 0 {
            return 0;
        }

        // Block until SIGCHLD wakes us.
        {
            let mut procs = scheduler::procs_lock();
            if let Some(p) = procs.iter_mut().find(|p| p.pid == caller_pid) {
                p.state = State::Blocked;
                p.wait_for_pid = if target_pid > 0 { target_pid as u32 } else { 0 };
            }
        }
        // Yield — the scheduler will run other processes.
        // When SIGCHLD arrives and we're unblocked, the loop retries.
        scheduler::current_yield();
    }
}
