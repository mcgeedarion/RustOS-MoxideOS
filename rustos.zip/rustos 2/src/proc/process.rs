//! Process Control Block (PCB) — x86_64 + RISC-V.

extern crate alloc;
use alloc::vec::Vec;

use crate::mm::pmm::{self, PAGE_SIZE};
use crate::proc::context::Context;
use crate::proc::signal::SigState;
use crate::security::CapSet;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State {
    Ready,
    Running,
    Blocked,
    Zombie,
}

pub struct Pcb {
    pub pid:          u32,
    pub ppid:         u32,
    pub state:        State,
    pub exit_code:    i32,
    pub caps:         CapSet,
    pub pc:           usize,
    pub sp:           usize,
    pub kernel_satp:  usize,  // CR3 on x86_64; kernel satp on RISC-V
    pub user_satp:    usize,  // user CR3 / satp
    pub trapframe_pa: usize,
    pub ctx:          Context,
    pub kstack_top:   usize,
    pub owned_pages:  Vec<usize>,
    // ── Signal state ───────────────────────────────────────────────────────
    pub signals:      SigState,
    /// VA of the sigreturn trampoline page mapped into this process.
    pub sigreturn_va: u64,
    // ── Wait state ─────────────────────────────────────────────────────────
    /// PID we're waiting for in waitpid(); 0 = any child.
    pub wait_for_pid: u32,
}

impl Pcb {
    pub fn new(pid: u32, ppid: u32) -> Self {
        Self {
            pid, ppid,
            state:        State::Ready,
            exit_code:    0,
            caps:         CapSet::empty(),
            pc:           0,
            sp:           0,
            kernel_satp:  0,
            user_satp:    0,
            trapframe_pa: 0,
            ctx:          Context::zero(),
            kstack_top:   0,
            owned_pages:  Vec::new(),
            signals:      SigState::new(),
            sigreturn_va: 0,
            wait_for_pid: 0,
        }
    }

    /// x86_64 ELF loader — allocates page tables, maps segments, returns
    /// (entry_va, user_rsp).
    #[cfg(target_arch = "x86_64")]
    pub fn load_elf(&mut self, data: &[u8]) -> Result<(usize, usize), &'static str> {
        use crate::arch::x86_64::paging as pg;
        use crate::proc::fork::load_elf_into_pub;
        let cr3 = pmm::alloc_page().ok_or("OOM: user CR3")?;
        unsafe { core::ptr::write_bytes(cr3 as *mut u8, 0, PAGE_SIZE); }
        self.owned_pages.push(cr3);
        pg::install_kernel_entries(cr3);

        // Map sigreturn trampoline page
        let trampoline_pa = pmm::alloc_page().ok_or("OOM: trampoline")?;
        unsafe { core::ptr::write_bytes(trampoline_pa as *mut u8, 0, PAGE_SIZE); }
        // Write `syscall; ud2` bytes (SYS_SIGRETURN = 139 on Linux x86-64)
        let tramp = trampoline_pa as *mut u8;
        unsafe {
            tramp.write(0xB8); tramp.add(1).write(139); tramp.add(2).write(0);
            tramp.add(3).write(0); tramp.add(4).write(0); // mov eax, 139
            tramp.add(5).write(0x0F); tramp.add(6).write(0x05); // syscall
            tramp.add(7).write(0x0F); tramp.add(8).write(0x0B); // ud2
        }
        const TRAMPOLINE_VA: usize = 0x7FFF_FFFF_F000;
        pg::map_user_page(cr3, TRAMPOLINE_VA, trampoline_pa);
        self.owned_pages.push(trampoline_pa);
        self.sigreturn_va = TRAMPOLINE_VA as u64;

        let (entry, rsp) = load_elf_into_pub(data, cr3, &mut self.owned_pages)?;
        self.user_satp   = cr3;
        self.kernel_satp = cr3;
        self.pc          = entry;
        self.sp          = rsp;
        Ok((entry, rsp))
    }

    /// RISC-V ELF loader (unchanged from previous iteration).
    #[cfg(target_arch = "riscv64")]
    pub fn load_elf(&mut self, data: &[u8]) -> Result<(), &'static str> {
        use crate::arch::riscv64::paging::PteFlags;
        use crate::elf;
        use crate::mm::vmm;
        let root_pa = pmm::alloc_page().ok_or("OOM: user satp")?;
        unsafe { core::ptr::write_bytes(root_pa as *mut u8, 0, PAGE_SIZE); }
        self.owned_pages.push(root_pa);
        vmm::install_kernel_entries(root_pa);
        let loaded = elf::load(data, root_pa, &mut self.owned_pages)?;
        // User stack
        const USTACK_TOP: usize = 0x0000_0040_0000_0000;
        const USTACK_PAGES: usize = 4;
        for i in 0..USTACK_PAGES {
            let pa = pmm::alloc_page().ok_or("OOM: stack")?;
            unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
            self.owned_pages.push(pa);
            vmm::map_page(root_pa, USTACK_TOP - (USTACK_PAGES - i) * PAGE_SIZE, pa,
                          PteFlags::R | PteFlags::W | PteFlags::U);
        }
        self.user_satp   = crate::arch::riscv64::csr::make_satp(root_pa);
        self.kernel_satp = 0;
        self.pc          = loaded.entry;
        self.sp          = USTACK_TOP - 16;
        Ok(())
    }
}

/// Lightweight snapshot for /proc reads (avoids holding scheduler lock).
pub struct PcbSnapshot {
    pub pid:   u32,
    pub ppid:  u32,
    pub state: State,
    pub name:  [u8; 16],
    pub pages: usize,
}

impl PcbSnapshot {
    pub fn name(&self) -> &str {
        let end = self.name.iter().position(|&b| b == 0).unwrap_or(16);
        core::str::from_utf8(&self.name[..end]).unwrap_or("?")
    }
    pub fn state_str(&self) -> &'static str {
        match self.state {
            State::Ready   => "R (running)",
            State::Running => "R (running)",
            State::Blocked => "S (sleeping)",
            State::Zombie  => "Z (zombie)",
        }
    }
    pub fn rss_kb(&self) -> usize { self.pages * 4 }  // 4 KiB pages
}
