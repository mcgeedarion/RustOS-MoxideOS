//! PCIe ECAM config space helper
const ECAM_BASE: usize = 0x3000_0000;

pub fn cfg_read32(bus: u8, dev: u8, func: u8, offset: u16) -> u32 {
    let addr = ECAM_BASE
        | ((bus  as usize) << 20)
        | ((dev  as usize) << 15)
        | ((func as usize) << 12)
        | ((offset as usize) & 0xFFC);
    unsafe { (addr as *const u32).read_volatile() }
}

pub fn cfg_write32(bus: u8, dev: u8, func: u8, offset: u16, val: u32) {
    let addr = ECAM_BASE
        | ((bus  as usize) << 20)
        | ((dev  as usize) << 15)
        | ((func as usize) << 12)
        | ((offset as usize) & 0xFFC);
    unsafe { (addr as *mut u32).write_volatile(val); }
}
