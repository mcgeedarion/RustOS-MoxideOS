//! TTY line discipline.
//!
//! Provides a thin layer between the serial UART and userspace fd 0/1/2:
//!   - Canonical mode: buffer input until LF, handle BS/DEL, echo chars
//!   - Raw mode: deliver each byte immediately (no echo, no special chars)
//!   - `ioctl` hooks: TCGETS / TCSETS / TIOCGWINSZ / TIOCSWINSZ
//!
//! The global TTY is the system console (serial UART).  Per-process tty
//! tracking (controlling terminal, session groups) is a future extension.

extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;
use crate::drivers::uart;

// ── termios ───────────────────────────────────────────────────────────────

/// Subset of Linux struct termios (enough for musl readline / bash).
#[derive(Clone, Copy)]
pub struct Termios {
    pub c_iflag: u32,
    pub c_oflag: u32,
    pub c_cflag: u32,
    pub c_lflag: u32,
    pub c_cc:    [u8; 19],
}

pub const ICANON:  u32 = 0o0002;  // canonical mode
pub const ECHO:    u32 = 0o0010;  // echo input
pub const ISIG:    u32 = 0o0001;  // signals (SIGINT etc)
pub const OPOST:   u32 = 0o0001;  // output processing
pub const CS8:     u32 = 0o0060;
pub const CREAD:   u32 = 0o0200;
pub const HUPCL:   u32 = 0o0400;
pub const CLOCAL:  u32 = 0o4000;
pub const B38400:  u32 = 0o0017;

impl Default for Termios {
    fn default() -> Self {
        let mut cc = [0u8; 19];
        cc[4] = 1;   // VMIN = 1
        cc[5] = 0;   // VTIME = 0
        cc[2] = 3;   // VINTR = ^C
        cc[3] = 28;  // VQUIT = ^\
        cc[7] = 8;   // VERASE = BS
        cc[0] = 4;   // VEOF = ^D
        Termios {
            c_iflag: 0x4B2,  // ICRNL | IXON
            c_oflag: OPOST,
            c_cflag: B38400 | CS8 | CREAD | HUPCL | CLOCAL,
            c_lflag: ICANON | ECHO | ISIG,
            c_cc:    cc,
        }
    }
}

// ── Window size ───────────────────────────────────────────────────────────

#[derive(Clone, Copy)]
pub struct Winsize { pub rows: u16, pub cols: u16, pub xpixel: u16, pub ypixel: u16 }

static WINSIZE: Mutex<Winsize> = Mutex::new(Winsize { rows: 24, cols: 80, xpixel: 0, ypixel: 0 });
static TERMIOS: Mutex<Termios> = Mutex::new(Termios {
    c_iflag: 0x4B2, c_oflag: 1, c_cflag: 0o17 | 0o60 | 0o200 | 0o400 | 0o4000,
    c_lflag: 0o0002 | 0o0010 | 0o0001,
    c_cc:    [4,0,3,28,0,0,0,8,0,0,0,0,0,0,0,0,0,1,0],
});

// ── Input line buffer (canonical mode) ───────────────────────────────────

struct LineBuffer { buf: [u8; 512], len: usize, ready: bool }
static LINE_BUF: Mutex<LineBuffer> = Mutex::new(LineBuffer { buf: [0;512], len: 0, ready: false });

/// Called from UART IRQ handler on each received byte.
pub fn on_uart_byte(b: u8) {
    let term = *TERMIOS.lock();
    let canonical = term.c_lflag & ICANON != 0;
    let echo_on   = term.c_lflag & ECHO   != 0;
    let sig_on    = term.c_lflag & ISIG   != 0;

    if sig_on {
        if b == term.c_cc[2] { // VINTR = ^C
            crate::proc::signal::send_foreground(crate::proc::signal::SIGINT);
            return;
        }
        if b == term.c_cc[3] { // VQUIT = ^\
            crate::proc::signal::send_foreground(crate::proc::signal::SIGQUIT);
            return;
        }
    }

    if canonical {
        let erase = term.c_cc[7]; // VERASE
        let eof   = term.c_cc[0]; // VEOF  = ^D
        let mut lb = LINE_BUF.lock();
        if b == erase || b == 0x7F { // backspace / DEL
            if lb.len > 0 {
                lb.len -= 1;
                if echo_on { uart::puts("\x08 \x08"); }
            }
        } else if b == eof && lb.len == 0 {
            lb.ready = true; // EOF condition: read returns 0
        } else {
            if lb.len < 511 { lb.buf[lb.len] = b; lb.len += 1; }
            if echo_on { uart::putc(b); }
            if b == b'\n' || b == b'\r' { lb.ready = true; }
        }
    } else {
        // Raw mode: push directly to a raw byte queue (simplified: reuse line buf)
        let mut lb = LINE_BUF.lock();
        if lb.len < 511 { lb.buf[lb.len] = b; lb.len += 1; lb.ready = true; }
        if echo_on { uart::putc(b); }
    }
}

/// Read up to `n` bytes from the TTY input.
/// Blocks (spins + polls net) until at least 1 byte is available.
pub fn read(buf: &mut [u8]) -> usize {
    let n = buf.len();
    loop {
        {
            let mut lb = LINE_BUF.lock();
            if lb.ready && lb.len > 0 {
                let take = n.min(lb.len);
                buf[..take].copy_from_slice(&lb.buf[..take]);
                // Shift remaining bytes
                lb.buf.copy_within(take..lb.len, 0);
                lb.len -= take;
                if lb.len == 0 { lb.ready = false; }
                return take;
            }
            if lb.ready && lb.len == 0 { lb.ready = false; return 0; } // EOF
        }
        core::hint::spin_loop();
        crate::net::poll();
    }
}

// ── ioctl numbers (Linux x86-64) ──────────────────────────────────────────

pub const TCGETS:     usize = 0x5401;
pub const TCSETS:     usize = 0x5402;
pub const TCSETSW:    usize = 0x5403;
pub const TCSETSF:    usize = 0x5404;
pub const TIOCGWINSZ: usize = 0x5413;
pub const TIOCSWINSZ: usize = 0x5414;
pub const TIOCGPGRP:  usize = 0x540F;
pub const TIOCSPGRP:  usize = 0x5410;

/// Handle an ioctl on fd 0/1/2 (the TTY).
/// `arg` is a user-space virtual address.
pub fn ioctl(request: usize, arg: usize) -> isize {
    match request {
        TCGETS => {
            let t = *TERMIOS.lock();
            let bytes = unsafe {
                core::slice::from_raw_parts(&t as *const Termios as *const u8,
                    core::mem::size_of::<Termios>())
            };
            if arg == 0 { return -14; }
            unsafe { core::ptr::copy_nonoverlapping(bytes.as_ptr(), arg as *mut u8, bytes.len()); }
            0
        }
        TCSETS | TCSETSW | TCSETSF => {
            if arg == 0 { return -14; }
            let mut t = Termios::default();
            let bytes = unsafe {
                core::slice::from_raw_parts_mut(&mut t as *mut Termios as *mut u8,
                    core::mem::size_of::<Termios>())
            };
            unsafe { core::ptr::copy_nonoverlapping(arg as *const u8, bytes.as_mut_ptr(), bytes.len()); }
            *TERMIOS.lock() = t;
            0
        }
        TIOCGWINSZ => {
            let w = *WINSIZE.lock();
            let bytes = unsafe {
                core::slice::from_raw_parts(&w as *const Winsize as *const u8,
                    core::mem::size_of::<Winsize>())
            };
            if arg == 0 { return -14; }
            unsafe { core::ptr::copy_nonoverlapping(bytes.as_ptr(), arg as *mut u8, bytes.len()); }
            0
        }
        TIOCSWINSZ => {
            if arg == 0 { return -14; }
            let mut w = Winsize { rows:0, cols:0, xpixel:0, ypixel:0 };
            let bytes = unsafe {
                core::slice::from_raw_parts_mut(&mut w as *mut Winsize as *mut u8,
                    core::mem::size_of::<Winsize>())
            };
            unsafe { core::ptr::copy_nonoverlapping(arg as *const u8, bytes.as_mut_ptr(), bytes.len()); }
            *WINSIZE.lock() = w;
            0
        }
        TIOCGPGRP => { if arg != 0 { unsafe { *(arg as *mut u32) = 1; } } 0 }
        TIOCSPGRP => 0,
        _ => -25, // ENOTTY
    }
}
