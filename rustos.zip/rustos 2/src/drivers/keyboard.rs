//! High-level keyboard driver (wraps PS/2 or evdev)
use crate::input::InputEvent;

pub fn poll() -> Option<InputEvent> {
    crate::drivers::ps2::poll()
        .or_else(|| crate::drivers::evdev::poll())
}
