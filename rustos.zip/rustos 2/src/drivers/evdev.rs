//! Generic evdev-style input driver
use crate::input::{InputEvent, EV_KEY};

static mut MMIO_BASE: usize = 0;

pub fn set_base(base: usize) {
    unsafe { MMIO_BASE = base; }
}

pub fn poll() -> Option<InputEvent> {
    let base = unsafe { MMIO_BASE };
    if base == 0 { return None; }
    let status = unsafe { (base as *const u32).read_volatile() };
    if status & 1 == 0 { return None; } // no event pending
    let kind  = unsafe { ((base + 4)  as *const u16).read_volatile() };
    let code  = unsafe { ((base + 6)  as *const u16).read_volatile() };
    let value = unsafe { ((base + 8)  as *const u32).read_volatile() };
    // Acknowledge
    unsafe { (base as *mut u32).write_volatile(0); }
    Some(InputEvent { kind, code, value })
}
