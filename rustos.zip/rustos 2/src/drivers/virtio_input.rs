//! VirtIO input device driver stub
use crate::input::InputEvent;

pub fn poll() -> Option<InputEvent> { None }
