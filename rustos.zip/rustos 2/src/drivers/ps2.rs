//! PS/2 keyboard driver
use crate::input::{InputEvent, EV_KEY};

const DATA_PORT:   usize = 0x0300_0060;
const STATUS_PORT: usize = 0x0300_0064;

fn inb(port: usize) -> u8 {
    unsafe { (port as *const u8).read_volatile() }
}

pub fn poll() -> Option<InputEvent> {
    let status = inb(STATUS_PORT);
    if status & 0x01 == 0 { return None; } // output buffer empty

    let scancode = inb(DATA_PORT);

    // Handle Set-2 key release prefix (0xF0)
    static mut RELEASE: bool = false;
    let (code, value) = unsafe {
        if scancode == 0xF0 {
            RELEASE = true;
            return None;
        }
        let v = if RELEASE { 0u32 } else { 1u32 };
        RELEASE = false;
        (scancode as u16, v)
    };

    Some(InputEvent { kind: EV_KEY, code, value })
}
