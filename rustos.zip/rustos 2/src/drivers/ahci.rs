//! AHCI SATA driver stub
use crate::block::BlockDev;

pub struct AhciDisk { pub base: usize }

impl BlockDev for AhciDisk {
    fn read_block(&self, _lba: u64, _buf: &mut [u8]) -> Result<(), &'static str> {
        Err("AHCI not yet implemented")
    }
    fn write_block(&self, _lba: u64, _buf: &[u8]) -> Result<(), &'static str> {
        Err("AHCI not yet implemented")
    }
}
