//! RISC-V Platform-Level Interrupt Controller
const PLIC_BASE: usize = 0x0C00_0000;

pub fn init() {
    // Enable all interrupt sources at priority 1 for context 0
    unsafe {
        for src in 1usize..32 {
            let prio_reg = (PLIC_BASE + src * 4) as *mut u32;
            prio_reg.write_volatile(1);
        }
        // Enable bits for context 0
        let enable_reg = (PLIC_BASE + 0x2000) as *mut u32;
        enable_reg.write_volatile(0xFFFF_FFFE);
        // Set priority threshold to 0
        let threshold_reg = (PLIC_BASE + 0x20_0000) as *mut u32;
        threshold_reg.write_volatile(0);
    }
}

pub fn claim() -> u32 {
    unsafe { ((PLIC_BASE + 0x20_0004) as *mut u32).read_volatile() }
}

pub fn complete(irq: u32) {
    unsafe { ((PLIC_BASE + 0x20_0004) as *mut u32).write_volatile(irq); }
}
