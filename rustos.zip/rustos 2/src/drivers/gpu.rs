//! GPU driver stub
pub fn init() {}
