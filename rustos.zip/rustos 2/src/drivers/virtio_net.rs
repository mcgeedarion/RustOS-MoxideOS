//! VirtIO network device driver (PCI legacy, split virtqueue).
//!
//! Virtqueue layout:
//!   Queue 0 = RX  (device writes received packets here)
//!   Queue 1 = TX  (driver writes packets to send here)
//!
//! Each RX descriptor is pre-filled with a free page so the device has
//! somewhere to DMA incoming frames.  TX is fully synchronous (polled).
//!
//! Spec: VirtIO 1.2 §5.1

extern crate alloc;
use alloc::vec::Vec;
use core::sync::atomic::{fence, Ordering};
use spin::Mutex;
use crate::mm::pmm::{self, PAGE_SIZE};

// ── PCI helpers (reuse from virtio_blk) ──────────────────────────────────

fn pci_find(vendor: u16, device_ids: &[u16]) -> Option<u16> {
    for dev in 0u8..32 {
        let id = pci_read32(0, dev, 0, 0);
        if id == 0xFFFF_FFFF { continue; }
        let v = (id & 0xFFFF) as u16;
        let d = (id >> 16)    as u16;
        if v == vendor && device_ids.contains(&d) {
            let cmd = pci_read32(0, dev, 0, 4) as u16;
            pci_write32(0, dev, 0, 4, (cmd | 0x5) as u32);
            return Some((pci_read32(0, dev, 0, 0x10) & !3) as u16);
        }
    }
    None
}

fn pci_read32(bus: u8, dev: u8, func: u8, off: u8) -> u32 {
    let addr = 0x8000_0000u32 | (bus as u32) << 16 | (dev as u32) << 11
             | (func as u32) << 8 | (off & 0xFC) as u32;
    unsafe {
        core::arch::asm!("out dx, eax", in("dx") 0xCF8u16, in("eax") addr);
        let v: u32;
        core::arch::asm!("in eax, dx", in("dx") 0xCFCu16, out("eax") v);
        v
    }
}
fn pci_write32(bus: u8, dev: u8, func: u8, off: u8, val: u32) {
    let addr = 0x8000_0000u32 | (bus as u32) << 16 | (dev as u32) << 11
             | (func as u32) << 8 | (off & 0xFC) as u32;
    unsafe {
        core::arch::asm!("out dx, eax", in("dx") 0xCF8u16, in("eax") addr);
        core::arch::asm!("out dx, eax", in("dx") 0xCFCu16, in("eax") val);
    }
}

// ── I/O port wrappers ─────────────────────────────────────────────────────

fn inb(p: u16) -> u8   { unsafe { let v; core::arch::asm!("in al,dx",in("dx")p,out("al")v); v } }
fn outb(p:u16,v:u8)    { unsafe { core::arch::asm!("out dx,al",in("dx")p,in("al")v); } }
fn inl(p: u16) -> u32  { unsafe { let v; core::arch::asm!("in eax,dx",in("dx")p,out("eax")v); v } }
fn outl(p:u16,v:u32)   { unsafe { core::arch::asm!("out dx,eax",in("dx")p,in("eax")v); } }

// ── Virtqueue ─────────────────────────────────────────────────────────────

const QUEUE_SIZE: usize = 64;
const VNET_HDR_SIZE: usize = 12; // virtio_net_hdr (no GSO fields needed)

#[repr(C, align(16))]
struct Desc { addr: u64, len: u32, flags: u16, next: u16 }
const VDESC_F_NEXT:  u16 = 1;
const VDESC_F_WRITE: u16 = 2;

#[repr(C, align(2))]
struct Avail { flags: u16, idx: u16, ring: [u16; QUEUE_SIZE] }
#[repr(C, align(4))]
struct Used  { flags: u16, idx: u16, ring: [UsedElem; QUEUE_SIZE] }
#[repr(C)] struct UsedElem { id: u32, len: u32 }

struct Queue {
    desc_pa:  usize,
    avail_pa: usize,
    used_pa:  usize,
    last_used: u16,
    next_free: u16,
}

impl Queue {
    fn desc(&self)  -> *mut Desc  { self.desc_pa  as *mut Desc  }
    fn avail(&self) -> *mut Avail { self.avail_pa as *mut Avail }
    fn used(&self)  -> *mut Used  { self.used_pa  as *mut Used  }

    fn push_avail(&self, head: u16) {
        unsafe {
            let idx = (*self.avail()).idx;
            (*self.avail()).ring[idx as usize % QUEUE_SIZE] = head;
            fence(Ordering::Release);
            (*self.avail()).idx = idx.wrapping_add(1);
        }
    }

    fn alloc_pages() -> (usize, usize, usize) {
        let dp = pmm::alloc_page().expect("OOM: vq desc");
        let ap = pmm::alloc_page().expect("OOM: vq avail");
        let up = pmm::alloc_page().expect("OOM: vq used");
        unsafe {
            core::ptr::write_bytes(dp as *mut u8, 0, PAGE_SIZE);
            core::ptr::write_bytes(ap as *mut u8, 0, PAGE_SIZE);
            core::ptr::write_bytes(up as *mut u8, 0, PAGE_SIZE);
        }
        (dp, ap, up)
    }
}

// ── virtio_net_hdr ────────────────────────────────────────────────────────

#[repr(C)]
struct VnetHdr {
    flags:       u8,
    gso_type:    u8,
    hdr_len:     u16,
    gso_size:    u16,
    csum_start:  u16,
    csum_offset: u16,
    num_buffers: u16, // only present when VIRTIO_NET_F_MRG_RXBUF set
}

// ── Driver state ──────────────────────────────────────────────────────────

struct NetDev {
    iobase: u16,
    mac:    [u8; 6],
    rxq:    Queue,
    txq:    Queue,
    // RX bounce buffers (one per descriptor)
    rx_bufs: Vec<usize>,  // physical addresses
}

static NETDEV: Mutex<Option<NetDev>> = Mutex::new(None);

const REG_STATUS:  u16 = 0x12;
const REG_QSELECT: u16 = 0x0E;
const REG_QSIZE:   u16 = 0x0C;
const REG_QADDR:   u16 = 0x08;
const REG_QNOTIFY: u16 = 0x10;
const REG_DRVFEAT: u16 = 0x04;
const REG_ISR:     u16 = 0x13;
const ST_ACK: u8 = 1; const ST_DRV: u8 = 2;
const ST_FOK: u8 = 8; const ST_DOK: u8 = 4;

pub fn init() {
    let iobase = match pci_find(0x1AF4, &[0x1000, 0x1041]) {
        Some(b) => b,
        None    => { crate::serial_println!("[virtio-net] not found"); return; }
    };

    // Reset + feature negotiation
    outb(iobase + REG_STATUS, 0);
    outb(iobase + REG_STATUS, ST_ACK);
    outb(iobase + REG_STATUS, ST_ACK | ST_DRV);
    outl(iobase + REG_DRVFEAT, 0);  // no optional features
    outb(iobase + REG_STATUS, ST_ACK | ST_DRV | ST_FOK);

    // Read MAC from device-specific config (offset 0x14 in BAR0 for legacy)
    let mac = [
        inb(iobase + 0x14), inb(iobase + 0x15), inb(iobase + 0x16),
        inb(iobase + 0x17), inb(iobase + 0x18), inb(iobase + 0x19),
    ];

    // Set up RX queue (index 0)
    let rxq = setup_queue(iobase, 0);
    // Set up TX queue (index 1)
    let txq = setup_queue(iobase, 1);

    outb(iobase + REG_STATUS, ST_ACK | ST_DRV | ST_FOK | ST_DOK);

    // Pre-fill RX descriptors with bounce pages
    let mut rx_bufs = Vec::with_capacity(QUEUE_SIZE);
    for i in 0..QUEUE_SIZE {
        let pa = pmm::alloc_page().expect("OOM: rx buf");
        unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
        rx_bufs.push(pa);
        unsafe {
            // Two-descriptor chain: [0]=vnet_hdr (write) → [1]=payload (write)
            let di = i * 2;
            (*rxq.desc()).add(di).write(Desc {
                addr:  pa as u64,
                len:   VNET_HDR_SIZE as u32,
                flags: VDESC_F_WRITE | VDESC_F_NEXT,
                next:  (di + 1) as u16,
            });
            (*rxq.desc()).add(di + 1).write(Desc {
                addr:  (pa + VNET_HDR_SIZE) as u64,
                len:   (PAGE_SIZE - VNET_HDR_SIZE) as u32,
                flags: VDESC_F_WRITE,
                next:  0,
            });
            rxq.push_avail(di as u16);
        }
    }
    // Notify device about RX descriptors
    outl(iobase + REG_QNOTIFY, 0);

    crate::serial_println!("[virtio-net] MAC {:02x}:{:02x}:{:02x}:{:02x}:{:02x}:{:02x}",
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);

    *NETDEV.lock() = Some(NetDev { iobase, mac, rxq, txq, rx_bufs });
}

fn setup_queue(iobase: u16, index: u32) -> Queue {
    outl(iobase + REG_QSELECT, index);
    outl(iobase + REG_QSIZE, QUEUE_SIZE as u32);
    let (dp, ap, up) = Queue::alloc_pages();
    // Legacy: queue PFN (4 KiB pages)
    outl(iobase + REG_QADDR, (dp >> 12) as u32);
    Queue { desc_pa: dp, avail_pa: ap, used_pa: up, last_used: 0, next_free: 0 }
}

// ── TX ────────────────────────────────────────────────────────────────────

/// Send a raw Ethernet frame.
pub fn send(frame: &[u8]) -> bool {
    let mut guard = NETDEV.lock();
    let dev = match guard.as_mut() { Some(d) => d, None => return false };

    let hdr = VnetHdr { flags:0, gso_type:0, hdr_len:0, gso_size:0,
                         csum_start:0, csum_offset:0, num_buffers:1 };
    let hdr_pa = &hdr as *const VnetHdr as usize;
    let pay_pa  = frame.as_ptr() as usize;
    let di = dev.txq.next_free as usize;

    unsafe {
        (*dev.txq.desc()).add(di).write(Desc {
            addr: hdr_pa as u64, len: VNET_HDR_SIZE as u32,
            flags: VDESC_F_NEXT, next: (di+1) as u16,
        });
        (*dev.txq.desc()).add(di+1).write(Desc {
            addr: pay_pa as u64, len: frame.len() as u32,
            flags: 0, next: 0,
        });
        dev.txq.push_avail(di as u16);
    }
    dev.txq.next_free = ((di + 2) % QUEUE_SIZE) as u16;
    outl(dev.iobase + REG_QNOTIFY, 1); // notify TX queue

    // Poll for completion
    let used = dev.txq.used_pa as *mut Used;
    for _ in 0..100_000 {
        fence(Ordering::Acquire);
        if unsafe { (*used).idx } != dev.txq.last_used { break; }
        core::hint::spin_loop();
    }
    dev.txq.last_used = dev.txq.last_used.wrapping_add(1);
    true
}

// ── RX ────────────────────────────────────────────────────────────────────

/// Poll for a received frame.  Returns a copy in a Vec, or None.
pub fn recv() -> Option<Vec<u8>> {
    let mut guard = NETDEV.lock();
    let dev = guard.as_mut()?;
    let used = dev.rxq.used_pa as *mut Used;
    fence(Ordering::Acquire);
    if unsafe { (*used).idx } == dev.rxq.last_used { return None; }

    let elem = unsafe { (*used).ring[dev.rxq.last_used as usize % QUEUE_SIZE] };
    dev.rxq.last_used = dev.rxq.last_used.wrapping_add(1);
    let head = elem.id as usize;
    let total_len = elem.len as usize;

    let buf_pa = dev.rx_bufs[head / 2];
    let payload_len = total_len.saturating_sub(VNET_HDR_SIZE);
    let payload_ptr = (buf_pa + VNET_HDR_SIZE) as *const u8;
    let frame = unsafe { core::slice::from_raw_parts(payload_ptr, payload_len).to_vec() };

    // Recycle descriptor
    unsafe { dev.rxq.push_avail(head as u16); }
    outl(dev.iobase + REG_QNOTIFY, 0);

    Some(frame)
}

pub fn mac() -> Option<[u8; 6]> {
    NETDEV.lock().as_ref().map(|d| d.mac)
}
