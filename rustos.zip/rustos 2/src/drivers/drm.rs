//! DRM display driver stub
pub fn init() {}
pub fn flip() {}
