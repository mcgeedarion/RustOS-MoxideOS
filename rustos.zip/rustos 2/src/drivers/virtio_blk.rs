//! VirtIO block device driver (PCI transport, split virtqueue).
//!
//! Spec: VirtIO 1.2 §5.2 (block), §2.7 (split virtqueue).
//!
//! Supports:
//!   - Read  (VIRTIO_BLK_T_IN  = 0)
//!   - Write (VIRTIO_BLK_T_OUT = 1)
//!   - FLUSH (VIRTIO_BLK_T_FLUSH = 4)
//!
//! One request at a time (synchronous, polled completion).
//! Queue depth = 16 descriptors.

extern crate alloc;
use alloc::vec::Vec;

use core::sync::atomic::{fence, Ordering};
use spin::Mutex;
use crate::mm::pmm::{self, PAGE_SIZE};

// ── PCI config-space helpers (x86 port I/O) ──────────────────────────────

#[cfg(target_arch = "x86_64")]
mod pci {
    fn outl(port: u16, val: u32) {
        unsafe { core::arch::asm!("out dx, eax", in("dx") port, in("eax") val); }
    }
    fn inl(port: u16) -> u32 {
        let v: u32;
        unsafe { core::arch::asm!("in eax, dx", in("dx") port, out("eax") v); }
        v
    }
    fn addr(bus: u8, dev: u8, func: u8, off: u8) -> u32 {
        0x8000_0000 | (bus as u32) << 16 | (dev as u32) << 11
                    | (func as u32) << 8  | (off & 0xFC) as u32
    }
    pub fn cfg_read32(bus: u8, dev: u8, func: u8, off: u8) -> u32 {
        outl(0xCF8, addr(bus, dev, func, off));
        inl(0xCFC)
    }
    pub fn cfg_write32(bus: u8, dev: u8, func: u8, off: u8, val: u32) {
        outl(0xCF8, addr(bus, dev, func, off));
        outl(0xCFC, val);
    }
    pub fn cfg_read16(bus: u8, dev: u8, func: u8, off: u8) -> u16 {
        (cfg_read32(bus, dev, func, off) >> ((off & 2) * 8)) as u16
    }

    /// Scan bus 0 for VirtIO block device (vendor=0x1AF4, device=0x1042|0x1001).
    pub fn find_virtio_blk() -> Option<(u8, u8, u16)> { // (bus,dev,iobase)
        for dev in 0u8..32 {
            let id = cfg_read32(0, dev, 0, 0);
            if id == 0xFFFF_FFFF { continue; }
            let vendor = (id & 0xFFFF) as u16;
            let device = (id >> 16)    as u16;
            if vendor == 0x1AF4 && (device == 0x1001 || device == 0x1042) {
                let bar0 = cfg_read32(0, dev, 0, 0x10) & !0x3;
                // Enable bus-master + I/O space
                let cmd = cfg_read16(0, dev, 0, 0x04);
                cfg_write32(0, dev, 0, 0x04, (cmd | 0x5) as u32);
                return Some((0, dev, bar0 as u16));
            }
        }
        None
    }
}

// ── VirtIO legacy I/O registers (BAR0) ───────────────────────────────────

struct VirtioBar0(u16);

impl VirtioBar0 {
    fn read32(&self, off: u16) -> u32 {
        let v: u32;
        unsafe { core::arch::asm!("in eax, dx", in("dx") self.0 + off, out("eax") v); }
        v
    }
    fn write32(&self, off: u16, v: u32) {
        unsafe { core::arch::asm!("out dx, eax", in("dx") self.0 + off, in("eax") v); }
    }
    fn write8(&self, off: u16, v: u8) {
        unsafe { core::arch::asm!("out dx, al", in("dx") self.0 + off, in("al") v); }
    }
}

const VIRTIO_STATUS_RESET:       u8 = 0;
const VIRTIO_STATUS_ACKNOWLEDGE: u8 = 1;
const VIRTIO_STATUS_DRIVER:      u8 = 2;
const VIRTIO_STATUS_DRIVER_OK:   u8 = 4;
const VIRTIO_STATUS_FEATURES_OK: u8 = 8;
const VIRTIO_STATUS_FAILED:      u8 = 128;

const VIRTIO_REG_DEVFEAT:   u16 = 0x00;
const VIRTIO_REG_DRVFEAT:   u16 = 0x04;
const VIRTIO_REG_QADDR:     u16 = 0x08;
const VIRTIO_REG_QSIZE:     u16 = 0x0C;
const VIRTIO_REG_QSELECT:   u16 = 0x0E;
const VIRTIO_REG_QNOTIFY:   u16 = 0x10;
const VIRTIO_REG_STATUS:    u16 = 0x12;
const VIRTIO_REG_ISR:       u16 = 0x13;

// ── Split virtqueue ───────────────────────────────────────────────────────

const QUEUE_SIZE: usize = 16;

#[repr(C, align(16))]
struct VirtqDesc {
    addr:  u64,
    len:   u32,
    flags: u16,
    next:  u16,
}

const VIRTQ_DESC_F_NEXT:  u16 = 1;
const VIRTQ_DESC_F_WRITE: u16 = 2;

#[repr(C, align(2))]
struct VirtqAvail {
    flags: u16,
    idx:   u16,
    ring:  [u16; QUEUE_SIZE],
}

#[repr(C, align(4))]
struct VirtqUsed {
    flags: u16,
    idx:   u16,
    ring:  [VirtqUsedElem; QUEUE_SIZE],
}

#[repr(C)]
struct VirtqUsedElem { id: u32, len: u32 }

// VirtIO block request header
#[repr(C)]
struct BlkReqHdr { ty: u32, _reserved: u32, sector: u64 }
const VIRTIO_BLK_T_IN:    u32 = 0;
const VIRTIO_BLK_T_OUT:   u32 = 1;
const VIRTIO_BLK_T_FLUSH: u32 = 4;

// ── Driver state ─────────────────────────────────────────────────────────

struct BlkDev {
    bar:        VirtioBar0,
    desc_pa:    usize,
    avail_pa:   usize,
    used_pa:    usize,
    last_used:  u16,
}

static BLKDEV: Mutex<Option<BlkDev>> = Mutex::new(None);

pub fn init() {
    #[cfg(not(target_arch = "x86_64"))] {
        // MMIO path for RISC-V (QEMU virt machine)
        let base = 0x1000_1000usize;
        if crate::drivers::virtio_mmio::probe(base) {
            crate::drivers::uart::puts("[virtio-blk] MMIO found (RISC-V stub)\n");
        }
        return;
    }

    #[cfg(target_arch = "x86_64")] {
        let (bus, dev, iobase) = match pci::find_virtio_blk() {
            Some(v) => v,
            None    => { crate::serial_println!("[virtio-blk] not found"); return; }
        };
        let bar = VirtioBar0(iobase);

        // Initialisation sequence (VirtIO 1.2 §3.1.1)
        bar.write8(VIRTIO_REG_STATUS, VIRTIO_STATUS_RESET);
        bar.write8(VIRTIO_REG_STATUS, VIRTIO_STATUS_ACKNOWLEDGE);
        bar.write8(VIRTIO_REG_STATUS, VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER);

        // Accept no optional features for simplicity
        bar.write32(VIRTIO_REG_DRVFEAT, 0);
        bar.write8(VIRTIO_REG_STATUS, VIRTIO_STATUS_ACKNOWLEDGE
                                    | VIRTIO_STATUS_DRIVER
                                    | VIRTIO_STATUS_FEATURES_OK);

        // Set up queue 0
        bar.write32(VIRTIO_REG_QSELECT, 0);
        bar.write32(VIRTIO_REG_QSIZE, QUEUE_SIZE as u32);

        // Allocate contiguous pages for desc, avail, used tables
        // Minimum 2 pages covers all three at QUEUE_SIZE=16
        let queue_pa = pmm::alloc_page().expect("OOM: virtqueue");
        unsafe { core::ptr::write_bytes(queue_pa as *mut u8, 0, PAGE_SIZE * 2); }
        pmm::alloc_page(); // second page (adjacent in physical layout)

        let desc_pa  = queue_pa;
        let avail_pa = queue_pa + core::mem::size_of::<VirtqDesc>() * QUEUE_SIZE;
        let used_pa  = (avail_pa + core::mem::size_of::<VirtqAvail>() + 0xFFF) & !0xFFF;

        bar.write32(VIRTIO_REG_QADDR, (queue_pa >> 12) as u32);

        bar.write8(VIRTIO_REG_STATUS,
            VIRTIO_STATUS_ACKNOWLEDGE | VIRTIO_STATUS_DRIVER
          | VIRTIO_STATUS_FEATURES_OK | VIRTIO_STATUS_DRIVER_OK);

        if bar.read32(VIRTIO_REG_STATUS) as u8 & VIRTIO_STATUS_FAILED != 0 {
            crate::serial_println!("[virtio-blk] device failed init");
            return;
        }

        *BLKDEV.lock() = Some(BlkDev {
            bar, desc_pa, avail_pa, used_pa, last_used: 0,
        });
        crate::serial_println!("[virtio-blk] ready (PCI bus={} dev={})", bus, dev);
    }
}

// ── Public I/O interface ──────────────────────────────────────────────────

/// Read `count` 512-byte sectors starting at `sector` into `buf`.
pub fn read_sectors(sector: u64, buf: &mut [u8]) -> Result<(), &'static str> {
    submit_rw(VIRTIO_BLK_T_IN, sector, buf)
}

/// Write `buf` (multiple of 512 bytes) starting at `sector`.
pub fn write_sectors(sector: u64, buf: &[u8]) -> Result<(), &'static str> {
    // Safety: write path doesn't mutate buf; we cast to *mut u8 but only
    // set VIRTQ_DESC_F_WRITE on the status byte descriptor, not the data desc.
    submit_rw(VIRTIO_BLK_T_OUT, sector,
              unsafe { core::slice::from_raw_parts_mut(buf.as_ptr() as *mut u8, buf.len()) })
}

fn submit_rw(ty: u32, sector: u64, buf: &mut [u8]) -> Result<(), &'static str> {
    if buf.len() % 512 != 0 { return Err("buf not sector-aligned"); }

    let mut guard = BLKDEV.lock();
    let dev = guard.as_mut().ok_or("no virtio-blk")?;

    // Allocate 3 descriptors: [0]=header  [1]=data  [2]=status
    let hdr = BlkReqHdr { ty, _reserved: 0, sector };
    let hdr_pa = &hdr as *const BlkReqHdr as usize;
    let buf_pa  = buf.as_ptr() as usize;
    let status  = 0u8;
    let stat_pa = &status as *const u8 as usize;

    let descs = dev.desc_pa as *mut VirtqDesc;
    unsafe {
        // Desc 0: header (read-only device)
        descs.add(0).write(VirtqDesc {
            addr:  hdr_pa as u64, len: 16,
            flags: VIRTQ_DESC_F_NEXT, next: 1,
        });
        // Desc 1: data buffer
        let data_flags = VIRTQ_DESC_F_NEXT
            | if ty == VIRTIO_BLK_T_IN { VIRTQ_DESC_F_WRITE } else { 0 };
        descs.add(1).write(VirtqDesc {
            addr: buf_pa as u64, len: buf.len() as u32,
            flags: data_flags, next: 2,
        });
        // Desc 2: status byte (device writes here)
        descs.add(2).write(VirtqDesc {
            addr: stat_pa as u64, len: 1,
            flags: VIRTQ_DESC_F_WRITE, next: 0,
        });
    }

    // Publish in avail ring
    let avail = dev.avail_pa as *mut VirtqAvail;
    let idx = unsafe { (*avail).idx };
    unsafe {
        (*avail).ring[(idx as usize) % QUEUE_SIZE] = 0; // head descriptor
        fence(Ordering::Release);
        (*avail).idx = idx.wrapping_add(1);
    }

    // Notify device
    dev.bar.write32(VIRTIO_REG_QNOTIFY, 0);

    // Poll used ring (no interrupt needed for synchronous I/O)
    let used = dev.used_pa as *mut VirtqUsed;
    let timeout = 1_000_000u32;
    let mut i = 0u32;
    loop {
        fence(Ordering::Acquire);
        if unsafe { (*used).idx } != dev.last_used { break; }
        i += 1;
        if i >= timeout { return Err("virtio-blk timeout"); }
        core::hint::spin_loop();
    }
    dev.last_used = dev.last_used.wrapping_add(1);

    if status != 0 { return Err("virtio-blk I/O error"); }
    Ok(())
}
