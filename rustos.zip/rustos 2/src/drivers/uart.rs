//! 16550 UART driver (QEMU virt machine, MMIO at 0x1000_0000)
const UART_BASE: usize = 0x1000_0000;

const RBR: usize = 0; // receive buffer (R)
const THR: usize = 0; // transmit holding (W)
const IER: usize = 1; // interrupt enable
const FCR: usize = 2; // FIFO control (W)
const LCR: usize = 3; // line control
const LSR: usize = 5; // line status

const LSR_DATA_READY: u8 = 1 << 0;
const LSR_TX_IDLE:    u8 = 1 << 5;

fn reg(offset: usize) -> *mut u8 {
    (UART_BASE + offset) as *mut u8
}

pub fn init() {
    unsafe {
        reg(IER).write_volatile(0x00); // disable interrupts during init
        reg(LCR).write_volatile(0x80); // DLAB=1 to set baud
        reg(0).write_volatile(0x03);   // baud divisor low  (38400)
        reg(1).write_volatile(0x00);   // baud divisor high
        reg(LCR).write_volatile(0x03); // 8N1, DLAB=0
        reg(FCR).write_volatile(0xC7); // enable+clear FIFOs
        reg(IER).write_volatile(0x01); // enable RX interrupt
    }
}

/// Write one byte, spinning until the TX FIFO has room.
pub fn putc(c: u8) {
    unsafe {
        while reg(LSR).read_volatile() & LSR_TX_IDLE == 0 {}
        reg(THR).write_volatile(c);
    }
}

/// Write a string.
pub fn puts(s: &str) {
    for &b in s.as_bytes() {
        if b == b'\n' { putc(b'\r'); }
        putc(b);
    }
}

/// Blocking read of one byte from the UART RX FIFO.
pub fn getc_raw() -> Option<u8> {
    // Non-blocking: return byte only if LSR data-ready bit set
    let lsr = inb(COM1 + 5);
    if lsr & 1 == 0 { return None; }
    Some(inb(COM1))
}

pub fn getc() -> u8 {
    unsafe {
        while reg(LSR).read_volatile() & LSR_DATA_READY == 0 {}
        reg(RBR).read_volatile()
    }
}
