//! RISC-V CLINT — timer + software interrupts (QEMU virt: base 0x0200_0000)
const CLINT_BASE: usize = 0x0200_0000;
const MTIME:      usize = CLINT_BASE + 0xBFF8;
const MTIMECMP0:  usize = CLINT_BASE + 0x4000;

/// ~10 ms at 10 MHz (QEMU virt default mtime clock)
pub const TIMER_INTERVAL: u64 = 100_000;

/// Set the next timer interrupt `delta` ticks from now.
pub fn set_timer(delta: u64) {
    let now = unsafe { (MTIME as *const u64).read_volatile() };
    unsafe { (MTIMECMP0 as *mut u64).write_volatile(now + delta); }
}

/// Read the current mtime counter.
pub fn read_time() -> u64 {
    unsafe { (MTIME as *const u64).read_volatile() }
}

/// Called once at boot: arm the first timer interrupt.
pub fn init() {
    set_timer(TIMER_INTERVAL);
}
