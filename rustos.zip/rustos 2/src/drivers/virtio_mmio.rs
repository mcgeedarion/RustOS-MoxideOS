//! VirtIO MMIO transport layer
const VIRTIO_MAGIC: u32 = 0x74726976;

#[repr(C)]
pub struct VirtioMmioRegs {
    pub magic:            u32,
    pub version:          u32,
    pub device_id:        u32,
    pub vendor_id:        u32,
    pub host_features:    u32,
    _pad:                 [u32; 3],
    pub guest_features:   u32,
    _pad2:                [u32; 3],
    pub queue_sel:        u32,
    pub queue_num_max:    u32,
    pub queue_num:        u32,
    _pad3:                [u32; 2],
    pub queue_ready:      u32,
    _pad4:                [u32; 2],
    pub queue_notify:     u32,
    _pad5:                [u32; 3],
    pub interrupt_status: u32,
    pub interrupt_ack:    u32,
    _pad6:                [u32; 2],
    pub status:           u32,
}

pub fn probe(base: usize) -> bool {
    let regs = base as *const VirtioMmioRegs;
    unsafe { (*regs).magic == VIRTIO_MAGIC }
}
