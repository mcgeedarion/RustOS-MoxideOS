//! Mouse driver stub
pub fn poll() -> Option<(i8, i8, u8)> { None }
