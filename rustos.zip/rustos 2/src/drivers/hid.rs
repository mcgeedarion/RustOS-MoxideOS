//! USB HID driver stub
pub fn poll() -> Option<[u8; 8]> { None }
