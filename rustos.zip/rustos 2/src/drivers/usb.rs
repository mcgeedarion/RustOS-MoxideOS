//! USB host controller stub
pub fn init() {}
