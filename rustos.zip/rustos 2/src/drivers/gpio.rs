//! Generic GPIO driver with per-pin IRQ handlers
use spin::Mutex;

pub type GpioHandler = fn();
fn noop() {}

const MAX_HANDLERS: usize = 256; // 8 ports * 32 pins
static HANDLERS: Mutex<[GpioHandler; MAX_HANDLERS]> = Mutex::new([noop; MAX_HANDLERS]);

pub fn set_handler(port: usize, pin: usize, handler: GpioHandler) {
    let idx = port * 32 + pin;
    if idx < MAX_HANDLERS {
        HANDLERS.lock()[idx] = handler;
    }
}

pub fn handle_gpio_irq(port: usize, status: u32) {
    let handlers = HANDLERS.lock();
    let mut bits = status;
    while bits != 0 {
        let pin = bits.trailing_zeros() as usize;
        handlers[port * 32 + pin]();
        bits &= bits - 1;
    }
}
