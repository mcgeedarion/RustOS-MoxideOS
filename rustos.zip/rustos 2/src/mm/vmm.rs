//! Virtual memory manager — Sv39 + KPTI
//!
//! Security invariants enforced here:
//!   - Kernel higher-half map: text R|X, rodata R, data/bss/heap/stack R|W.
//!   - No identity (PA==VA) map after boot.
//!   - User pages never mapped into kernel higher-half.
use crate::mm::pmm::{self, PAGE_SIZE};
use crate::arch::riscv64::paging::{PteFlags, make_pte, pte_ppn};
use crate::arch::riscv64::csr::make_satp;
use crate::proc::process::Pcb;

pub const USER_END:      usize = 0x0000_003f_ffff_f000;
pub const KERNEL_BASE:   usize = 0xffff_ffc0_0000_0000;
pub const TRAMPOLINE_VA: usize = 0x0000_003f_ffff_f000;
pub const TRAPFRAME_VA:  usize = TRAMPOLINE_VA - PAGE_SIZE;

extern "C" {
    static _trampoline_start: u8;
    static _text_start:  u8;
    static _text_end:    u8;
    static _rodata_end:  u8;
}

fn alloc_zero_page() -> Option<usize> {
    let pa = pmm::alloc_page()?;
    unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
    Some(pa)
}

/// Walk / install a single 4 KiB mapping in the Sv39 table at `root_pa`.
pub fn map_page(root_pa: usize, va: usize, pa: usize, flags: PteFlags) {
    let vpn = [
        (va >> 12) & 0x1FF,
        (va >> 21) & 0x1FF,
        (va >> 30) & 0x1FF,
    ];
    let mut table = root_pa as *mut u64;
    for level in (1..=2).rev() {
        let entry = unsafe { (table as *const u64).add(vpn[level]).read_volatile() };
        if entry & 1 == 0 {
            let child = alloc_zero_page().expect("OOM in map_page");
            unsafe { (table as *mut u64).add(vpn[level]).write_volatile(make_pte(child / PAGE_SIZE, PteFlags::V)); }
            table = child as *mut u64;
        } else {
            table = (pte_ppn(entry) * PAGE_SIZE) as *mut u64;
        }
    }
    unsafe {
        (table as *mut u64).add(vpn[0])
            .write_volatile(make_pte(pa / PAGE_SIZE, flags | PteFlags::V));
    }
}

/// Walk the page table and return the PA mapped at `va`, or None.
pub fn walk_pa(root_pa: usize, va: usize) -> Option<usize> {
    let vpn = [
        (va >> 12) & 0x1FF,
        (va >> 21) & 0x1FF,
        (va >> 30) & 0x1FF,
    ];
    let mut table = root_pa as *const u64;
    for level in (1..=2).rev() {
        let entry = unsafe { table.add(vpn[level]).read_volatile() };
        if entry & 1 == 0 { return None; }
        table = (pte_ppn(entry) * PAGE_SIZE) as *const u64;
    }
    let leaf = unsafe { table.add(vpn[0]).read_volatile() };
    if leaf & 1 == 0 { return None; }
    Some(pte_ppn(leaf) * PAGE_SIZE + (va & (PAGE_SIZE - 1)))
}

pub fn unmap_page(root_pa: usize, va: usize) {
    let vpn = [
        (va >> 12) & 0x1FF,
        (va >> 21) & 0x1FF,
        (va >> 30) & 0x1FF,
    ];
    let mut table = root_pa as *mut u64;
    for level in (1..=2).rev() {
        let entry = unsafe { (table as *const u64).add(vpn[level]).read_volatile() };
        if entry & 1 == 0 { return; }
        table = (pte_ppn(entry) * PAGE_SIZE) as *mut u64;
    }
    unsafe { (table as *mut u64).add(vpn[0]).write_volatile(0); }
}

// ---------------------------------------------------------------------------
// KPTI page-table builders
// ---------------------------------------------------------------------------

/// Build the kernel SATP for a process.
/// Maps: kernel higher-half (R|X / R / R|W per section) + trampoline (R|X)
///       + trapframe (R|W). NO identity map, NO user pages.
pub fn build_kernel_satp(pcb: &Pcb) -> usize {
    let root = alloc_zero_page().expect("OOM: kernel_satp root");
    let tramp_pa    = unsafe { &_trampoline_start as *const u8 as usize };
    let text_start  = unsafe { &_text_start  as *const u8 as usize };
    let text_end    = unsafe { &_text_end    as *const u8 as usize };
    let rodata_end  = unsafe { &_rodata_end  as *const u8 as usize };

    // Trampoline + trapframe
    map_page(root, TRAMPOLINE_VA, tramp_pa,       PteFlags::R | PteFlags::X);
    map_page(root, TRAPFRAME_VA,  pcb.trapframe_pa, PteFlags::R | PteFlags::W);

    // Higher-half kernel map with tight per-section permissions
    let kbase: usize = 0x8020_0000;
    let ksize: usize = 128 * 1024 * 1024;
    let mut off = 0;
    while off < ksize {
        let pa    = kbase + off;
        let va_hi = KERNEL_BASE + off;
        let flags = if pa >= text_start && pa < text_end {
            PteFlags::R | PteFlags::X
        } else if pa >= text_end && pa < rodata_end {
            PteFlags::R
        } else {
            PteFlags::R | PteFlags::W
        };
        map_page(root, va_hi, pa, flags);
        off += PAGE_SIZE;
    }

    make_satp(root / PAGE_SIZE)
}

/// Build the user SATP: trampoline (R|X) + trapframe (R|W) only.
/// User text/data/stack pages are added by Pcb::load_elf.
pub fn build_user_satp(pcb: &Pcb) -> usize {
    let root     = alloc_zero_page().expect("OOM: user_satp root");
    let tramp_pa = unsafe { &_trampoline_start as *const u8 as usize };
    map_page(root, TRAMPOLINE_VA, tramp_pa,         PteFlags::R | PteFlags::X);
    map_page(root, TRAPFRAME_VA,  pcb.trapframe_pa, PteFlags::R | PteFlags::W);
    make_satp(root / PAGE_SIZE)
}

// ---------------------------------------------------------------------------
// Address validation
// ---------------------------------------------------------------------------

/// True iff [va, va+len) lies entirely within user address space.
/// A zero-length range is valid (caller decides semantics).
pub fn is_user_range(va: usize, len: usize) -> bool {
    va != 0 && va < USER_END && va.saturating_add(len) <= USER_END
}

// ---------------------------------------------------------------------------
// Demand paging (stub — wired to current PCB below)
// ---------------------------------------------------------------------------

pub fn handle_page_fault(va: usize) -> bool {
    if va >= KERNEL_BASE { return false; }
    if let Some(pa) = pmm::alloc_page() {
        unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
        // TODO: map pa into current process kernel_satp once per-CPU PCB ptr exists
        let _ = pa;
        true
    } else {
        false
    }
}
