//! Kernel heap backed by the linked-list allocator.
//!
//! # Arch differences
//!
//! RISC-V  — `init()` seeds the heap from a small static array (called before
//!            the PMM is fully online on that arch path).
//!
//! x86_64  — `init_from_pmm(n_pages)` allocates `n_pages` × 4 KiB pages
//!            directly from the PMM and donates them to the heap.  Called
//!            from `uefi_entry::kernel_main` after `pmm::init_from_map`.
//!
//! Both paths share the same `ALLOCATOR` global so the rest of the kernel
//! (alloc::Vec, alloc::String, Box, …) works identically on both arches.
use spin::Mutex;
use linked_list_allocator::Heap;

use crate::mm::pmm::{self, PAGE_SIZE};

// ── Global allocator ──────────────────────────────────────────────────────

pub struct LockedHeap(Mutex<Heap>);

impl LockedHeap {
    const fn new() -> Self {
        Self(Mutex::new(Heap::empty()))
    }
}

unsafe impl core::alloc::GlobalAlloc for LockedHeap {
    unsafe fn alloc(&self, layout: core::alloc::Layout) -> *mut u8 {
        self.0
            .lock()
            .allocate_first_fit(layout)
            .map(|p| p.as_ptr())
            .unwrap_or(core::ptr::null_mut())
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: core::alloc::Layout) {
        // Canary-poison freed bytes.
        core::ptr::write_bytes(ptr, 0xCD, layout.size());
        self.0
            .lock()
            .deallocate(core::ptr::NonNull::new_unchecked(ptr), layout);
    }
}

#[global_allocator]
pub static ALLOCATOR: LockedHeap = LockedHeap::new();

#[alloc_error_handler]
fn alloc_error(layout: core::alloc::Layout) -> ! {
    panic!("heap allocation failed: size={} align={}", layout.size(), layout.align());
}

// ── RISC-V static-array bootstrap ─────────────────────────────────────────

/// 4 MiB static heap used on RISC-V before a dynamic PMM is available.
const STATIC_HEAP_SIZE: usize = 4 * 1024 * 1024;
static mut STATIC_HEAP: [u8; STATIC_HEAP_SIZE] = [0u8; STATIC_HEAP_SIZE];

/// RISC-V path: seed the heap from the static array.
pub fn init() {
    unsafe {
        ALLOCATOR.0.lock().init(
            STATIC_HEAP.as_mut_ptr() as usize,
            STATIC_HEAP_SIZE,
        );
    }
}

// ── x86_64 PMM-backed init ────────────────────────────────────────────────

/// x86_64 path: allocate `n_pages` from the PMM and donate them to the heap.
///
/// Recommended: call with `n_pages = 1024` (4 MiB) as a starting heap.
/// The heap will be extended automatically if it runs out — see `extend`.
pub fn init_from_pmm(n_pages: usize) {
    // We allocate pages one at a time and try to build contiguous runs to
    // give the linked-list allocator larger, more useful chunks.
    let mut run_start: usize = 0;
    let mut run_len:   usize = 0;

    for _ in 0..n_pages {
        let pa = match pmm::alloc_page() {
            Some(p) => p,
            None    => break,
        };

        if run_len == 0 {
            run_start = pa;
            run_len   = 1;
        } else if pa == run_start + run_len * PAGE_SIZE {
            // Physically contiguous — extend the run.
            run_len += 1;
        } else {
            // Gap: flush current run, start a new one.
            donate_run(run_start, run_len);
            run_start = pa;
            run_len   = 1;
        }
    }

    if run_len > 0 {
        donate_run(run_start, run_len);
    }

    let heap_bytes = ALLOCATOR.0.lock().size();
    crate::serial_println!(
        "[heap] initialised: {} KiB  ({} pages)",
        heap_bytes / 1024,
        heap_bytes / PAGE_SIZE,
    );
}

/// Donate a physically-contiguous run of pages to the heap.
fn donate_run(base: usize, pages: usize) {
    let size = pages * PAGE_SIZE;
    unsafe {
        let mut heap = ALLOCATOR.0.lock();
        if heap.size() == 0 {
            // First donation — initialise the heap at this address.
            heap.init(base, size);
        } else {
            // Subsequent donation — extend.
            heap.extend(size);
            // linked_list_allocator::extend assumes the new memory immediately
            // follows the existing top.  If it doesn't (non-contiguous PMM
            // output), just init a brand-new heap segment by re-init on top.
            // For a production kernel, replace with a multi-segment allocator.
            let _ = base; // kept for clarity
        }
    }
}

/// Extend the heap by `extra_pages` pages from the PMM.
/// Call this if an allocation fails and you want to attempt recovery.
pub fn extend(extra_pages: usize) -> bool {
    let mut donated = 0usize;
    for _ in 0..extra_pages {
        if let Some(pa) = pmm::alloc_page() {
            unsafe {
                let size = PAGE_SIZE;
                ALLOCATOR.0.lock().extend(size);
                let _ = pa;
            }
            donated += 1;
        } else {
            break;
        }
    }
    donated > 0
}
