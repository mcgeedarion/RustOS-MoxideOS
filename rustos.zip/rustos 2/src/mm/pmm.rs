//! Physical memory manager.
//!
//! # RISC-V path
//! `init()` — called from boot.rs, registers the single 128 MiB DRAM window
//! starting at the end of the kernel image.
//!
//! # x86_64 path
//! `init_from_map(regions)` — called from uefi_entry after ExitBootServices.
//! Walks the UEFI memory map, skips the kernel image and reserved regions,
//! and registers every usable conventional-memory region with the buddy
//! allocator.  Multiple non-contiguous regions are fully supported.
use core::sync::atomic::{AtomicUsize, Ordering};

pub use crate::mm::buddy::PAGE_SIZE;
use crate::mm::buddy;

static FREE_PAGES:  AtomicUsize = AtomicUsize::new(0);
static TOTAL_PAGES: AtomicUsize = AtomicUsize::new(0);

// ── RISC-V single-region init ─────────────────────────────────────────────

pub fn init() {
    extern "C" { static _end: u8; }
    let image_end = unsafe { &_end as *const u8 as usize };
    let start = align_up(image_end, PAGE_SIZE);
    let end   = 0x8020_0000usize + 128 * 1024 * 1024;
    if start < end {
        let pages = (end - start) / PAGE_SIZE;
        buddy::add_region(start, pages);
        FREE_PAGES.store(pages, Ordering::SeqCst);
        TOTAL_PAGES.store(pages, Ordering::SeqCst);
    }
}

// ── x86_64 multi-region init ──────────────────────────────────────────────

/// Minimum page address we'll hand out — skip first 1 MiB (legacy BIOS/ROM).
const X86_LOW_LIMIT: usize = 0x10_0000; // 1 MiB

/// Called by uefi_entry::kernel_main with the UEFI memory map.
/// `regions` is the slice of `MemRegion` produced by efi_main.
pub fn init_from_map(regions: &[crate::arch::x86_64::uefi_entry::MemRegion]) {
    use crate::arch::x86_64::uefi_entry::RegionKind;

    // Locate the end of our own kernel image so we never hand it out.
    extern "C" { static _end: u8; }
    let kernel_end = align_up(
        unsafe { &_end as *const u8 as usize },
        PAGE_SIZE,
    );

    let mut total = 0usize;

    for r in regions {
        if r.kind != RegionKind::Usable { continue; }

        let base = r.base as usize;
        let end  = base + r.len as usize;

        // Skip anything below 1 MiB.
        let base = base.max(X86_LOW_LIMIT);
        if base >= end { continue; }

        // Skip pages that contain our kernel image.
        let base = if end <= kernel_end {
            // Entire region is under the kernel — skip.
            continue;
        } else if base < kernel_end {
            // Region straddles the kernel end — start after it.
            kernel_end
        } else {
            base
        };

        let base  = align_up(base, PAGE_SIZE);
        let end   = align_dn(end,  PAGE_SIZE);
        if base >= end { continue; }

        let pages = (end - base) / PAGE_SIZE;
        buddy::add_region(base, pages);
        total += pages;

        crate::serial_println!(
            "[pmm] region {:#018x}..{:#018x}  {} MiB",
            base, end,
            (pages * PAGE_SIZE) / (1024 * 1024),
        );
    }

    FREE_PAGES.store(total, Ordering::SeqCst);
    TOTAL_PAGES.store(total, Ordering::SeqCst);

    crate::serial_println!(
        "[pmm] total usable: {} MiB  ({} pages)",
        (total * PAGE_SIZE) / (1024 * 1024),
        total,
    );
}

// ── Alloc / free ──────────────────────────────────────────────────────────

pub fn alloc_page() -> Option<usize> {
    let pa = buddy::alloc()?;
    FREE_PAGES.fetch_sub(1, Ordering::Relaxed);
    Some(pa)
}

pub fn free_page(pa: usize) {
    buddy::free(pa);
    FREE_PAGES.fetch_add(1, Ordering::Relaxed);
}

pub fn free_pages()  -> usize { FREE_PAGES.load(Ordering::Relaxed) }
pub fn total_pages() -> usize { TOTAL_PAGES.load(Ordering::Relaxed) }

// ── Alignment helpers ─────────────────────────────────────────────────────

#[inline]
pub fn align_up(val: usize, align: usize) -> usize {
    (val + align - 1) & !(align - 1)
}

#[inline]
pub fn align_dn(val: usize, align: usize) -> usize {
    val & !(align - 1)
}

/// Return (total_bytes, free_bytes).
pub fn stats() -> (usize, usize) {
    let free = FREE_PAGES.load(core::sync::atomic::Ordering::Relaxed) * PAGE_SIZE;
    let total = TOTAL_PAGES.load(core::sync::atomic::Ordering::Relaxed) * PAGE_SIZE;
    (total, free)
}
