//! Swap subsystem stub
pub fn page_in(va: usize) -> bool {
    let _ = va;
    false // No swap device yet
}

pub fn page_out(va: usize) -> bool {
    let _ = va;
    false
}
