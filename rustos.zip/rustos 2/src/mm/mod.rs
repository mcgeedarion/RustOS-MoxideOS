pub mod buddy;
pub mod heap;
pub mod pmm;
pub mod swap;
pub mod vmm;
pub mod vmm_boot;

pub use pmm::PAGE_SIZE;

/// RISC-V init path — called from boot.rs before satp is active.
pub fn init() {
    // pmm::init() is called in boot.rs (before satp activation).
    // heap::init() is called in boot.rs after satp is live.
}
pub mod mmap;
