//! Bitmap buddy allocator — supports up to MAX_REGIONS non-contiguous
//! physical memory regions so the x86_64 memory map can be fully ingested.
//!
//! Each region tracks its own base + bitmap.  alloc() scans regions in order;
//! free() finds the owning region by address.
use core::sync::atomic::{AtomicUsize, Ordering};
use spin::Mutex;

pub const PAGE_SIZE: usize  = 4096;
/// Max pages per region (128 MiB).
const REGION_PAGES: usize   = 32_768;
/// Max distinct physical memory regions.
const MAX_REGIONS:  usize   = 16;

struct Region {
    base:   usize,
    pages:  usize,
    bitmap: [u8; REGION_PAGES / 8],
}

impl Region {
    const fn zero() -> Self {
        Self { base: 0, pages: 0, bitmap: [0u8; REGION_PAGES / 8] }
    }

    fn alloc(&mut self) -> Option<usize> {
        for i in 0..self.pages {
            let (byte, bit) = (i / 8, i % 8);
            if self.bitmap[byte] & (1 << bit) == 0 {
                self.bitmap[byte] |= 1 << bit;
                let pa = self.base + i * PAGE_SIZE;
                // Poison inside lock — no SMP window.
                unsafe { core::ptr::write_bytes(pa as *mut u8, 0xAB, PAGE_SIZE); }
                return Some(pa);
            }
        }
        None
    }

    fn free(&mut self, pa: usize) {
        if pa < self.base { return; }
        let i = (pa - self.base) / PAGE_SIZE;
        if i >= self.pages { return; }
        let (byte, bit) = (i / 8, i % 8);
        if self.bitmap[byte] & (1 << bit) == 0 { return; } // double-free guard
        unsafe { core::ptr::write_bytes(pa as *mut u8, 0xDE, PAGE_SIZE); }
        self.bitmap[byte] &= !(1 << bit);
    }

    fn contains(&self, pa: usize) -> bool {
        pa >= self.base && pa < self.base + self.pages * PAGE_SIZE
    }
}

struct BuddyAllocator {
    regions: [Region; MAX_REGIONS],
    count:   usize,
}

impl BuddyAllocator {
    const fn new() -> Self {
        const ZERO: Region = Region::zero();
        Self { regions: [ZERO; MAX_REGIONS], count: 0 }
    }

    fn add_region(&mut self, base: usize, pages: usize) {
        if self.count >= MAX_REGIONS { return; }
        let pages = pages.min(REGION_PAGES);
        self.regions[self.count] = Region { base, pages, bitmap: [0u8; REGION_PAGES / 8] };
        self.count += 1;
    }

    fn alloc(&mut self) -> Option<usize> {
        for r in &mut self.regions[..self.count] {
            if let Some(pa) = r.alloc() { return Some(pa); }
        }
        None
    }

    fn free(&mut self, pa: usize) {
        for r in &mut self.regions[..self.count] {
            if r.contains(pa) { r.free(pa); return; }
        }
    }

    fn total_pages(&self) -> usize {
        self.regions[..self.count].iter().map(|r| r.pages).sum()
    }
}

static ALLOC: Mutex<BuddyAllocator> = Mutex::new(BuddyAllocator::new());

/// Register a contiguous physical region with the allocator.
pub fn add_region(base: usize, pages: usize) {
    ALLOC.lock().add_region(base, pages);
}

pub fn alloc() -> Option<usize> {
    ALLOC.lock().alloc()
}

pub fn free(pa: usize) {
    ALLOC.lock().free(pa);
}

pub fn total_pages() -> usize {
    ALLOC.lock().total_pages()
}
