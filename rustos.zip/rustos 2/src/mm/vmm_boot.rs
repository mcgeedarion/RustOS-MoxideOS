//! Boot-time kernel page table builder.
//! Runs before heap is available — uses only PMM page allocations.
//!
//! Security notes:
//!   - Identity map is installed for the brief window between write_satp and
//!     the first higher-half PC, then REMOVED by remove_identity_map().
//!   - Kernel text (.text) is mapped R|X only.
//!   - Kernel data/bss/heap/stack are mapped R|W only (never executable).
//!   - Trampoline is R|X, no write.
use crate::mm::pmm::{alloc_page, PAGE_SIZE};
use crate::arch::riscv64::paging::{PteFlags, make_pte, pte_ppn};
use crate::arch::riscv64::csr::make_satp;

const KPHYS_BASE: usize = 0x8020_0000;
const KPHYS_SIZE: usize = 128 * 1024 * 1024;
pub const KVIRT_BASE: usize = 0xffff_ffc0_8020_0000;

// Linker symbols for section boundaries (defined in linker.ld)
extern "C" {
    static _text_start:  u8;
    static _text_end:    u8;
    static _rodata_end:  u8;
}

fn alloc_pt() -> usize {
    let pa = alloc_page().expect("OOM: boot page table");
    unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
    pa
}

pub fn map_page_boot(root_pa: usize, va: usize, pa: usize, flags: PteFlags) {
    let vpn = [
        (va >> 12) & 0x1FF,
        (va >> 21) & 0x1FF,
        (va >> 30) & 0x1FF,
    ];
    let mut table = root_pa as *mut u64;
    for level in (1..=2).rev() {
        let entry = unsafe { (table as *const u64).add(vpn[level]).read_volatile() };
        if entry & 1 == 0 {
            let child = alloc_pt();
            unsafe { (table as *mut u64).add(vpn[level]).write_volatile(make_pte(child / PAGE_SIZE, PteFlags::V)); }
            table = child as *mut u64;
        } else {
            table = (pte_ppn(entry) * PAGE_SIZE) as *mut u64;
        }
    }
    unsafe {
        (table as *mut u64).add(vpn[0])
            .write_volatile(make_pte(pa / PAGE_SIZE, flags | PteFlags::V));
    }
}

/// Unmap a single VA in the boot page table (zeroes the leaf PTE).
pub fn unmap_page_boot(root_pa: usize, va: usize) {
    let vpn = [
        (va >> 12) & 0x1FF,
        (va >> 21) & 0x1FF,
        (va >> 30) & 0x1FF,
    ];
    let mut table = root_pa as *mut u64;
    for level in (1..=2).rev() {
        let entry = unsafe { (table as *const u64).add(vpn[level]).read_volatile() };
        if entry & 1 == 0 { return; }
        table = (pte_ppn(entry) * PAGE_SIZE) as *mut u64;
    }
    unsafe { (table as *mut u64).add(vpn[0]).write_volatile(0); }
}

/// Build the boot kernel page table.
/// Maps:
///   - Identity (PA==VA): temporary, removed by remove_identity_map() after boot.
///   - Higher-half:  text  -> R|X,  rodata -> R,  rest -> R|W.
///   - Trampoline at TRAMPOLINE_VA: R|X.
pub fn build_boot_kernel_pt() -> usize {
    let root = alloc_pt();

    let text_start  = unsafe { &_text_start  as *const u8 as usize };
    let text_end    = unsafe { &_text_end    as *const u8 as usize };
    let rodata_end  = unsafe { &_rodata_end  as *const u8 as usize };

    let mut off = 0usize;
    while off < KPHYS_SIZE {
        let pa    = KPHYS_BASE + off;
        let va_hi = KVIRT_BASE + off;

        // Determine per-page flags based on section
        let hi_flags = if pa >= text_start && pa < text_end {
            PteFlags::R | PteFlags::X          // .text: R|X
        } else if pa >= text_end && pa < rodata_end {
            PteFlags::R                        // .rodata: R only
        } else {
            PteFlags::R | PteFlags::W          // .data/.bss/heap/stack: R|W
        };

        // Identity map: always R|W|X so the brief post-satp window works.
        // These are stripped by remove_identity_map() immediately after boot.
        map_page_boot(root, pa, pa, PteFlags::R | PteFlags::W | PteFlags::X);

        // Higher-half map with tight permissions
        map_page_boot(root, va_hi, pa, hi_flags);

        off += PAGE_SIZE;
    }

    // Trampoline: R|X, no write
    extern "C" { static _trampoline_start: u8; }
    let tramp_pa = unsafe { &_trampoline_start as *const u8 as usize };
    map_page_boot(root, crate::mm::vmm::TRAMPOLINE_VA, tramp_pa, PteFlags::R | PteFlags::X);

    make_satp(root / PAGE_SIZE)
}

/// SECURITY: Remove the identity (PA==VA) mappings installed for boot.
/// Must be called immediately after the CPU is running at higher-half VAs.
/// After this call, the only valid kernel window is KVIRT_BASE.
pub fn remove_identity_map(boot_satp: usize) {
    let root_pa = crate::arch::riscv64::csr::satp_ppn(boot_satp) * PAGE_SIZE;
    let mut off = 0usize;
    while off < KPHYS_SIZE {
        let pa = KPHYS_BASE + off;
        unmap_page_boot(root_pa, pa); // strip PA==VA entry
        off += PAGE_SIZE;
    }
    // TLB flush after bulk unmap
    crate::arch::riscv64::csr::sfence_vma();
}
