//! Virtual memory area (VMA) tracker + mmap / munmap / mprotect / brk.
//!
//! Each process has a per-PCB VMA list stored in the scheduler's PCB.
//! For now we keep a *global* VMA list (single address space kernel) that
//! is reset on execve.  A proper per-process implementation follows the
//! same API.
//!
//! Address space layout (userspace):
//!   0x0000_0000_0040_0000  ELF load base
//!   ...                    text / rodata / data / bss
//!   brk_start              heap (grows up via brk / MAP_ANONYMOUS)
//!   0x0000_7FFF_F000_0000  mmap region (grows down)
//!   0x0000_7FFF_FFFF_F000  stack top

extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;
use crate::mm::pmm::{self, PAGE_SIZE};
use crate::arch::x86_64::paging;

// ── Constants ─────────────────────────────────────────────────────────────

pub const PROT_NONE:  u32 = 0;
pub const PROT_READ:  u32 = 1;
pub const PROT_WRITE: u32 = 2;
pub const PROT_EXEC:  u32 = 4;

pub const MAP_PRIVATE:    u32 = 0x02;
pub const MAP_SHARED:     u32 = 0x01;
pub const MAP_ANONYMOUS:  u32 = 0x20;
pub const MAP_FIXED:      u32 = 0x10;
pub const MAP_GROWSDOWN:  u32 = 0x100;

// mmap region: allocate from just below 128 TiB, growing downward
const MMAP_TOP: usize    = 0x0000_7FFF_F000_0000;
const MMAP_BOTTOM: usize = 0x0000_0000_1000_0000; // 256 MiB
const BRK_BASE: usize    = 0x0000_0000_0060_0000; // 6 MiB — above typical ELF

// ── VMA descriptor ────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct Vma {
    pub start: usize,
    pub end:   usize,  // exclusive
    pub prot:  u32,
    pub flags: u32,
    pub file_backed: bool,
}

// ── Global state ──────────────────────────────────────────────────────────

struct MmapState {
    vmas:     Vec<Vma>,
    next_map: usize,  // next mmap allocation base (grows down)
    brk:      usize,  // current program break
}

static MM: Mutex<MmapState> = Mutex::new(MmapState {
    vmas:     Vec::new(),
    next_map: MMAP_TOP,
    brk:      BRK_BASE,
});

/// Reset address space (called from execve).
pub fn reset(brk_start: usize) {
    let mut mm = MM.lock();
    // Unmap all user VMAs
    for vma in mm.vmas.drain(..) {
        unmap_range(vma.start, vma.end - vma.start);
    }
    mm.next_map = MMAP_TOP;
    mm.brk      = brk_start;
}

// ── Page table helpers (thin wrappers around paging module) ───────────────

fn map_range(va: usize, len: usize, prot: u32) {
    let pages = (len + PAGE_SIZE - 1) / PAGE_SIZE;
    for i in 0..pages {
        let page_va = va + i * PAGE_SIZE;
        match pmm::alloc_page() {
            Some(pa) => {
                unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
                let writable  = prot & PROT_WRITE != 0;
                let user      = true;
                let exec      = prot & PROT_EXEC  != 0;
                paging::map_page(page_va, pa, writable, user, exec);
            }
            None => { crate::serial_println!("[mmap] OOM mapping {:016x}", page_va); }
        }
    }
}

fn unmap_range(va: usize, len: usize) {
    let pages = (len + PAGE_SIZE - 1) / PAGE_SIZE;
    for i in 0..pages {
        let page_va = va + i * PAGE_SIZE;
        if let Some(pa) = paging::unmap_page(page_va) {
            pmm::free_page(pa);
        }
    }
}

fn remap_prot(va: usize, len: usize, prot: u32) {
    let pages = (len + PAGE_SIZE - 1) / PAGE_SIZE;
    for i in 0..pages {
        paging::set_page_prot(va + i * PAGE_SIZE,
            prot & PROT_WRITE != 0,
            prot & PROT_EXEC  != 0);
    }
}

// ── mmap ─────────────────────────────────────────────────────────────────

pub fn sys_mmap(addr: usize, len: usize, prot: u32, flags: u32, fd: usize, offset: usize) -> isize {
    if len == 0 { return -22; } // EINVAL
    let len_aligned = (len + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);

    let mut mm = MM.lock();

    let va = if flags & MAP_FIXED != 0 {
        if addr == 0 { return -22; }
        addr
    } else if addr != 0 {
        addr
    } else {
        // Allocate from mmap region (grow downward)
        if mm.next_map < MMAP_BOTTOM + len_aligned { return -12; } // ENOMEM
        mm.next_map -= len_aligned;
        mm.next_map
    };

    // Check for overlap and remove any conflicting VMAs (MAP_FIXED)
    if flags & MAP_FIXED != 0 {
        mm.vmas.retain(|v| v.end <= va || v.start >= va + len_aligned);
    }

    // Record VMA
    mm.vmas.push(Vma { start: va, end: va + len_aligned, prot, flags, file_backed: false });
    drop(mm);

    // Allocate and map pages
    map_range(va, len_aligned, prot);

    // File-backed mapping: copy file data
    if flags & MAP_ANONYMOUS == 0 && fd < 1000 {
        let mut tmp = alloc::vec![0u8; len_aligned];
        // Seek to offset
        crate::fs::vfs::seek(fd, offset as i64, crate::fs::vfs::SEEK_SET);
        let n = crate::fs::vfs::read(fd, &mut tmp[..len]);
        if n > 0 {
            unsafe { core::ptr::copy_nonoverlapping(tmp.as_ptr(), va as *mut u8, n as usize); }
        }
    }

    va as isize
}

// ── munmap ────────────────────────────────────────────────────────────────

pub fn sys_munmap(addr: usize, len: usize) -> isize {
    if addr % PAGE_SIZE != 0 { return -22; }
    let len_aligned = (len + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
    let mut mm = MM.lock();
    mm.vmas.retain(|v| v.end <= addr || v.start >= addr + len_aligned);
    drop(mm);
    unmap_range(addr, len_aligned);
    0
}

// ── mprotect ─────────────────────────────────────────────────────────────

pub fn sys_mprotect(addr: usize, len: usize, prot: u32) -> isize {
    if addr % PAGE_SIZE != 0 { return -22; }
    let len_aligned = (len + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
    let mut mm = MM.lock();
    for vma in mm.vmas.iter_mut() {
        if vma.start <= addr && vma.end >= addr + len_aligned {
            vma.prot = prot;
        }
    }
    drop(mm);
    remap_prot(addr, len_aligned, prot);
    0
}

// ── brk ───────────────────────────────────────────────────────────────────

pub fn sys_brk(new_brk: usize) -> isize {
    let mut mm = MM.lock();
    if new_brk == 0 { return mm.brk as isize; } // query

    let old_brk = mm.brk;
    if new_brk < old_brk {
        // Shrink heap
        let shrink_start = (new_brk + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        let shrink_end   = (old_brk + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        if shrink_end > shrink_start {
            mm.vmas.retain(|v| !(v.start >= shrink_start && v.end <= shrink_end));
            drop(mm);
            unmap_range(shrink_start, shrink_end - shrink_start);
            MM.lock().brk = new_brk;
            return new_brk as isize;
        }
    } else if new_brk > old_brk {
        // Grow heap
        let map_start = (old_brk + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        let map_end   = (new_brk + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        mm.vmas.push(Vma { start: map_start, end: map_end,
            prot: PROT_READ | PROT_WRITE, flags: MAP_PRIVATE | MAP_ANONYMOUS,
            file_backed: false });
        drop(mm);
        map_range(map_start, map_end - map_start, PROT_READ | PROT_WRITE);
        MM.lock().brk = new_brk;
        return new_brk as isize;
    }
    mm.brk as isize
}

// ── mremap (minimal — extend in place) ───────────────────────────────────

pub fn sys_mremap(old_addr: usize, old_size: usize, new_size: usize, _flags: usize) -> isize {
    if new_size > old_size {
        let extra_start = old_addr + old_size;
        let extra_len   = new_size - old_size;
        map_range(extra_start, extra_len, PROT_READ | PROT_WRITE);
        let mut mm = MM.lock();
        if let Some(v) = mm.vmas.iter_mut().find(|v| v.start == old_addr) {
            v.end = old_addr + new_size;
        }
    }
    old_addr as isize
}

// ── Query helpers for /proc/maps ──────────────────────────────────────────

pub fn snapshot() -> Vec<Vma> { MM.lock().vmas.clone() }
pub fn current_brk() -> usize { MM.lock().brk }
