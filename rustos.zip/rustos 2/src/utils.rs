//! Miscellaneous kernel utilities

pub fn align_up(val: usize, align: usize) -> usize {
    (val + align - 1) & !(align - 1)
}

pub fn align_down(val: usize, align: usize) -> usize {
    val & !(align - 1)
}

pub fn is_aligned(val: usize, align: usize) -> bool {
    val & (align - 1) == 0
}
