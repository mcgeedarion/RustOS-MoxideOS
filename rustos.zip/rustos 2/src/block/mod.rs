//! Block device abstraction
pub trait BlockDev {
    fn read_block(&self, lba: u64, buf: &mut [u8]) -> Result<(), &'static str>;
    fn write_block(&self, lba: u64, buf: &[u8])    -> Result<(), &'static str>;
    fn block_size(&self) -> usize { 512 }
}
