//! x86-64 ELF64 loader.
//!
//! Supports:
//!   ET_EXEC — static executable (fixed virtual addresses)
//!   ET_DYN  — position-independent executable (PIE) or shared object
//!   PT_INTERP — dynamic linker path; triggers two-stage load
//!   PT_PHDR   — program header table VA (passed to interpreter)
//!   PT_GNU_STACK — stack permissions (NX enforcement)
//!   PT_GNU_RELRO — read-only after relocation region
//!
//! ## Dynamic linking flow
//!
//! 1. Load the main executable's PT_LOAD segments (with a random base for PIE).
//! 2. If PT_INTERP is present, read the interpreter path (e.g.
//!    `/lib/ld-musl-x86_64.so.1`).
//! 3. Load the interpreter as a second ET_DYN image at a fresh base address.
//! 4. Build the auxiliary vector (auxv) on the user stack.
//! 5. Jump to the interpreter entry point — it resolves all relocations then
//!    jumps to the main executable's entry.

extern crate alloc;
use alloc::{string::String, vec::Vec};
use crate::mm::pmm::{self, PAGE_SIZE};
use crate::arch::x86_64::paging;

// ── ELF constants ─────────────────────────────────────────────────────────

const ELF_MAGIC: [u8; 4]  = [0x7F, b'E', b'L', b'F'];
const ELFCLASS64: u8       = 2;
const ELFDATA2LSB: u8      = 1; // little-endian
const EM_X86_64: u16       = 62;

const ET_EXEC: u16 = 2;
const ET_DYN:  u16 = 3;

const PT_NULL:      u32 = 0;
const PT_LOAD:      u32 = 1;
const PT_DYNAMIC:   u32 = 2;
const PT_INTERP:    u32 = 3;
const PT_NOTE:      u32 = 4;
const PT_PHDR:      u32 = 6;
const PT_TLS:       u32 = 7;
const PT_GNU_STACK: u32 = 0x6474_E551;
const PT_GNU_RELRO: u32 = 0x6474_E552;

const PF_X: u32 = 1;
const PF_W: u32 = 2;
const PF_R: u32 = 4;

// ── Auxiliary vector types ─────────────────────────────────────────────────

pub const AT_NULL:     u64 = 0;
pub const AT_PHDR:     u64 = 3;  // VA of program header table
pub const AT_PHENT:    u64 = 4;  // size of one program header
pub const AT_PHNUM:    u64 = 5;  // number of program headers
pub const AT_PAGESZ:   u64 = 6;  // page size
pub const AT_BASE:     u64 = 7;  // interpreter base address
pub const AT_FLAGS:    u64 = 8;
pub const AT_ENTRY:    u64 = 9;  // main executable entry
pub const AT_UID:      u64 = 11;
pub const AT_EUID:     u64 = 12;
pub const AT_GID:      u64 = 13;
pub const AT_EGID:     u64 = 14;
pub const AT_HWCAP:    u64 = 16;
pub const AT_CLKTCK:   u64 = 17;
pub const AT_SECURE:   u64 = 23;
pub const AT_RANDOM:   u64 = 25; // pointer to 16 random bytes
pub const AT_HWCAP2:   u64 = 26;
pub const AT_EXECFN:   u64 = 31; // pointer to executable filename

// ── On-disk structures ────────────────────────────────────────────────────

#[repr(C)] #[derive(Copy, Clone)]
struct Elf64Hdr {
    e_ident:     [u8; 16],
    e_type:      u16,
    e_machine:   u16,
    e_version:   u32,
    e_entry:     u64,
    e_phoff:     u64,
    e_shoff:     u64,
    e_flags:     u32,
    e_ehsize:    u16,
    e_phentsize: u16,
    e_phnum:     u16,
    e_shentsize: u16,
    e_shnum:     u16,
    e_shstrndx:  u16,
}

#[repr(C)] #[derive(Copy, Clone)]
struct Elf64Phdr {
    p_type:   u32,
    p_flags:  u32,
    p_offset: u64,
    p_vaddr:  u64,
    p_paddr:  u64,
    p_filesz: u64,
    p_memsz:  u64,
    p_align:  u64,
}

// ── Load result ────────────────────────────────────────────────────────────

pub struct LoadResult {
    /// Entry point to jump to (interpreter entry if dynamic, else main entry).
    pub entry:         usize,
    /// Main executable entry (for AT_ENTRY in auxv).
    pub main_entry:    usize,
    /// Base address the main executable was loaded at.
    pub load_base:     usize,
    /// Interpreter base address (0 if static).
    pub interp_base:   usize,
    /// VA of the main executable's program header table.
    pub phdr_va:       usize,
    pub phentsize:     usize,
    pub phnum:         usize,
    /// Top of the initially mapped data (brk starts here, page-aligned up).
    pub load_end:      usize,
    /// Interpreter path string (empty if static).
    pub interp_path:   String,
    /// Physical pages allocated during load (for COW/exec-replace accounting).
    pub owned_pages:   Vec<usize>,
}

// ── Public entry point ─────────────────────────────────────────────────────

/// Load an ELF binary into a fresh address space.
///
/// `cr3` — physical address of the new PML4 (already has kernel entries).
/// Returns `Err` with a static message on any format/resource error.
pub fn load(elf: &[u8], cr3: usize) -> Result<LoadResult, &'static str> {
    if elf.len() < core::mem::size_of::<Elf64Hdr>() { return Err("too small"); }
    let hdr = read_hdr(elf);
    if hdr.e_ident[..4] != ELF_MAGIC        { return Err("bad magic"); }
    if hdr.e_ident[4]   != ELFCLASS64       { return Err("not 64-bit"); }
    if hdr.e_ident[5]   != ELFDATA2LSB      { return Err("not LE"); }
    if hdr.e_machine    != EM_X86_64        { return Err("not x86-64"); }
    if hdr.e_type != ET_EXEC && hdr.e_type != ET_DYN { return Err("not exec/dyn"); }

    let phdrs = read_phdrs(elf, &hdr)?;

    // ── Choose load base ──────────────────────────────────────────────────
    // ET_EXEC: base = 0 (segments have absolute VAs)
    // ET_DYN:  base = random-ish address in lower 2 GiB for ASLR
    let load_base: usize = if hdr.e_type == ET_DYN {
        aslr_base()
    } else {
        0
    };

    let mut owned  = Vec::new();
    let mut load_end = 0usize;
    let mut phdr_va  = 0usize;
    let mut interp_path = String::new();

    // ── Map PT_LOAD segments ───────────────────────────────────────────────
    for ph in phdrs.iter() {
        if ph.p_type == PT_PHDR {
            phdr_va = load_base + ph.p_vaddr as usize;
        }
        if ph.p_type == PT_INTERP {
            let start = ph.p_offset as usize;
            let end   = start + ph.p_filesz as usize;
            if end > elf.len() { return Err("bad PT_INTERP"); }
            let raw = &elf[start..end];
            let nul = raw.iter().position(|&b| b==0).unwrap_or(raw.len());
            interp_path = String::from(core::str::from_utf8(&raw[..nul]).unwrap_or(""));
        }
        if ph.p_type != PT_LOAD { continue; }
        let va_start = (load_base + ph.p_vaddr as usize) & !(PAGE_SIZE - 1);
        let va_end   = (load_base + ph.p_vaddr as usize + ph.p_memsz as usize + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        let writable = ph.p_flags & PF_W != 0;
        let exec     = ph.p_flags & PF_X != 0;
        let mut va = va_start;
        while va < va_end {
            let pa = pmm::alloc_page().ok_or("OOM loading ELF")?;
            unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
            // Copy file data into this page
            let page_off = va - va_start;
            let file_start = ph.p_offset as usize + page_off;
            let copy_len   = if file_start < elf.len() {
                PAGE_SIZE.min(elf.len() - file_start).min(ph.p_filesz as usize - page_off.min(ph.p_filesz as usize))
            } else { 0 };
            if copy_len > 0 {
                unsafe { core::ptr::copy_nonoverlapping(elf.as_ptr().add(file_start), pa as *mut u8, copy_len); }
            }
            paging::map_page_in(cr3, va, pa, writable, true /* user */, exec);
            owned.push(pa);
            if va + PAGE_SIZE > load_end { load_end = va + PAGE_SIZE; }
            va += PAGE_SIZE;
        }
    }
    if load_end == 0 { return Err("no PT_LOAD"); }

    let main_entry = load_base + hdr.e_entry as usize;

    // ── Load interpreter if present ────────────────────────────────────────
    let (entry, interp_base) = if !interp_path.is_empty() {
        let interp_data = crate::fs::vfs::lookup(&interp_path)
            .ok_or("interpreter not found in VFS")?;
        let ib = load_interp(&interp_data, cr3, &mut owned, load_end)?;
        (ib.entry, ib.base)
    } else {
        (main_entry, 0)
    };

    Ok(LoadResult {
        entry, main_entry, load_base, interp_base,
        phdr_va: if phdr_va == 0 { load_base + hdr.e_phoff as usize } else { phdr_va },
        phentsize: hdr.e_phentsize as usize,
        phnum:     hdr.e_phnum    as usize,
        load_end,
        interp_path,
        owned_pages: owned,
    })
}

// ── Load interpreter (second pass) ───────────────────────────────────────

struct InterpLoad { entry: usize, base: usize }

fn load_interp(elf: &[u8], cr3: usize, owned: &mut Vec<usize>, hint: usize)
    -> Result<InterpLoad, &'static str>
{
    let hdr   = read_hdr(elf);
    let phdrs = read_phdrs(elf, &hdr)?;
    // Place interpreter above main image with some gap
    let base  = (hint + 0x10_0000 + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
    let mut top = base;
    for ph in phdrs.iter() {
        if ph.p_type != PT_LOAD { continue; }
        let va_start = (base + ph.p_vaddr as usize) & !(PAGE_SIZE - 1);
        let va_end   = (base + ph.p_vaddr as usize + ph.p_memsz as usize + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        let mut va   = va_start;
        while va < va_end {
            let pa = pmm::alloc_page().ok_or("OOM loading interp")?;
            unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
            let page_off   = va - va_start;
            let file_start = ph.p_offset as usize + page_off;
            let copy_len   = if file_start < elf.len() {
                PAGE_SIZE.min(elf.len() - file_start).min(ph.p_filesz as usize - page_off.min(ph.p_filesz as usize))
            } else { 0 };
            if copy_len > 0 {
                unsafe { core::ptr::copy_nonoverlapping(elf.as_ptr().add(file_start), pa as *mut u8, copy_len); }
            }
            paging::map_page_in(cr3, va, pa, ph.p_flags & PF_W != 0, true, ph.p_flags & PF_X != 0);
            owned.push(pa);
            if va + PAGE_SIZE > top { top = va + PAGE_SIZE; }
            va += PAGE_SIZE;
        }
    }
    Ok(InterpLoad { entry: base + hdr.e_entry as usize, base })
}

// ── Helpers ───────────────────────────────────────────────────────────────

fn read_hdr(elf: &[u8]) -> Elf64Hdr {
    unsafe { core::ptr::read_unaligned(elf.as_ptr() as *const Elf64Hdr) }
}

fn read_phdrs<'a>(elf: &'a [u8], hdr: &Elf64Hdr) -> Result<Vec<Elf64Phdr>, &'static str> {
    let off  = hdr.e_phoff as usize;
    let sz   = hdr.e_phentsize as usize;
    let n    = hdr.e_phnum as usize;
    if off + n * sz > elf.len() { return Err("phdr OOB"); }
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let ph = unsafe { core::ptr::read_unaligned(elf.as_ptr().add(off + i * sz) as *const Elf64Phdr) };
        out.push(ph);
    }
    Ok(out)
}

fn aslr_base() -> usize {
    // ASLR: pick a load base between 0x4000_0000 and 0x6000_0000
    // using the low bits of the APIC tick counter as entropy.
    let ticks = crate::arch::x86_64::apic::ticks();
    let offset = (ticks & 0x1FF) << 21; // 2 MiB aligned, up to ~1 GiB variation
    0x4000_0000 + offset as usize
}

/// Map a single page into an arbitrary CR3 without switching the current CR3.
pub fn map_page_in_cr3(cr3: usize, va: usize, pa: usize, w: bool, u: bool, x: bool) {
    paging::map_page_in(cr3, va, pa, w, u, x);
}
