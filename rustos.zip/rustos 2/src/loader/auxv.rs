//! Auxiliary vector (auxv) + initial user stack builder.
//!
//! Writes argc / argv[] / envp[] / auxv[] onto the user stack and returns
//! the new RSP that the kernel should set in the new thread's register state.

extern crate alloc;
use alloc::{string::String, vec::Vec};
use super::elf64::*;

/// All inputs the auxv builder needs.
pub struct AuxvParams<'a> {
    pub stack_top:   usize,    // VA of user stack top (exclusive)
    pub stack_size:  usize,
    pub load:        &'a crate::loader::elf64::LoadResult,
    pub argv:        &'a [String],
    pub envp:        &'a [String],
    pub execfn:      &'a str,
    pub cr3:         usize,
}

/// Returns the new RSP after writing the initial stack frame.
pub fn build(p: &AuxvParams) -> usize {
    // We write into a Vec<u64> buffer then copy to user stack pages.
    // Walking from the top downwards.

    let stack_base = p.stack_top - p.stack_size;

    // ── Allocate user stack pages ─────────────────────────────────────────
    use crate::mm::pmm::{self, PAGE_SIZE};
    let pages = p.stack_size / PAGE_SIZE;
    let mut stack_phys = Vec::new();
    for i in 0..pages {
        let pa = pmm::alloc_page().expect("OOM stack");
        unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
        crate::arch::x86_64::paging::map_page_in(
            p.cr3,
            stack_base + i * PAGE_SIZE,
            pa,
            true, true, false,
        );
        stack_phys.push(pa);
    }

    // ── Helper: push bytes at a VA (which is now mapped) ─────────────────
    let mut sp = p.stack_top;
    let push_bytes = |sp: &mut usize, data: &[u8]| {
        *sp -= data.len();
        *sp &= !(data.len().next_power_of_two().min(8) - 1); // align
        unsafe { core::ptr::copy_nonoverlapping(data.as_ptr(), *sp as *mut u8, data.len()); }
        *sp
    };
    let push_u64 = |sp: &mut usize, v: u64| {
        *sp -= 8;
        unsafe { *(*sp as *mut u64) = v; }
        *sp
    };

    // ── Write strings ────────────────────────────────────────────────────
    // 16 random bytes for AT_RANDOM
    let mut rand16 = [0u8; 16];
    for (i, b) in rand16.iter_mut().enumerate() {
        *b = (crate::arch::x86_64::apic::ticks() >> (i * 5)) as u8 ^ 0xA5;
    }
    let at_random_va = push_bytes(&mut sp, &rand16);

    let execfn_va = push_bytes(&mut sp, {
        let mut s = p.execfn.as_bytes().to_vec(); s.push(0); &s.clone()
    });

    let mut env_ptrs = Vec::new();
    for e in p.envp.iter().rev() {
        let mut s = e.as_bytes().to_vec(); s.push(0);
        env_ptrs.push(push_bytes(&mut sp, &s));
    }
    env_ptrs.reverse();

    let mut arg_ptrs = Vec::new();
    for a in p.argv.iter().rev() {
        let mut s = a.as_bytes().to_vec(); s.push(0);
        arg_ptrs.push(push_bytes(&mut sp, &s));
    }
    arg_ptrs.reverse();

    // Align stack to 16 bytes before pushing u64 values
    sp &= !15;

    // ── Auxiliary vector ──────────────────────────────────────────────────
    // AT_NULL terminator
    push_u64(&mut sp, 0); push_u64(&mut sp, AT_NULL);

    macro_rules! auxv {
        ($t:expr, $v:expr) => { push_u64(&mut sp, $v as u64); push_u64(&mut sp, $t); }
    }

    auxv!(AT_EXECFN,  execfn_va);
    auxv!(AT_RANDOM,  at_random_va);
    auxv!(AT_SECURE,  0u64);
    auxv!(AT_EGID,    0u64);
    auxv!(AT_GID,     0u64);
    auxv!(AT_EUID,    0u64);
    auxv!(AT_UID,     0u64);
    auxv!(AT_CLKTCK,  100u64);
    auxv!(AT_HWCAP,   0u64);
    auxv!(AT_FLAGS,   0u64);
    auxv!(AT_ENTRY,   p.load.main_entry as u64);
    auxv!(AT_BASE,    p.load.interp_base as u64);
    auxv!(AT_PAGESZ,  4096u64);
    auxv!(AT_PHNUM,   p.load.phnum as u64);
    auxv!(AT_PHENT,   p.load.phentsize as u64);
    auxv!(AT_PHDR,    p.load.phdr_va as u64);

    // ── envp[] ────────────────────────────────────────────────────────────
    push_u64(&mut sp, 0); // null terminator
    for &ptr in env_ptrs.iter().rev() { push_u64(&mut sp, ptr as u64); }

    // ── argv[] ────────────────────────────────────────────────────────────
    push_u64(&mut sp, 0); // null terminator
    for &ptr in arg_ptrs.iter().rev() { push_u64(&mut sp, ptr as u64); }

    // ── argc ──────────────────────────────────────────────────────────────
    push_u64(&mut sp, p.argv.len() as u64);

    sp
}
