//! ARP — address resolution protocol.
//! Maintains a static table of up to 32 entries.
extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;
use crate::net::ethernet::{self, ETHERTYPE_ARP, BCAST};

const MAX_ARP: usize = 32;

struct Entry { ip: [u8;4], mac: [u8;6] }
static TABLE: Mutex<Vec<Entry>> = Mutex::new(Vec::new());

pub fn insert(ip: [u8;4], mac: [u8;6]) {
    let mut t = TABLE.lock();
    if let Some(e) = t.iter_mut().find(|e| e.ip == ip) { e.mac = mac; return; }
    if t.len() < MAX_ARP { t.push(Entry { ip, mac }); }
}

pub fn lookup(ip: [u8;4]) -> Option<[u8;6]> {
    TABLE.lock().iter().find(|e| e.ip == ip).map(|e| e.mac)
}

pub fn announce(ip: [u8;4], mac: [u8;6]) { insert(ip, mac); }

/// Send an ARP request for `target_ip`.
pub fn request(src_ip: [u8;4], src_mac: [u8;6], target_ip: [u8;4]) {
    let mut pkt = [0u8; 28];
    pkt[0..2].copy_from_slice(&[0,1]);      // HTYPE ethernet
    pkt[2..4].copy_from_slice(&[8,0]);      // PTYPE IPv4
    pkt[4] = 6; pkt[5] = 4;                 // HLEN PLEN
    pkt[6..8].copy_from_slice(&[0,1]);      // OPER request
    pkt[8..14].copy_from_slice(&src_mac);
    pkt[14..18].copy_from_slice(&src_ip);
    pkt[24..28].copy_from_slice(&target_ip);
    let frame = ethernet::encode(BCAST, src_mac, ETHERTYPE_ARP, &pkt);
    crate::drivers::virtio_net::send(&frame);
}

/// Parse an incoming ARP packet and update the table / reply if needed.
pub fn handle(src_mac: [u8;6], pkt: &[u8], our_ip: [u8;4], our_mac: [u8;6]) {
    if pkt.len() < 28 { return; }
    let oper = u16::from_be_bytes([pkt[6], pkt[7]]);
    let sender_mac: [u8;6] = pkt[8..14].try_into().unwrap_or([0;6]);
    let sender_ip:  [u8;4] = pkt[14..18].try_into().unwrap_or([0;4]);
    insert(sender_ip, sender_mac);
    if oper == 1 { // ARP request
        let target_ip: [u8;4] = pkt[24..28].try_into().unwrap_or([0;4]);
        if target_ip == our_ip {
            // Send ARP reply
            let mut rep = [0u8; 28];
            rep[0..2].copy_from_slice(&[0,1]); rep[2..4].copy_from_slice(&[8,0]);
            rep[4]=6; rep[5]=4; rep[6..8].copy_from_slice(&[0,2]);
            rep[8..14].copy_from_slice(&our_mac);
            rep[14..18].copy_from_slice(&our_ip);
            rep[18..24].copy_from_slice(&sender_mac);
            rep[24..28].copy_from_slice(&sender_ip);
            let f = ethernet::encode(sender_mac, our_mac, ETHERTYPE_ARP, &rep);
            crate::drivers::virtio_net::send(&f);
        }
    }
}
