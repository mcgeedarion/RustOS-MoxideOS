//! Network stack — VirtIO-net → Ethernet → ARP/IPv4 → ICMP/UDP/TCP.
extern crate alloc;
use spin::Mutex;

pub mod arp;
pub mod dhcp;
pub mod dns;
pub mod ethernet;
pub mod icmp;
pub mod ipv4;
pub mod tcp;
pub mod udp;

pub struct NetConfig {
    pub ip:  [u8;4],
    pub gw:  [u8;4],
    pub mac: [u8;6],
    pub dns: [u8;4],
}

pub static STACK: Mutex<Option<NetConfig>> = Mutex::new(None);

pub fn init() {
    crate::drivers::virtio_net::init();
    let mac = match crate::drivers::virtio_net::mac() {
        Some(m) => m,
        None    => { crate::serial_println!("[net] no NIC"); return; }
    };

    crate::serial_println!("[net] running DHCP…");
    match dhcp::request() {
        Some((ip, gw, _mask)) => {
            let dns = [gw[0], gw[1], gw[2], 1]; // assume gateway is DNS too
            crate::serial_println!("[net] IP {}.{}.{}.{}  GW {}.{}.{}.{}",
                ip[0],ip[1],ip[2],ip[3], gw[0],gw[1],gw[2],gw[3]);
            *STACK.lock() = Some(NetConfig { ip, gw, mac, dns });
            arp::announce(ip, mac);
        }
        None => {
            // Static fallback: 10.0.2.15/24, GW 10.0.2.2 (QEMU default)
            let ip  = [10,0,2,15];
            let gw  = [10,0,2,2];
            let dns = [10,0,2,3];
            crate::serial_println!("[net] DHCP failed — static {}.{}.{}.{}", ip[0],ip[1],ip[2],ip[3]);
            *STACK.lock() = Some(NetConfig { ip, gw, mac, dns });
            arp::announce(ip, mac);
        }
    }
}

/// Process all pending received frames (call from timer or busy-wait loops).
pub fn poll() {
    while let Some(frame_bytes) = crate::drivers::virtio_net::recv() {
        if let Some(frame) = ethernet::decode(&frame_bytes) {
            let st = STACK.lock();
            let our_ip = st.as_ref().map(|s| s.ip).unwrap_or([0;4]);
            let our_mac = st.as_ref().map(|s| s.mac).unwrap_or([0;6]);
            drop(st);
            match frame.ethertype {
                ethernet::ETHERTYPE_ARP => arp::handle(frame.src, &frame.payload, our_ip, our_mac),
                ethernet::ETHERTYPE_IP  => {
                    if let Some(pkt) = ipv4::parse(&frame.payload) {
                        match pkt.proto {
                            1  => icmp::handle(pkt.src, pkt.payload),
                            6  => tcp::handle(pkt.src, pkt.payload),
                            17 => udp::handle(pkt.src, pkt.payload),
                            _  => {}
                        }
                    }
                }
                _ => {}
            }
        }
    }
}
