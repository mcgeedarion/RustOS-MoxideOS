//! ICMP echo request / reply.
use crate::net::{ipv4, STACK};

pub fn ping(dst: [u8;4]) -> bool {
    let payload = b"rustos ping\x00";
    let mut pkt = alloc::vec![0u8; 8 + payload.len()];
    pkt[0] = 8; // echo request
    pkt[4] = 0; pkt[5] = 1; // id
    pkt[6] = 0; pkt[7] = 1; // seq
    pkt[8..].copy_from_slice(payload);
    let ck = ipv4::checksum(&pkt);
    pkt[2..4].copy_from_slice(&ck.to_be_bytes());
    ipv4::send(dst, 1, &pkt)
}

pub fn handle(src: [u8;4], pkt: &[u8]) {
    if pkt.len() < 8 || pkt[0] != 8 { return; } // only echo request
    let mut rep = pkt.to_vec();
    rep[0] = 0; rep[2] = 0; rep[3] = 0; // echo reply, clear checksum
    let ck = ipv4::checksum(&rep);
    rep[2..4].copy_from_slice(&ck.to_be_bytes());
    ipv4::send(src, 1, &rep);
}
