//! UDP send / receive.
extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;
use crate::net::ipv4;

pub struct UdpPacket { pub src_ip: [u8;4], pub src_port: u16, pub dst_port: u16, pub data: Vec<u8> }
static RX_QUEUE: Mutex<Vec<UdpPacket>> = Mutex::new(Vec::new());

pub struct UdpSocket { pub port: u16 }
impl UdpSocket {
    pub fn new(port: u16) -> Self { Self { port } }

    pub fn send_to(&self, addr: [u8;4], port: u16, data: &[u8]) -> bool {
        let mut pkt = alloc::vec![0u8; 8 + data.len()];
        pkt[0..2].copy_from_slice(&self.port.to_be_bytes());
        pkt[2..4].copy_from_slice(&port.to_be_bytes());
        let len = (8 + data.len()) as u16;
        pkt[4..6].copy_from_slice(&len.to_be_bytes());
        pkt[8..].copy_from_slice(data);
        ipv4::send(addr, 17, &pkt)
    }

    pub fn recv(&self, timeout_ms: u32) -> Option<UdpPacket> {
        for _ in 0..timeout_ms * 10_000 {
            let mut q = RX_QUEUE.lock();
            if let Some(idx) = q.iter().position(|p| p.dst_port == self.port) {
                return Some(q.remove(idx));
            }
            drop(q);
            core::hint::spin_loop();
            crate::net::poll();
        }
        None
    }
}

pub fn handle(src_ip: [u8;4], pkt: &[u8]) {
    if pkt.len() < 8 { return; }
    let src_port = u16::from_be_bytes([pkt[0],pkt[1]]);
    let dst_port = u16::from_be_bytes([pkt[2],pkt[3]]);
    let len      = u16::from_be_bytes([pkt[4],pkt[5]]) as usize;
    let data_end = len.min(pkt.len());
    RX_QUEUE.lock().push(UdpPacket {
        src_ip, src_port, dst_port, data: pkt[8..data_end].to_vec()
    });
}
