//! DNS resolver — single A-record query over UDP port 53.
extern crate alloc;
use alloc::vec::Vec;
use crate::net::udp::UdpSocket;

pub fn resolve(hostname: &str) -> Option<[u8;4]> {
    let dns_ip = crate::net::STACK.lock().as_ref().map(|s| s.dns)?;
    let mut pkt = alloc::vec![0u8; 512];
    pkt[0..2].copy_from_slice(&[0x12, 0x34]); // ID
    pkt[2..4].copy_from_slice(&[0x01, 0x00]); // standard query
    pkt[4..6].copy_from_slice(&[0x00, 0x01]); // QDCOUNT=1
    // Encode QNAME
    let mut pos = 12usize;
    for label in hostname.split('.') {
        if label.is_empty() { continue; }
        pkt[pos] = label.len() as u8; pos += 1;
        pkt[pos..pos+label.len()].copy_from_slice(label.as_bytes());
        pos += label.len();
    }
    pkt[pos] = 0; pos += 1;
    pkt[pos..pos+2].copy_from_slice(&[0,1]); pos += 2; // QTYPE A
    pkt[pos..pos+2].copy_from_slice(&[0,1]); pos += 2; // QCLASS IN

    let sock = UdpSocket::new(0xDEAD); // ephemeral
    sock.send_to(dns_ip, 53, &pkt[..pos]);

    let resp = sock.recv(2000)?;
    let d = &resp.data;
    if d.len() < 12 { return None; }
    let ancount = u16::from_be_bytes([d[6], d[7]]) as usize;
    if ancount == 0 { return None; }
    // Skip question section
    let mut p = 12;
    while p < d.len() && d[p] != 0 { p += d[p] as usize + 1; }
    p += 5; // null label + QTYPE + QCLASS
    // Parse first answer
    for _ in 0..ancount {
        if p + 10 > d.len() { break; }
        p += 2; // name (compressed pointer or label)
        let rtype = u16::from_be_bytes([d[p], d[p+1]]); p += 2;
        p += 2; // class
        p += 4; // TTL
        let rdlen = u16::from_be_bytes([d[p], d[p+1]]) as usize; p += 2;
        if rtype == 1 && rdlen == 4 && p + 4 <= d.len() {
            return Some([d[p],d[p+1],d[p+2],d[p+3]]);
        }
        p += rdlen;
    }
    None
}
