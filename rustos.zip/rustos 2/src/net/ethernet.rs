//! Ethernet frame encode / decode.
extern crate alloc;
use alloc::vec::Vec;

pub const ETHERTYPE_IP:  u16 = 0x0800;
pub const ETHERTYPE_ARP: u16 = 0x0806;
pub const BCAST: [u8; 6] = [0xFF; 6];

pub struct Frame { pub dst: [u8; 6], pub src: [u8; 6], pub ethertype: u16, pub payload: Vec<u8> }

pub fn encode(dst: [u8;6], src: [u8;6], etype: u16, payload: &[u8]) -> Vec<u8> {
    let mut f = Vec::with_capacity(14 + payload.len());
    f.extend_from_slice(&dst);
    f.extend_from_slice(&src);
    f.push((etype >> 8) as u8); f.push((etype & 0xFF) as u8);
    f.extend_from_slice(payload);
    f
}

pub fn decode(raw: &[u8]) -> Option<Frame> {
    if raw.len() < 14 { return None; }
    Some(Frame {
        dst:       raw[0..6].try_into().ok()?,
        src:       raw[6..12].try_into().ok()?,
        ethertype: u16::from_be_bytes([raw[12], raw[13]]),
        payload:   raw[14..].to_vec(),
    })
}
