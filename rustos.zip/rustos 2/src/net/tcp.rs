//! Minimal TCP — SYN/SYN-ACK/ACK handshake, data send/recv, FIN teardown.
//! One socket at a time per port (no concurrent accept).
extern crate alloc;
use alloc::vec::Vec;
use core::sync::atomic::{AtomicU16, Ordering};
use spin::Mutex;
use crate::net::{ipv4, STACK};

// ── State machine ─────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum State { Closed, Listen, SynSent, SynReceived, Established, FinWait1, FinWait2, CloseWait, LastAck, TimeWait }

const F_FIN: u8 = 0x01; const F_SYN: u8 = 0x02; const F_RST: u8 = 0x04;
const F_PSH: u8 = 0x08; const F_ACK: u8 = 0x10;

#[derive(Clone)]
pub struct TcpSocket {
    pub local_port:  u16,
    pub remote_ip:   [u8;4],
    pub remote_port: u16,
    pub state:       State,
    pub snd_seq:     u32,
    pub rcv_seq:     u32,  // next expected from remote
    pub rx_buf:      Vec<u8>,
}

static SOCKETS: Mutex<Vec<TcpSocket>> = Mutex::new(Vec::new());
static EPHEMERAL: AtomicU16 = AtomicU16::new(49152);

fn alloc_port() -> u16 { EPHEMERAL.fetch_add(1, Ordering::SeqCst) }

// ── Packet builder ────────────────────────────────────────────────────────

fn build_segment(
    src_ip: [u8;4], src_port: u16,
    dst_ip: [u8;4], dst_port: u16,
    seq: u32, ack: u32, flags: u8,
    data: &[u8],
) -> Vec<u8> {
    let mut seg = alloc::vec![0u8; 20 + data.len()];
    seg[0..2].copy_from_slice(&src_port.to_be_bytes());
    seg[2..4].copy_from_slice(&dst_port.to_be_bytes());
    seg[4..8].copy_from_slice(&seq.to_be_bytes());
    seg[8..12].copy_from_slice(&ack.to_be_bytes());
    seg[12] = 0x50; // data offset = 5 (20 bytes), no options
    seg[13] = flags;
    seg[14..16].copy_from_slice(&4096u16.to_be_bytes()); // window
    seg[20..].copy_from_slice(data);

    // TCP checksum over pseudo-header
    let ck = tcp_checksum(src_ip, dst_ip, &seg);
    seg[16..18].copy_from_slice(&ck.to_be_bytes());
    seg
}

fn tcp_checksum(src: [u8;4], dst: [u8;4], seg: &[u8]) -> u16 {
    let seg_len = seg.len() as u16;
    let mut sum = 0u32;
    // Pseudo-header: src, dst, zero, proto=6, tcp_len
    for i in (0..4).step_by(2) {
        sum += u16::from_be_bytes([src[i],src[i+1]]) as u32;
        sum += u16::from_be_bytes([dst[i],dst[i+1]]) as u32;
    }
    sum += 6u32; // TCP protocol number
    sum += seg_len as u32;
    for i in (0..seg.len()).step_by(2) {
        let w = if i+1 < seg.len() { u16::from_be_bytes([seg[i],seg[i+1]]) }
                else { (seg[i] as u16) << 8 };
        sum += w as u32;
    }
    while sum >> 16 != 0 { sum = (sum & 0xFFFF) + (sum >> 16); }
    !(sum as u16)
}

// ── Public API ────────────────────────────────────────────────────────────

impl TcpSocket {
    pub fn new(port: u16) -> Self {
        Self { local_port: port, remote_ip: [0;4], remote_port: 0,
               state: State::Closed, snd_seq: 0xC0DE_0000, rcv_seq: 0,
               rx_buf: Vec::new() }
    }

    /// Active connect: SYN → wait SYN-ACK → ACK.
    pub fn connect(&mut self, addr: [u8;4], port: u16) -> bool {
        let st = STACK.lock();
        let (our_ip, _) = match st.as_ref() { Some(s) => (s.ip, s.mac), None => return false };
        drop(st);

        self.remote_ip   = addr;
        self.remote_port = port;
        self.local_port  = alloc_port();
        self.state       = State::SynSent;
        self.snd_seq     = 0xC0DE_0000;

        let seg = build_segment(our_ip, self.local_port, addr, port,
                                self.snd_seq, 0, F_SYN, &[]);
        ipv4::send(addr, 6, &seg);
        self.snd_seq = self.snd_seq.wrapping_add(1);

        // Wait for SYN-ACK
        for _ in 0..200_000u32 {
            crate::net::poll();
            if self.state == State::Established { return true; }
            core::hint::spin_loop();
        }
        self.state = State::Closed;
        false
    }

    /// Passive listen: wait for SYN (blocking).
    pub fn listen(port: u16) -> TcpSocket {
        let mut s = TcpSocket::new(port);
        s.state = State::Listen;
        s
    }

    pub fn accept(&mut self) -> bool {
        for _ in 0..2_000_000u32 {
            crate::net::poll();
            if self.state == State::Established { return true; }
            core::hint::spin_loop();
        }
        false
    }

    pub fn send(&mut self, data: &[u8]) -> bool {
        if self.state != State::Established { return false; }
        let st = STACK.lock();
        let (our_ip, _) = match st.as_ref() { Some(s) => (s.ip, s.mac), None => return false };
        drop(st);
        let seg = build_segment(our_ip, self.local_port,
                                self.remote_ip, self.remote_port,
                                self.snd_seq, self.rcv_seq, F_PSH | F_ACK, data);
        self.snd_seq = self.snd_seq.wrapping_add(data.len() as u32);
        ipv4::send(self.remote_ip, 6, &seg)
    }

    pub fn recv(&mut self, timeout_ms: u32) -> Vec<u8> {
        for _ in 0..timeout_ms * 10_000 {
            crate::net::poll();
            if !self.rx_buf.is_empty() { return core::mem::take(&mut self.rx_buf); }
            core::hint::spin_loop();
        }
        Vec::new()
    }

    pub fn close(&mut self) {
        if self.state != State::Established { self.state = State::Closed; return; }
        let st = STACK.lock();
        let (our_ip, _) = match st.as_ref() { Some(s) => (s.ip, s.mac), None => { self.state = State::Closed; return; } };
        drop(st);
        let seg = build_segment(our_ip, self.local_port,
                                self.remote_ip, self.remote_port,
                                self.snd_seq, self.rcv_seq, F_FIN | F_ACK, &[]);
        self.snd_seq = self.snd_seq.wrapping_add(1);
        self.state = State::FinWait1;
        ipv4::send(self.remote_ip, 6, &seg);
    }
}

// ── Incoming segment handler ──────────────────────────────────────────────

pub fn handle(src_ip: [u8;4], pkt: &[u8]) {
    if pkt.len() < 20 { return; }
    let src_port = u16::from_be_bytes([pkt[0], pkt[1]]);
    let dst_port = u16::from_be_bytes([pkt[2], pkt[3]]);
    let seq      = u32::from_be_bytes([pkt[4], pkt[5], pkt[6], pkt[7]]);
    let ack_num  = u32::from_be_bytes([pkt[8], pkt[9], pkt[10], pkt[11]]);
    let data_off = ((pkt[12] >> 4) * 4) as usize;
    let flags    = pkt[13];
    let payload  = if data_off < pkt.len() { &pkt[data_off..] } else { &[] };

    let st_guard = STACK.lock();
    let our_ip = match st_guard.as_ref() { Some(s) => s.ip, None => return };
    drop(st_guard);

    let mut sockets = SOCKETS.lock();
    // Find matching socket (listening or connected)
    let idx = sockets.iter().position(|s|
        s.local_port == dst_port
        && (s.state == State::Listen
            || (s.remote_ip == src_ip && s.remote_port == src_port))
    );
    let Some(i) = idx else { return };
    let s = &mut sockets[i];

    match s.state {
        State::Listen if flags & F_SYN != 0 => {
            s.remote_ip   = src_ip;
            s.remote_port = src_port;
            s.rcv_seq     = seq.wrapping_add(1);
            s.state       = State::SynReceived;
            let seg = build_segment(our_ip, dst_port, src_ip, src_port,
                                    s.snd_seq, s.rcv_seq, F_SYN | F_ACK, &[]);
            s.snd_seq = s.snd_seq.wrapping_add(1);
            drop(sockets);
            ipv4::send(src_ip, 6, &seg);
        }
        State::SynReceived if flags & F_ACK != 0 => {
            s.state = State::Established;
        }
        State::SynSent if flags & (F_SYN | F_ACK) == F_SYN | F_ACK => {
            s.rcv_seq = seq.wrapping_add(1);
            s.state   = State::Established;
            let seg = build_segment(our_ip, s.local_port, src_ip, src_port,
                                    s.snd_seq, s.rcv_seq, F_ACK, &[]);
            drop(sockets);
            ipv4::send(src_ip, 6, &seg);
        }
        State::Established => {
            if !payload.is_empty() {
                s.rx_buf.extend_from_slice(payload);
                s.rcv_seq = s.rcv_seq.wrapping_add(payload.len() as u32);
                let seg = build_segment(our_ip, dst_port, src_ip, src_port,
                                        s.snd_seq, s.rcv_seq, F_ACK, &[]);
                drop(sockets);
                ipv4::send(src_ip, 6, &seg);
                return;
            }
            if flags & F_FIN != 0 {
                s.rcv_seq = s.rcv_seq.wrapping_add(1);
                s.state   = State::CloseWait;
                let seg = build_segment(our_ip, dst_port, src_ip, src_port,
                                        s.snd_seq, s.rcv_seq, F_ACK, &[]);
                drop(sockets);
                ipv4::send(src_ip, 6, &seg);
            }
        }
        State::FinWait1 if flags & F_ACK != 0 => { s.state = State::FinWait2; }
        State::FinWait2 if flags & F_FIN != 0 => {
            s.rcv_seq = seq.wrapping_add(1);
            s.state   = State::TimeWait;
            let seg = build_segment(our_ip, dst_port, src_ip, src_port,
                                    s.snd_seq, s.rcv_seq, F_ACK, &[]);
            drop(sockets);
            ipv4::send(src_ip, 6, &seg);
        }
        _ => {}
    }
}

pub fn register(s: TcpSocket) { SOCKETS.lock().push(s); }
pub fn remove(port: u16) { SOCKETS.lock().retain(|s| s.local_port != port); }
