//! IPv4 packet builder + sender.
extern crate alloc;
use alloc::vec::Vec;
use crate::net::{arp, ethernet, STACK};

pub fn checksum(hdr: &[u8]) -> u16 {
    let mut sum = 0u32;
    for i in (0..hdr.len()).step_by(2) {
        let w = if i+1 < hdr.len() { u16::from_be_bytes([hdr[i],hdr[i+1]]) } else { (hdr[i] as u16) << 8 };
        sum += w as u32;
    }
    while sum >> 16 != 0 { sum = (sum & 0xFFFF) + (sum >> 16); }
    !(sum as u16)
}

pub fn send(dst_ip: [u8;4], proto: u8, payload: &[u8]) -> bool {
    let st = STACK.lock();
    let (our_ip, our_mac) = match st.as_ref() { Some(s) => (s.ip, s.mac), None => return false };
    drop(st);

    let total = 20 + payload.len();
    let mut hdr = [0u8; 20];
    hdr[0] = 0x45; hdr[1] = 0;
    let len = total as u16;
    hdr[2..4].copy_from_slice(&len.to_be_bytes());
    hdr[8] = 64; hdr[9] = proto;
    hdr[12..16].copy_from_slice(&our_ip);
    hdr[16..20].copy_from_slice(&dst_ip);
    let cksum = checksum(&hdr);
    hdr[10..12].copy_from_slice(&cksum.to_be_bytes());

    let dst_mac = arp::lookup(dst_ip).unwrap_or_else(|| {
        arp::request(our_ip, our_mac, dst_ip);
        // Wait a bit for reply (busy-wait up to ~1 ms worth of iterations)
        for _ in 0..100_000 { core::hint::spin_loop(); }
        arp::lookup(dst_ip).unwrap_or([0xFF;6])
    });

    let mut frame_payload = Vec::with_capacity(total);
    frame_payload.extend_from_slice(&hdr);
    frame_payload.extend_from_slice(payload);
    let frame = ethernet::encode(dst_mac, our_mac, ethernet::ETHERTYPE_IP, &frame_payload);
    crate::drivers::virtio_net::send(&frame)
}

pub struct Packet<'a> { pub src: [u8;4], pub dst: [u8;4], pub proto: u8, pub payload: &'a [u8] }

pub fn parse(raw: &[u8]) -> Option<Packet<'_>> {
    if raw.len() < 20 { return None; }
    let ihl = (raw[0] & 0xF) as usize * 4;
    if raw.len() < ihl { return None; }
    let total = u16::from_be_bytes([raw[2],raw[3]]) as usize;
    let end = total.min(raw.len());
    Some(Packet {
        src:     raw[12..16].try_into().ok()?,
        dst:     raw[16..20].try_into().ok()?,
        proto:   raw[9],
        payload: &raw[ihl..end],
    })
}
