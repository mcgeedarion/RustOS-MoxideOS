//! DHCP client — DISCOVER / OFFER / REQUEST / ACK over UDP.
extern crate alloc;
use alloc::vec::Vec;
use crate::net::udp::UdpSocket;

pub fn request() -> Option<([u8;4], [u8;4], [u8;4])> {
    // Returns (our_ip, gateway, subnet_mask)
    let xid: u32 = 0xDEAD_C0DE;
    let mac = crate::drivers::virtio_net::mac()?;

    let mut disc = alloc::vec![0u8; 300];
    disc[0] = 1;          // BOOTREQUEST
    disc[1] = 1;          // Ethernet
    disc[2] = 6;          // MAC length
    disc[3] = 0;          // hops
    disc[4..8].copy_from_slice(&xid.to_be_bytes());
    disc[28..34].copy_from_slice(&mac);
    // Magic cookie
    disc[236..240].copy_from_slice(&[99,130,83,99]);
    // Option 53: DHCP DISCOVER
    disc[240] = 53; disc[241] = 1; disc[242] = 1;
    disc[243] = 255; // END

    let sock = UdpSocket::new(68);
    sock.send_to([255;4], 67, &disc);

    // Wait for OFFER
    let offer = sock.recv(2000)?;
    let offered_ip: [u8;4] = offer.data[16..20].try_into().ok()?;

    // Build REQUEST
    let mut req = alloc::vec![0u8; 300];
    req[0] = 1; req[1] = 1; req[2] = 6;
    req[4..8].copy_from_slice(&xid.to_be_bytes());
    req[28..34].copy_from_slice(&mac);
    req[236..240].copy_from_slice(&[99,130,83,99]);
    req[240] = 53; req[241] = 1; req[242] = 3;  // DHCP REQUEST
    req[243] = 50; req[244] = 4; req[245..249].copy_from_slice(&offered_ip); // Requested IP
    req[249] = 255;
    sock.send_to([255;4], 67, &req);

    // Wait for ACK
    let ack = sock.recv(2000)?;
    if ack.data.len() < 240 { return None; }
    let our_ip: [u8;4]   = ack.data[16..20].try_into().ok()?;

    // Parse options for gateway + subnet
    let mut gw = [0u8;4]; let mut mask = [255u8,255,255,0];
    let mut i = 240;
    while i + 1 < ack.data.len() {
        let opt = ack.data[i]; let len = ack.data[i+1] as usize;
        if opt == 1 && len == 4 { mask.copy_from_slice(&ack.data[i+2..i+6]); }
        if opt == 3 && len == 4 { gw.copy_from_slice(&ack.data[i+2..i+6]); }
        if opt == 255 { break; }
        i += 2 + len;
    }
    Some((our_ip, gw, mask))
}
