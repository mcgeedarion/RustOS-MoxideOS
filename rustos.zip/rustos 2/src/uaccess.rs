//! Safe user-space memory access helpers.
//!
//! All public functions return Result<_, ()> so callers cannot silently
//! ignore faults (fixes audit finding #2).
//!
//! validate_user_ptr no longer rejects len==0 — zero-length is valid
//! and callers are responsible for early-exit semantics (fixes finding #4).
//!
//! strncpy_from_user validates the entire range up-front, then reads,
//! eliminating the per-byte TOCTOU window (fixes finding #3).
use crate::mm::vmm;

/// Return true iff [va, va+len) is a valid user-space range.
/// A zero-length range passes if va itself is in user space.
pub fn validate_user_ptr(va: usize, len: usize) -> bool {
    if va == 0 { return false; }
    // For len==0 just check the base address is in user space
    if len == 0 { return vmm::is_user_range(va, 1); }
    vmm::is_user_range(va, len)
}

/// Copy `dst.len()` bytes from user address `src` into `dst`.
/// Returns `Ok(n)` on success, `Err(())` if the range fails validation.
pub fn copy_from_user(dst: &mut [u8], src: usize) -> Result<usize, ()> {
    let len = dst.len();
    if len == 0 { return Ok(0); }
    if !validate_user_ptr(src, len) { return Err(()); }
    unsafe {
        core::ptr::copy_nonoverlapping(src as *const u8, dst.as_mut_ptr(), len);
    }
    Ok(len)
}

/// Copy `src.len()` bytes from `src` into user address `dst`.
/// Returns `Ok(n)` on success, `Err(())` if the range fails validation.
pub fn copy_to_user(dst: usize, src: &[u8]) -> Result<usize, ()> {
    let len = src.len();
    if len == 0 { return Ok(0); }
    if !validate_user_ptr(dst, len) { return Err(()); }
    unsafe {
        core::ptr::copy_nonoverlapping(src.as_ptr(), dst as *mut u8, len);
    }
    Ok(len)
}

/// Copy a NUL-terminated string from user space into `buf`.
/// Validates the entire maximum range up-front (no per-byte TOCTOU).
/// Returns `Ok(len)` where len excludes the NUL, or `Err(())` on fault/overflow.
pub fn strncpy_from_user(buf: &mut [u8], src: usize) -> Result<usize, ()> {
    if src == 0 || buf.is_empty() { return Err(()); }
    let max = buf.len();
    // Validate the entire window once before touching any byte
    if !validate_user_ptr(src, max) { return Err(()); }
    for i in 0..max {
        let byte = unsafe { core::ptr::read_volatile((src + i) as *const u8) };
        buf[i] = byte;
        if byte == 0 { return Ok(i); } // return length excluding NUL
    }
    // No NUL found within max bytes — treat as error (not NUL-terminated)
    Err(())
}
