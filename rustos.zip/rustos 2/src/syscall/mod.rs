//! Syscall dispatcher — RISC-V and x86_64 paths share implementations.
//!
//! # RISC-V
//! `handle(tf)` — called from trap_handler on ecall (scause=8).
//!   Reads nr/args from tf.regs[17,10..15], writes result to tf.regs[10].
//!
//! # x86_64
//! `handle_x86(frame)` — called from syscall_rust_handler (SYSCALL fast-path).
//!   Reads nr from frame.rax, args from frame.rdi/rsi/rdx/r10/r8/r9.
//!   Returns isize; caller stores in frame.rax.
//!
//! Both paths share the sys_* implementations below.

#![allow(unused_imports)]

use crate::mm::pmm::PAGE_SIZE;
use crate::security::{CapSet, Caps};
use crate::uaccess::{validate_user_ptr, copy_from_user, copy_to_user, strncpy_from_user};

// ── Syscall numbers (Linux/RISC-V64 ABI — reused on x86_64 for simplicity) ─

pub const SYS_IOCTL:   usize = 16;
pub const SYS_READ:    usize = 63;
pub const SYS_WRITE:   usize = 64;
pub const SYS_OPENAT:  usize = 56;
pub const SYS_CLOSE:   usize = 57;
pub const SYS_EXECVE:  usize = 221;
pub const SYS_EXIT:    usize = 93;
pub const SYS_GETPID:  usize = 172;

pub const SYS_CLONE:       usize = 56;
pub const SYS_FUTEX:       usize = 202;
pub const SYS_GETTID:      usize = 186;
pub const SYS_TGKILL:      usize = 234;
pub const SYS_EXIT_GROUP:  usize = 231;
pub const SYS_TKILL:       usize = 200;
pub const SYS_SCHED_YIELD: usize = 24;
pub const SYS_NANOSLEEP:   usize = 35;
pub const SYS_GETPPID:     usize = 110;
pub const SYS_GETUID:      usize = 102;
pub const SYS_GETGID:      usize = 104;
pub const SYS_GETEUID:     usize = 107;
pub const SYS_GETEGID:     usize = 108;
pub const SYS_MMAP:      usize = 9;
pub const SYS_MPROTECT:  usize = 10;
pub const SYS_MREMAP:    usize = 25;

pub const SYS_MUNMAP:    usize = 11;
pub const SYS_BRK:       usize = 12;
pub const SYS_FORK:    usize = 220;   // clone-lite stub


pub const SYS_DUP2:    usize = 33;
pub const SYS_GETPID:  usize = 39;
pub const SYS_SOCKET:   usize = 41;
pub const SYS_BIND:     usize = 49;
pub const SYS_CONNECT:  usize = 42;
pub const SYS_ACCEPT:   usize = 43;
pub const SYS_SENDTO:   usize = 44;
pub const SYS_RECVFROM: usize = 45;
pub const SYS_PIPE:     usize = 22;
pub const SYS_WAITPID: usize = 260;
pub const SYS_YIELD:   usize = 124;
pub const SYS_UNAME:   usize = 160;

pub const SYS_FSTAT:   usize = 80;
pub const SYS_LSEEK:   usize = 62;
pub const SYS_GETCWD:  usize = 17;
pub const SYS_CHDIR:   usize = 49;
pub const SYS_GETDENTS:usize = 217;


pub const SYS_KILL:        usize = 129;
pub const SYS_SIGACTION:   usize = 134;
pub const SYS_SIGPROCMASK: usize = 135;
pub const SYS_SIGRETURN:   usize = 139;


pub const SYS_DUP2:    usize = 33;
pub const SYS_GETPID:  usize = 39;
pub const SYS_SOCKET:   usize = 41;
pub const SYS_BIND:     usize = 49;
pub const SYS_CONNECT:  usize = 42;
pub const SYS_ACCEPT:   usize = 43;
pub const SYS_SENDTO:   usize = 44;
pub const SYS_RECVFROM: usize = 45;
pub const SYS_PIPE:     usize = 22;
pub const SYS_WAITPID:     usize = 260;  // waitid/waitpid


const MAX_RW: usize = PAGE_SIZE * 1024; // 4 MiB per read/write

// ── Capability helper ─────────────────────────────────────────────────────

fn current_caps() -> CapSet {
    let pid = crate::proc::scheduler::current_pid();
    if pid == 0 { return CapSet::empty(); }
    if let Some(procs) = crate::proc::scheduler::current_mut() {
        if let Some(p) = procs.iter().find(|p| p.pid == pid) {
            return p.caps;
        }
    }
    CapSet::empty()
}

// ── RISC-V dispatch ───────────────────────────────────────────────────────

#[cfg(target_arch = "riscv64")]
pub fn handle(tf: &mut crate::arch::riscv64::trap::TrapFrame) {
    let nr = tf.regs[17];
    let a0 = tf.regs[10];
    let a1 = tf.regs[11];
    let a2 = tf.regs[12];
    let a3 = tf.regs[13];
    let a4 = tf.regs[14];

    let ret: isize = dispatch(nr, a0, a1, a2, a3, a4);
    tf.regs[10] = ret as usize;
}

// ── x86_64 dispatch ───────────────────────────────────────────────────────

#[cfg(target_arch = "x86_64")]
pub fn handle_x86(
    frame: &mut crate::arch::x86_64::syscall::SyscallFrame,
) -> isize {
    let nr = frame.rax  as usize;
    let a0 = frame.rdi  as usize;
    let a1 = frame.rsi  as usize;
    let a2 = frame.rdx  as usize;
    let a3 = frame.r10  as usize;  // Linux x86-64 ABI uses r10 for arg3
    let a4 = frame.r8   as usize;

    // x86_64 fork/execve need the full register frame
    match nr {
        SYS_FORK   => return crate::proc::fork::do_fork(frame),
        SYS_EXECVE => return crate::proc::fork::do_execve(a0, a1, a2, frame),
        _ => {}
    }
    dispatch(nr, a0, a1, a2, a3, a4)
}

// ── Shared dispatcher ─────────────────────────────────────────────────────

fn dispatch(nr: usize, a0: usize, a1: usize, a2: usize, a3: usize, a4: usize) -> isize {
    // fork/execve handled below at x86-specific call sites — fallthrough to stubs on riscv
    match nr {
        SYS_READ    => sys_read_fd(a0, a1, a2),
        SYS_WRITE   => sys_write_fd(a0, a1, a2),
        SYS_OPENAT  => sys_openat_vfs(a0, a1 as *const u8, a2 as u32),
        SYS_CLOSE   => { crate::fs::vfs::close(a0) }
        SYS_EXECVE  => sys_execve_stub(), // x86: intercepted in handle_x86 before dispatch
        SYS_EXIT    => sys_exit(a0 as i32),
        SYS_GETPID  => crate::proc::scheduler::current_pid() as isize,
        SYS_MMAP      => crate::mm::mmap::sys_mmap(a0, a1, a2 as u32, a3 as u32, a4, a5),
        SYS_MUNMAP    => crate::mm::mmap::sys_munmap(a0, a1),
        SYS_BRK       => crate::mm::mmap::sys_brk(a0),
        SYS_MPROTECT  => crate::mm::mmap::sys_mprotect(a0, a1, a2 as u32),
        SYS_MREMAP    => crate::mm::mmap::sys_mremap(a0, a1, a2, a3),
        SYS_FORK    => sys_fork_stub(),   // x86: intercepted in handle_x86 before dispatch
        SYS_WAITPID => -1,              // ECHILD — no child yet
        SYS_YIELD   => { crate::proc::scheduler::current_yield(); 0 }
        SYS_KILL        => crate::proc::signal::sys_kill(a0 as u32, a1 as u8),
        SYS_SIGACTION   => crate::proc::signal::sys_sigaction(a0 as u8, a1),
        SYS_SIGPROCMASK => crate::proc::signal::sys_sigprocmask(a0, a1 as u64),
        SYS_SIGRETURN   => sys_sigreturn(),
        SYS_WAITPID     => crate::proc::wait::sys_waitpid(a0 as i32, a1, a2),

        SYS_DUP2    => sys_dup2(a0, a1),
        SYS_GETPID  => crate::proc::scheduler::current_pid() as isize,
        SYS_SOCKET   => sys_socket(a0, a1, a2),
        SYS_BIND     => sys_bind(a0, a1),
        SYS_CONNECT  => sys_connect(a0, a1, a2 as u16),
        SYS_ACCEPT   => sys_accept(a0),
        SYS_SENDTO   => sys_sendto(a0, a1, a2, a3),
        SYS_RECVFROM => sys_recvfrom(a0, a1, a2, a3),
        SYS_PIPE     => sys_pipe(a0),
        SYS_FSTAT    => sys_fstat(a0, a1),
        SYS_IOCTL    => sys_ioctl(a0, a1, a2),
        SYS_LSEEK    => sys_lseek(a0, a1 as i64, a2 as i32),
        SYS_GETCWD   => sys_getcwd(a0, a1),
        SYS_GETDENTS => sys_getdents(a0, a1, a2),
        SYS_UNAME   => sys_uname(a0 as *mut u8),
        _           => {
            crate::serial_println!("[syscall] unimplemented nr={}", nr);
            -38 // ENOSYS
        }
    }
}


// ── POSIX/musl compat syscall numbers ────────────────────────────────────
pub const SYS_STAT:       usize = 4;
pub const SYS_LSTAT:      usize = 6;
pub const SYS_POLL:       usize = 7;
pub const SYS_ACCESS:     usize = 21;
pub const SYS_SELECT:     usize = 23;
pub const SYS_READLINK:   usize = 89;
pub const SYS_CHMOD:      usize = 90;
pub const SYS_UMASK:      usize = 95;
pub const SYS_GETRLIMIT:  usize = 97;
pub const SYS_GETRUSAGE:  usize = 98;
pub const SYS_TIMES:      usize = 100;
pub const SYS_FCNTL:      usize = 72;
pub const SYS_TRUNCATE:   usize = 76;
pub const SYS_FTRUNCATE:  usize = 77;
pub const SYS_RENAME:     usize = 82;
pub const SYS_MKDIR:      usize = 83;
pub const SYS_RMDIR:      usize = 84;
pub const SYS_LINK:       usize = 86;
pub const SYS_UNLINK:     usize = 87;
pub const SYS_SYMLINK:    usize = 88;
pub const SYS_SETRLIMIT:  usize = 160;
pub const SYS_TIME:       usize = 201;
pub const SYS_READLINKAT: usize = 267;
pub const SYS_FACCESSAT:  usize = 269;
pub const SYS_NEWFSTATAT: usize = 262;
pub const SYS_UNLINKAT:   usize = 263;
pub const SYS_MKDIRAT:    usize = 258;
pub const SYS_RENAMEAT:   usize = 264;
pub const SYS_OPENAT2:    usize = 437;


// ── Dynamic linker extension syscalls ────────────────────────────────────
pub const SYS_MMAP2:  usize = 192;  // 32-bit compat mmap (some ld.so use it)
pub const SYS_OPENAT: usize = 257;
pub const SYS_FSTAT:  usize = 5;    // already present but ensure number right
pub const SYS_LSEEK:  usize = 8;    // needed by ld.so file I/O
pub const SYS_READV:  usize = 19;
pub const SYS_PREAD64:usize = 17;
pub const SYS_PREAD:  usize = 17;   // alias

// ── musl/glibc compat stubs ───────────────────────────────────────────────

pub const SYS_MADVISE:        usize = 28;
pub const SYS_SET_TID_ADDRESS:usize = 218;
pub const SYS_SET_ROBUST_LIST:usize = 273;
pub const SYS_RT_SIGPROCMASK: usize = 14;
pub const SYS_CLOCK_GETTIME:  usize = 228;
pub const SYS_GETTIMEOFDAY:   usize = 96;
pub const SYS_PRLIMIT64:      usize = 302;
pub const SYS_GETRANDOM:      usize = 318;
pub const SYS_ARCH_PRCTL:     usize = 158;

// ── sys_exit ─────────────────────────────────────────────────────────────

fn sys_exit(code: i32) -> isize {
    crate::proc::scheduler::exit(code);
    0
}

// ── sys_yield ────────────────────────────────────────────────────────────
// (scheduler::current_yield is defined in scheduler.rs below)

// ── sys_read ─────────────────────────────────────────────────────────────

fn sys_read(fd: usize, buf: usize, count: usize) -> isize {
    if fd != 0 { return -9; } // EBADF
    if count == 0 { return 0; }
    let max = count.min(MAX_RW);
    if !validate_user_ptr(buf, max) { return -14; } // EFAULT

    const STAGE: usize = 256;
    let mut tmp = [0u8; STAGE];
    let mut total = 0usize;

    while total < max {
        let batch = (max - total).min(STAGE);
        let mut n = 0usize;
        while n < batch {
            let c = get_char();
            let b = if c == b'\r' { b'\n' } else { c };
            if b == b'\n' {
                put_char(b'\n');
            } else if b == 0x7f || b == 0x08 {
                if n > 0 { n -= 1; put_str("\x08 \x08"); }
                continue;
            } else {
                put_char(b);
            }
            tmp[n] = b; n += 1;
            if b == b'\n' { break; }
        }
        if n == 0 { break; }
        match copy_to_user(buf + total, &tmp[..n]) {
            Err(()) => { if total == 0 { return -14; } break; }
            Ok(_)   => {}
        }
        total += n;
        if tmp[n - 1] == b'\n' { break; }
    }
    total as isize
}

// ── sys_write ────────────────────────────────────────────────────────────

fn sys_write(fd: usize, buf: usize, count: usize) -> isize {
    if fd != 1 && fd != 2 { return -9; } // EBADF
    if count == 0 { return 0; }
    let max = count.min(MAX_RW);
    if !validate_user_ptr(buf, max) { return -14; }

    const STAGE: usize = 256;
    let mut tmp = [0u8; STAGE];
    let mut done = 0usize;

    while done < max {
        let batch = (max - done).min(STAGE);
        match copy_from_user(&mut tmp[..batch], buf + done) {
            Err(()) => { if done == 0 { return -14; } break; }
            Ok(_)   => {}
        }
        for &b in &tmp[..batch] { put_char(b); }
        done += batch;
    }
    done as isize
}

// ── sys_openat / sys_close ────────────────────────────────────────────────

fn sys_openat(dirfd: usize, path: *const u8, flags: u32) -> isize {
    let _ = (dirfd, flags);
    let mut buf = [0u8; 256];
    match unsafe { strncpy_from_user(&mut buf, path, 256) } {
        Err(_)  => return -14,
        Ok(len) => {
            let s = core::str::from_utf8(&buf[..len]).unwrap_or("");
            match crate::fs::vfs::lookup(s) {
                Some(_) => 3,   // fd=3 (first non-stdio)
                None    => -2,  // ENOENT
            }
        }
    }
}

fn sys_close(fd: usize) -> isize {
    if fd < 3 { return -9; } // can't close stdio
    0
}

// ── sys_execve (stub) ─────────────────────────────────────────────────────

fn sys_execve_stub() -> isize { -38 } // ENOSYS — full impl needs more plumbing

// ── sys_mmap / sys_munmap / sys_brk ──────────────────────────────────────

// ── sys_fork (stub) ───────────────────────────────────────────────────────

fn sys_fork_stub() -> isize { -38 } // ENOSYS

// ── sys_uname ────────────────────────────────────────────────────────────

fn sys_uname(buf: *mut u8) -> isize {
    const INFO: &[u8] = b"rustos\0Linux\0x86_64\0";
    if !validate_user_ptr(buf as usize, INFO.len()) { return -14; }
    if copy_to_user(buf as usize, INFO).is_err() { return -14; }
    0
}

// ── User VA bump allocator (very simple) ──────────────────────────────────

use core::sync::atomic::{AtomicUsize, Ordering};
// Start user anonymous mappings at 256 MiB
static NEXT_ANON_VA: AtomicUsize = AtomicUsize::new(0x1000_0000);

fn alloc_user_va(pages: usize) -> usize {
    NEXT_ANON_VA.fetch_add(pages * PAGE_SIZE, Ordering::SeqCst)
}

// ── I/O helpers (arch-specific) ───────────────────────────────────────────

#[cfg(target_arch = "x86_64")]
fn get_char() -> u8 { crate::arch::x86_64::serial::read_byte() }

#[cfg(target_arch = "x86_64")]
fn put_char(b: u8)  { crate::arch::x86_64::serial::write_byte(b); }

#[cfg(target_arch = "x86_64")]
fn put_str(s: &str) { crate::arch::x86_64::serial::write_str(s); }

#[cfg(target_arch = "riscv64")]
fn get_char() -> u8 { crate::drivers::uart::getc() }

#[cfg(target_arch = "riscv64")]
fn put_char(b: u8)  { crate::drivers::uart::putc(b); }

#[cfg(target_arch = "riscv64")]
fn put_str(s: &str) {
    for b in s.bytes() { crate::drivers::uart::putc(b); }
}

// ── sys_sigreturn ─────────────────────────────────────────────────────────

fn sys_sigreturn() -> isize {
    // The user's signal frame holds the saved mcontext.  We restore it by
    // reading it back and rewriting the syscall frame.  For now we rely on
    // the trampoline having been executed (rsp points past the frame).
    // Full ucontext restore is wired in syscall_rust_handler (see below).
    0
}

// ── Post-syscall signal delivery hook (x86_64) ────────────────────────────

/// Called by `syscall_rust_handler` after every syscall.
/// If a signal is pending, builds a signal frame on the user stack and
/// redirects the SYSRET destination to the handler.
#[cfg(target_arch = "x86_64")]
pub fn check_signals_x86(frame: &mut crate::arch::x86_64::syscall::SyscallFrame) {
    if let Some((new_rip, new_rsp)) = crate::proc::signal::deliver_pending(
        frame.rcx,
        frame.user_rsp,
        frame.r11,
        frame,
    ) {
        frame.rcx      = new_rip;
        frame.user_rsp = new_rsp;
        // rdi = signal number (already set inside deliver_pending via frame.rax
        // but the handler expects it in rdi per SysV ABI)
    }
}

// ── VFS-backed syscalls ───────────────────────────────────────────────────

fn sys_read_fd(fd: usize, buf_va: usize, count: usize) -> isize {
    if fd == 0 {
        // Stdin: go through TTY line discipline
        if count == 0 { return 0; }
        if !validate_user_ptr(buf_va, count) { return -14; }
        let mut tmp = alloc::vec![0u8; count.min(512)];
        let n = crate::drivers::tty::read(&mut tmp);
        if n == 0 { return 0; }
        return match copy_to_user(buf_va, &tmp[..n]) { Ok(_) => n as isize, Err(()) => -14 };
    }
    if fd < 3 { return sys_read(fd, buf_va, count); }   // stdout/stderr fallback
    if count == 0 { return 0; }
    if !validate_user_ptr(buf_va, count) { return -14; }
    let mut tmp = alloc::vec![0u8; count.min(crate::mm::pmm::PAGE_SIZE * 64)];
    let n = crate::fs::vfs::read(fd, &mut tmp);
    if n < 0 { return n; }
    match copy_to_user(buf_va, &tmp[..n as usize]) {
        Ok(_)  => n,
        Err(()) => -14,
    }
}

fn sys_write_fd(fd: usize, buf_va: usize, count: usize) -> isize {
    if fd < 3 { return sys_write(fd, buf_va, count); }  // stdout/stderr fallback
    if count == 0 { return 0; }
    if !validate_user_ptr(buf_va, count) { return -14; }
    let mut tmp = alloc::vec![0u8; count.min(crate::mm::pmm::PAGE_SIZE * 64)];
    match copy_from_user(&mut tmp[..count], buf_va) {
        Ok(_)  => {}
        Err(()) => return -14,
    }
    crate::fs::vfs::write(fd, &tmp[..count])
}

fn sys_openat_vfs(dirfd: usize, path_va: *const u8, flags: u32) -> isize {
    let _ = dirfd;
    let mut buf = [0u8; 256];
    let len = match unsafe { strncpy_from_user(&mut buf, path_va, 256) } {
        Ok(n)  => n,
        Err(_) => return -14,
    };
    let path = match core::str::from_utf8(&buf[..len]) { Ok(s) => s, Err(_) => return -2 };
    match crate::fs::vfs::open(path, flags) {
        Ok(fd)  => fd as isize,
        Err(e)  => e as isize,
    }
}

fn sys_fstat(fd: usize, stat_va: usize) -> isize {
    let size = match crate::fs::vfs::fstat(fd) { Some(s) => s, None => return -9 };
    // Write a minimal Linux stat64 — only st_size (offset 48, 8 bytes) matters.
    let mut stat = [0u8; 144];
    stat[48..56].copy_from_slice(&(size as u64).to_le_bytes());
    match copy_to_user(stat_va, &stat) { Ok(_) => 0, Err(()) => -14 }
}

fn sys_lseek(fd: usize, offset: i64, whence: i32) -> isize {
    crate::fs::vfs::seek(fd, offset, whence)
}

fn sys_getcwd(buf_va: usize, size: usize) -> isize {
    let cwd = b"/\0";
    if size < cwd.len() { return -34; } // ERANGE
    match copy_to_user(buf_va, cwd) { Ok(_) => buf_va as isize, Err(()) => -14 }
}

fn sys_getdents(fd: usize, buf_va: usize, count: usize) -> isize {
    // Minimal getdents64 — returns one entry per call then 0.
    // Proper implementation needs per-fd directory position tracking.
    0
}

// ── Socket syscall implementations ───────────────────────────────────────

// Descriptor type tag stored in fd entry (reuse VFS with a socket marker)
fn sys_socket(_domain: usize, _stype: usize, _proto: usize) -> isize {
    // Allocate a new fd backed by a TCP or UDP socket.
    // For simplicity we always create a TCP socket (stream) here.
    let fd = crate::fs::vfs::open_socket();
    match fd { Ok(n) => n as isize, Err(e) => e as isize }
}

fn sys_bind(fd: usize, addr_va: usize) -> isize {
    let port = sockaddr_port(addr_va);
    crate::fs::vfs::socket_bind(fd, port)
}

fn sys_connect(fd: usize, addr_va: usize, _len: u16) -> isize {
    let (ip, port) = sockaddr_ip_port(addr_va);
    crate::fs::vfs::socket_connect(fd, ip, port)
}

fn sys_accept(fd: usize) -> isize {
    crate::fs::vfs::socket_accept(fd)
}

fn sys_sendto(fd: usize, buf_va: usize, len: usize, _flags: usize) -> isize {
    if !validate_user_ptr(buf_va, len) { return -14; }
    let mut tmp = alloc::vec![0u8; len.min(65536)];
    match copy_from_user(&mut tmp[..len], buf_va) { Ok(_) => {}, Err(()) => return -14 }
    crate::fs::vfs::socket_send(fd, &tmp[..len])
}

fn sys_recvfrom(fd: usize, buf_va: usize, len: usize, _flags: usize) -> isize {
    let data = match crate::fs::vfs::socket_recv(fd, len) { Some(d) => d, None => return -11 };
    if !validate_user_ptr(buf_va, data.len()) { return -14; }
    match copy_to_user(buf_va, &data) { Ok(_) => data.len() as isize, Err(()) => -14 }
}

fn sys_pipe(pipefd_va: usize) -> isize {
    let (rfd, wfd) = match crate::fs::vfs::create_pipe() { Some(p) => p, None => return -23 };
    let buf = [(rfd as u32).to_le_bytes(), (wfd as u32).to_le_bytes()].concat();
    match copy_to_user(pipefd_va, &buf) { Ok(_) => 0, Err(()) => -14 }
}

// ── sockaddr_in helpers ───────────────────────────────────────────────────

fn sockaddr_port(va: usize) -> u16 {
    // struct sockaddr_in: u16 family, u16 port (big-endian), u32 addr
    if !validate_user_ptr(va, 8) { return 0; }
    let mut buf = [0u8; 8];
    let _ = copy_from_user(&mut buf, va);
    u16::from_be_bytes([buf[2], buf[3]])
}

fn sockaddr_ip_port(va: usize) -> ([u8;4], u16) {
    if !validate_user_ptr(va, 8) { return ([0;4], 0); }
    let mut buf = [0u8; 8];
    let _ = copy_from_user(&mut buf, va);
    let port = u16::from_be_bytes([buf[2], buf[3]]);
    let ip   = [buf[4], buf[5], buf[6], buf[7]];
    (ip, port)
}

// ── dup2 ─────────────────────────────────────────────────────────────────

fn sys_dup2(old: usize, new: usize) -> isize {
    crate::fs::vfs::dup2(old, new)
}

// ── ioctl ────────────────────────────────────────────────────────────────

fn sys_ioctl(fd: usize, request: usize, arg: usize) -> isize {
    if fd < 3 {
        return crate::drivers::tty::ioctl(request, arg);
    }
    if crate::fs::devfs::get_dev_fd(fd).is_some() {
        return crate::fs::devfs::ioctl(fd, request, arg);
    }
    -25 // ENOTTY
}

// ── clock_gettime / gettimeofday ─────────────────────────────────────────

fn sys_clock_gettime(_clk: usize, ts_va: usize) -> isize {
    // Return uptime as coarse CLOCK_MONOTONIC
    let ticks = crate::arch::x86_64::apic::ticks();
    let secs  = ticks / 100;
    let nsecs = (ticks % 100) * 10_000_000;
    if ts_va != 0 {
        unsafe {
            *(ts_va as *mut u64)       = secs;
            *((ts_va+8) as *mut u64)   = nsecs;
        }
    }
    0
}

fn sys_gettimeofday(tv_va: usize) -> isize {
    let ticks = crate::arch::x86_64::apic::ticks();
    if tv_va != 0 {
        unsafe {
            *(tv_va as *mut u64)   = ticks / 100;          // tv_sec
            *((tv_va+8) as *mut u64) = (ticks%100)*10_000; // tv_usec
        }
    }
    0
}

fn sys_getrandom(buf_va: usize, len: usize, _flags: usize) -> isize {
    if buf_va == 0 || len == 0 { return 0; }
    let mut i = 0;
    while i < len {
        let rnd = crate::fs::devfs::seed_prng_word();
        let take = 8.min(len - i);
        unsafe {
            core::ptr::copy_nonoverlapping(
                rnd.to_le_bytes().as_ptr(),
                (buf_va + i) as *mut u8, take);
        }
        i += take;
    }
    len as isize
}

fn sys_arch_prctl(code: usize, addr: usize) -> isize {
    // ARCH_SET_FS = 0x1002
    if code == 0x1002 {
        unsafe { core::arch::asm!("wrfsbase {}", in(reg) addr); }
        return 0;
    }
    // ARCH_GET_FS = 0x1003
    if code == 0x1003 {
        let val: usize;
        unsafe { core::arch::asm!("rdfsbase {}", out(reg) val); }
        if addr != 0 { unsafe { *(addr as *mut usize) = val; } }
        return 0;
    }
    -1
}

// ── sys_clone ─────────────────────────────────────────────────────────────

fn sys_clone_dispatch(flags: u64, child_stack: usize, ptid: usize,
                      ctid: usize, tls: usize,
                      frame: &crate::arch::x86_64::interrupts::InterruptFrame) -> isize
{
    // Extract RIP from the interrupt frame (return address after syscall)
    let rip = frame.rip;
    let ctx = crate::proc::context::Context::from_frame(frame);
    crate::proc::clone::sys_clone(flags, child_stack, ptid, ctid, tls, &ctx, rip)
}

// ── nanosleep ─────────────────────────────────────────────────────────────

fn sys_nanosleep(req_va: usize, _rem: usize) -> isize {
    if req_va == 0 { return -14; }
    let secs:  u64 = unsafe { *(req_va as *const u64) };
    let nsecs: u64 = unsafe { *((req_va+8) as *const u64) };
    let ticks = secs * 100 + nsecs / 10_000_000;
    let deadline = crate::arch::x86_64::apic::ticks() + ticks;
    while crate::arch::x86_64::apic::ticks() < deadline {
        crate::proc::scheduler::current_yield();
        crate::net::poll();
    }
    0
}

// ── path string helpers ───────────────────────────────────────────────────

fn read_path(ptr: *const u8) -> Option<alloc::string::String> {
    if ptr.is_null() { return None; }
    let mut s = alloc::string::String::new();
    let mut i = 0usize;
    loop {
        let b = unsafe { *ptr.add(i) };
        if b == 0 || i > 4095 { break; }
        s.push(b as char);
        i += 1;
    }
    Some(s)
}

fn sys_path_str<F: Fn(&str) -> isize>(ptr: *const u8, f: F) -> isize {
    match read_path(ptr) { Some(p) => f(&p), None => -14 }
}

fn sys_path_op1<F: Fn(&str, u32) -> isize>(ptr: *const u8, arg: u32, f: F) -> isize {
    match read_path(ptr) { Some(p) => f(&p, arg), None => -14 }
}

fn sys_path_op2<F: Fn(&str, i64) -> isize>(ptr: *const u8, arg: i64, f: F) -> isize {
    match read_path(ptr) { Some(p) => f(&p, arg), None => -14 }
}

fn sys_stat_path(ptr: *const u8, stat_va: usize) -> isize {
    match read_path(ptr) { Some(p) => crate::fs::vfs::stat(&p, stat_va), None => -14 }
}

fn sys_access(ptr: *const u8, mode: u32) -> isize {
    match read_path(ptr) { Some(p) => crate::fs::vfs::access(&p, mode), None => -14 }
}

fn sys_readlink(ptr: *const u8, buf_va: usize, size: usize) -> isize {
    let path = match read_path(ptr) { Some(p) => p, None => return -14 };
    if buf_va == 0 || size == 0 { return -14; }
    let buf = unsafe { core::slice::from_raw_parts_mut(buf_va as *mut u8, size) };
    crate::fs::vfs_ops::readlink(&path, buf)
}

fn sys_rename(old: *const u8, new: *const u8) -> isize {
    let o = match read_path(old) { Some(p) => p, None => return -14 };
    let n = match read_path(new) { Some(p) => p, None => return -14 };
    crate::fs::vfs_ops::rename(&o, &n)
}

fn sys_mkdir(ptr: *const u8, mode: u32) -> isize {
    match read_path(ptr) { Some(p) => crate::fs::vfs_ops::mkdir(&p, mode), None => -14 }
}

fn sys_link(old: *const u8, new: *const u8) -> isize {
    let o = match read_path(old) { Some(p) => p, None => return -14 };
    let n = match read_path(new) { Some(p) => p, None => return -14 };
    crate::fs::vfs_ops::link(&o, &n)
}

fn sys_symlink(target: *const u8, linkpath: *const u8) -> isize {
    let t = match read_path(target)   { Some(p) => p, None => return -14 };
    let l = match read_path(linkpath) { Some(p) => p, None => return -14 };
    crate::fs::vfs_ops::symlink(&t, &l)
}

// ── resource limits ───────────────────────────────────────────────────────

fn sys_getrlimit(resource: usize, rlim_va: usize) -> isize {
    if rlim_va == 0 { return -14; }
    // Return generous limits: RLIM_INFINITY for most
    let (soft, hard): (u64, u64) = match resource {
        0  => (8192,        8192),         // RLIMIT_CPU (seconds)
        1  => (256*1024*1024, u64::MAX),   // RLIMIT_FSIZE
        2  => (u64::MAX, u64::MAX),        // RLIMIT_DATA
        3  => (8*1024*1024, 8*1024*1024),  // RLIMIT_STACK (8 MiB)
        4  => (u64::MAX, u64::MAX),        // RLIMIT_CORE
        7  => (u64::MAX, u64::MAX),        // RLIMIT_NOFILE ... handled below
        7  => (1024, 1024),                // RLIMIT_NOFILE
        _  => (u64::MAX, u64::MAX),
    };
    unsafe { *(rlim_va as *mut u64) = soft; *((rlim_va+8) as *mut u64) = hard; }
    0
}

fn sys_getrusage(buf_va: usize) -> isize {
    if buf_va == 0 { return -14; }
    // Zero-fill the rusage struct (144 bytes)
    unsafe { core::ptr::write_bytes(buf_va as *mut u8, 0, 144); }
    0
}

// ── ext2-aware stat helpers ───────────────────────────────────────────────

fn sys_stat_unified(ptr: *const u8, stat_va: usize) -> isize {
    match read_path(ptr) { Some(p) => crate::fs::vfs::stat_unified(&p, stat_va), None => -14 }
}

fn sys_rename_ext2(old: *const u8, new: *const u8) -> isize {
    let o = match read_path(old) { Some(p) => p, None => return -14 };
    let n = match read_path(new) { Some(p) => p, None => return -14 };
    crate::fs::vfs_ops::ext2_rename(&o, &n)
}

fn sys_mkdir_ext2(ptr: *const u8, mode: u32) -> isize {
    match read_path(ptr) { Some(p) => crate::fs::vfs_ops::ext2_mkdir(&p, mode), None => -14 }
}

fn sys_symlink_ext2(target: *const u8, linkpath: *const u8) -> isize {
    let t = match read_path(target)   { Some(p) => p, None => return -14 };
    let l = match read_path(linkpath) { Some(p) => p, None => return -14 };
    crate::fs::vfs_ops::ext2_symlink(&t, &l)
}

// ── sync(2) ───────────────────────────────────────────────────────────────

pub const SYS_SYNC:  usize = 162;
pub const SYS_FSYNC: usize = 74;

// ── openat (dirfd, path, flags, mode) ─────────────────────────────────────

const AT_FDCWD: i32 = -100;

fn sys_openat(dirfd: i32, path_ptr: *const u8, flags: usize, _mode: u32) -> isize {
    // Resolve path relative to dirfd (only AT_FDCWD supported for now)
    let path = match read_path(path_ptr) { Some(p) => p, None => return -14 };
    let resolved = if dirfd == AT_FDCWD || path.starts_with('/') {
        path
    } else {
        // Look up dirfd's path and join
        let base = crate::fs::vfs::fd_to_path(dirfd as usize).unwrap_or_default();
        alloc::format!("{}/{}", base, path)
    };
    // Delegate to open()
    sys_open_str(&resolved, flags)
}

fn sys_open_str(path: &str, flags: usize) -> isize {
    use crate::fs::vfs::*;
    // Try ext2 first
    let r = crate::fs::vfs::open_unified(path, flags);
    if r != -2 { return r; }
    // Try normal vfs open
    sys_open(path.as_ptr(), flags, 0)
}

fn sys_open(path_ptr: *const u8, flags: usize, _mode: usize) -> isize {
    let path = match read_path(path_ptr) { Some(p) => p, None => return -14 };
    sys_open_str(&path, flags)
}

// ── lseek ─────────────────────────────────────────────────────────────────

fn sys_lseek(fd: usize, offset: i64, whence: u32) -> isize {
    crate::fs::vfs::lseek(fd, offset, whence)
}

// ── pread64 ───────────────────────────────────────────────────────────────

fn sys_pread64(fd: usize, buf_va: usize, count: usize, offset: i64) -> isize {
    // Seek to offset, read, seek back
    let orig = crate::fs::vfs::get_pos(fd);
    crate::fs::vfs::lseek(fd, offset, 0 /* SEEK_SET */);
    let n = crate::fs::vfs::read_fd(fd, buf_va, count);
    crate::fs::vfs::lseek(fd, orig as i64, 0);
    n
}

// ── readv ──────────────────────────────────────────────────────────────────

#[repr(C)]
struct IoVec { base: usize, len: usize }

fn sys_readv(fd: usize, iov_va: usize, iovcnt: usize) -> isize {
    let mut total = 0isize;
    for i in 0..iovcnt {
        let iov: IoVec = unsafe { core::ptr::read((iov_va + i * 16) as *const IoVec) };
        if iov.len == 0 { continue; }
        let n = crate::fs::vfs::read_fd(fd, iov.base, iov.len);
        if n < 0 { return n; }
        total += n;
    }
    total
}

fn sys_mmap_dispatch(addr: usize, len: usize, prot: usize, flags: usize, fd: usize, off: usize) -> isize {
    crate::mm::mmap::sys_mmap(addr, len, prot, flags, fd, off)
}
