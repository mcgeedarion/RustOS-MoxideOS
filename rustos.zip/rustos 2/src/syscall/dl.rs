//! Syscall helpers specific to the dynamic linker path.
//!
//! The dynamic linker (`ld-musl-x86_64.so.1`) needs:
//!   open / read / close   — to open shared libraries by path
//!   mmap(MAP_FIXED)       — to map .so segments at precise VAs
//!   mprotect              — to change segment permissions after relocation
//!   munmap                — to unmap the file mapping after copying data
//!
//! All of these are handled by the generic VFS / mmap syscalls.  This module
//! adds the kernel-side `dlopen` / `dlsym` used when a statically-linked
//! program calls `dlopen(NULL, …)` (introspection), and the `LD_PRELOAD`
//! environment variable parser.

extern crate alloc;
use alloc::{string::String, vec::Vec};

// ── Loaded shared object table ────────────────────────────────────────────

struct SoEntry {
    name:  String,
    base:  usize,
    size:  usize,
    // symbol table: (name, offset from base)
    syms:  Vec<(String, usize)>,
}

use spin::Mutex;
static SO_TABLE: Mutex<Vec<SoEntry>> = Mutex::new(Vec::new());

// ── Register a loaded .so (called from execve / mmap path) ───────────────

pub fn register_so(name: &str, base: usize, size: usize) {
    SO_TABLE.lock().push(SoEntry {
        name: String::from(name), base, size, syms: Vec::new(),
    });
}

// ── dlopen ────────────────────────────────────────────────────────────────

/// Kernel-side dlopen: returns a handle (base address) or 0 on failure.
/// Used by statically-linked programs calling dlopen(NULL, …).
pub fn sys_dlopen(path_va: usize, _flags: usize) -> isize {
    if path_va == 0 {
        // dlopen(NULL) → handle for the main executable
        return 1;
    }
    let mut pbuf = [0u8; 512];
    let len = match unsafe { crate::uaccess::strncpy_from_user(&mut pbuf, path_va as *const u8, 512) } {
        Ok(n) => n, Err(_) => return 0,
    };
    let path = core::str::from_utf8(&pbuf[..len]).unwrap_or("");

    // Check if already loaded
    {
        let tbl = SO_TABLE.lock();
        if let Some(e) = tbl.iter().find(|e| e.name.ends_with(path) || path.ends_with(&*e.name)) {
            return e.base as isize;
        }
    }

    // Load from VFS
    let elf_data = match crate::fs::vfs::lookup(path)
        .or_else(|| crate::fs::ext2::read_file(path)) {
        Some(d) => d, None => { crate::serial_println!("[dlopen] not found: {}", path); return 0; }
    };

    // Get current CR3 (load into current address space)
    let cr3: usize;
    unsafe { core::arch::asm!("mov {}, cr3", out(reg) cr3); }
    let cr3 = cr3 & !0xFFF;

    match crate::loader::elf64::load(&elf_data, cr3) {
        Ok(r) => {
            register_so(path, r.load_base, r.load_end - r.load_base);
            r.load_base as isize
        }
        Err(e) => { crate::serial_println!("[dlopen] load failed: {}", e); 0 }
    }
}

// ── dlsym ─────────────────────────────────────────────────────────────────

/// Kernel-side dlsym stub: searches the SO table for a symbol by name.
/// Returns VA or 0.  The real symbol resolution is done by ld-musl in user
/// space; this only handles programs that bypass the dynamic linker entirely.
pub fn sys_dlsym(handle: usize, sym_va: usize) -> isize {
    let mut sbuf = [0u8; 256];
    let len = match unsafe { crate::uaccess::strncpy_from_user(&mut sbuf, sym_va as *const u8, 256) } {
        Ok(n) => n, Err(_) => return 0,
    };
    let sym = core::str::from_utf8(&sbuf[..len]).unwrap_or("");
    let tbl = SO_TABLE.lock();
    for entry in tbl.iter() {
        if handle == 0 || handle == entry.base || handle == 1 {
            if let Some((_, off)) = entry.syms.iter().find(|(n, _)| n == sym) {
                return (entry.base + off) as isize;
            }
        }
    }
    0
}

// ── LD_PRELOAD / library path helpers ────────────────────────────────────

/// Resolve a bare .so name to a full VFS path, searching standard directories.
pub fn resolve_so_path(name: &str) -> Option<String> {
    const SEARCH: &[&str] = &[
        "/lib",
        "/usr/lib",
        "/lib/x86_64-linux-musl",
        "/usr/lib/x86_64-linux-musl",
    ];
    for dir in SEARCH {
        let full = alloc::format!("{}/{}", dir, name);
        if crate::fs::vfs::access(&full, 0) == 0 { return Some(full); }
        if crate::fs::ext2::is_mounted() {
            if crate::fs::ext2::stat(&full).is_some() { return Some(full); }
        }
    }
    None
}
