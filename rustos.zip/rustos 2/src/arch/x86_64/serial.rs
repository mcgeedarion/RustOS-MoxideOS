//! COM1 16550A UART driver.
//! Provides serial_print!/serial_println! macros for early boot output,
//! plus read_byte/write_byte for the syscall read/write implementation.

use spin::Once;

const COM1: u16 = 0x3F8;

fn outb(port: u16, val: u8) {
    unsafe { core::arch::asm!("out dx, al", in("dx") port, in("al") val,
                              options(nostack, nomem)); }
}
fn inb(port: u16) -> u8 {
    let v: u8;
    unsafe { core::arch::asm!("in al, dx", in("dx") port, out("al") v,
                              options(nostack, nomem)); }
    v
}

static INIT: Once<()> = Once::new();

pub fn init() {
    INIT.call_once(|| {
        outb(COM1 + 1, 0x00); // disable interrupts
        outb(COM1 + 3, 0x80); // enable DLAB
        outb(COM1 + 0, 0x03); // baud 38400
        outb(COM1 + 1, 0x00);
        outb(COM1 + 3, 0x03); // 8N1
        outb(COM1 + 2, 0xC7); // FIFO 14-byte
        outb(COM1 + 4, 0x0B); // RTS/DSR
    });
}

fn is_tx_ready() -> bool { inb(COM1 + 5) & 0x20 != 0 }
fn is_rx_ready() -> bool { inb(COM1 + 5) & 0x01 != 0 }

pub fn write_byte(b: u8) {
    while !is_tx_ready() {}
    outb(COM1, b);
}

pub fn write_str(s: &str) {
    for b in s.bytes() {
        if b == b'\n' { write_byte(b'\r'); }
        write_byte(b);
    }
}

/// Blocking read — spins until a byte is available.
pub fn read_byte() -> u8 {
    while !is_rx_ready() {
        core::hint::spin_loop();
    }
    inb(COM1)
}

// fmt::Write adapter for serial_print!
pub struct SerialWriter;

impl core::fmt::Write for SerialWriter {
    fn write_str(&mut self, s: &str) -> core::fmt::Result {
        write_str(s);
        Ok(())
    }
}

#[macro_export]
macro_rules! serial_print {
    ($($arg:tt)*) => {{
        use core::fmt::Write;
        let _ = write!(
            $crate::arch::x86_64::serial::SerialWriter,
            $($arg)*
        );
    }};
}

#[macro_export]
macro_rules! serial_println {
    ()           => { $crate::serial_print!("\n") };
    ($($arg:tt)*) => { $crate::serial_print!("{}\n", format_args!($($arg)*)) };
}
