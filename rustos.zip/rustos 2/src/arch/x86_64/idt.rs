//! 64-bit Interrupt Descriptor Table.
//!
//! All 22 CPU exception stubs + APIC timer (vector 0x30) + spurious (0xFF).
//! Timer handler calls scheduler::tick() for preemptive round-robin.

use crate::arch::x86_64::gdt::SEL_KERNEL_CODE;
use crate::arch::x86_64::serial;
use core::arch::global_asm;

#[derive(Clone, Copy)]
#[repr(C)]
pub struct IdtGate {
    offset_lo:  u16,
    selector:   u16,
    ist:        u8,
    attr:       u8,
    offset_mid: u16,
    offset_hi:  u32,
    _zero:      u32,
}

impl IdtGate {
    const fn absent() -> Self {
        Self { offset_lo: 0, selector: 0, ist: 0, attr: 0,
               offset_mid: 0, offset_hi: 0, _zero: 0 }
    }
    pub fn new(handler: usize, dpl: u8, ist: u8) -> Self {
        let attr = 0b1000_1110 | (dpl << 5);
        Self {
            offset_lo:  (handler & 0xFFFF) as u16,
            selector:   SEL_KERNEL_CODE,
            ist,
            attr,
            offset_mid: ((handler >> 16) & 0xFFFF) as u16,
            offset_hi:  (handler >> 32) as u32,
            _zero:      0,
        }
    }
}

/// Full register frame pushed by isr_common + CPU.
#[repr(C)]
pub struct InterruptFrame {
    pub r15: u64, pub r14: u64, pub r13: u64, pub r12: u64,
    pub r11: u64, pub r10: u64, pub r9:  u64, pub r8:  u64,
    pub rbp: u64, pub rdi: u64, pub rsi: u64, pub rdx: u64,
    pub rcx: u64, pub rbx: u64, pub rax: u64,
    pub vector:     u64,
    pub error_code: u64,
    // CPU-pushed:
    pub rip:    u64,
    pub cs:     u64,
    pub rflags: u64,
    pub rsp:    u64,
    pub ss:     u64,
}

const IDT_SIZE: usize = 256;
static mut IDT: [IdtGate; IDT_SIZE] = [IdtGate::absent(); IDT_SIZE];

#[repr(C, packed)]
struct IdtPtr { limit: u16, base: u64 }

static EXCEPTION_NAMES: [&str; 22] = [
    "Divide-by-zero", "Debug", "NMI", "Breakpoint", "Overflow",
    "Bound Range", "Invalid Opcode", "Device Not Available", "Double Fault",
    "Coprocessor Segment Overrun", "Invalid TSS", "Segment Not Present",
    "Stack-Segment Fault", "General Protection Fault", "Page Fault",
    "Reserved", "x87 FP", "Alignment Check", "Machine Check",
    "SIMD FP", "Virtualization", "Control Protection",
];

/// Common Rust handler — exceptions + timer.
#[no_mangle]
pub extern "C" fn exception_handler(frame: &mut InterruptFrame) {
    let vec = frame.vector as usize;

    match vec {
        // ── APIC timer ────────────────────────────────────────────────────
        0x30 => {
            crate::proc::scheduler::tick(frame);
            // EOI already sent by tick(); just return.
            return;
        }

        // ── Spurious ──────────────────────────────────────────────────────
        0xFF => { return; }

        // ── Faults ────────────────────────────────────────────────────────
        _ => {
            let name = if vec < EXCEPTION_NAMES.len() {
                EXCEPTION_NAMES[vec]
            } else {
                "Unknown"
            };
            serial::write_str("\n[EXCEPTION] ");
            serial::write_str(name);
            serial::write_str("\n");

            use core::fmt::Write;
            let mut w = serial::SerialWriter;
            let _ = writeln!(w,
                "  vec={:#04x}  err={:#018x}  rip={:#018x}\n  rflags={:#018x}  rsp={:#018x}",
                frame.vector, frame.error_code, frame.rip,
                frame.rflags, frame.rsp,
            );

            if vec == 14 {
                let cr2: u64;
                unsafe { core::arch::asm!("mov {0}, cr2", out(reg) cr2); }
                let _ = writeln!(w, "  cr2(fault addr) = {:#018x}", cr2);
            }

            // Kill user process on any fault; panic on ring-0 fault.
            if frame.cs & 3 == 0 {
                // Fault in ring 0 — unrecoverable.
                loop { unsafe { core::arch::asm!("cli; hlt"); } }
            }
            crate::proc::scheduler::exit(-11);
        }
    }
}

// ── ISR stubs ─────────────────────────────────────────────────────────────

// Common save/restore + call
global_asm!(r#"
.global isr_common
isr_common:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    mov  rdi, rsp
    call exception_handler
    pop  r15
    pop  r14
    pop  r13
    pop  r12
    pop  r11
    pop  r10
    pop  r9
    pop  r8
    pop  rbp
    pop  rdi
    pop  rsi
    pop  rdx
    pop  rcx
    pop  rbx
    pop  rax
    add  rsp, 16
    iretq
"#);

macro_rules! isr_no_err {
    ($n:literal, $sym:ident) => {
        global_asm!(concat!(
            ".global ", stringify!($sym), "\n",
            stringify!($sym), ":\n",
            "  push 0\n",
            "  push ", $n, "\n",
            "  jmp isr_common\n",
        ));
        extern "C" { pub fn $sym(); }
    };
}
macro_rules! isr_with_err {
    ($n:literal, $sym:ident) => {
        global_asm!(concat!(
            ".global ", stringify!($sym), "\n",
            stringify!($sym), ":\n",
            "  push ", $n, "\n",
            "  jmp isr_common\n",
        ));
        extern "C" { pub fn $sym(); }
    };
}
macro_rules! isr_irq {
    ($n:literal, $sym:ident) => {
        global_asm!(concat!(
            ".global ", stringify!($sym), "\n",
            stringify!($sym), ":\n",
            "  push 0\n",            // no error code
            "  push ", $n, "\n",     // vector number
            "  jmp isr_common\n",
        ));
        extern "C" { pub fn $sym(); }
    };
}

isr_no_err!  (0,    isr0_de);
isr_no_err!  (1,    isr1_db);
isr_no_err!  (2,    isr2_nmi);
isr_no_err!  (3,    isr3_bp);
isr_no_err!  (4,    isr4_of);
isr_no_err!  (5,    isr5_br);
isr_no_err!  (6,    isr6_ud);
isr_no_err!  (7,    isr7_nm);
isr_with_err!(8,    isr8_df);
isr_no_err!  (9,    isr9_cso);
isr_with_err!(10,   isr10_ts);
isr_with_err!(11,   isr11_np);
isr_with_err!(12,   isr12_ss);
isr_with_err!(13,   isr13_gp);
isr_with_err!(14,   isr14_pf);
isr_no_err!  (15,   isr15_rsv);
isr_no_err!  (16,   isr16_mf);
isr_with_err!(17,   isr17_ac);
isr_no_err!  (18,   isr18_mc);
isr_no_err!  (19,   isr19_xm);
isr_no_err!  (20,   isr20_ve);
isr_with_err!(21,   isr21_cp);
isr_irq!     (0x30, isr_timer);   // APIC timer
isr_irq!     (0xFF, isr_spurious);

/// Populate and load the IDT.
pub fn init() {
    macro_rules! set {
        ($n:expr, $sym:ident) =>
            { unsafe { IDT[$n] = IdtGate::new($sym as usize, 0, 0); } };
        ($n:expr, $sym:ident, ist=$ist:literal) =>
            { unsafe { IDT[$n] = IdtGate::new($sym as usize, 0, $ist); } };
    }

    set!(0,    isr0_de);
    set!(1,    isr1_db);
    set!(2,    isr2_nmi,    ist=1);
    set!(3,    isr3_bp);
    set!(4,    isr4_of);
    set!(5,    isr5_br);
    set!(6,    isr6_ud);
    set!(7,    isr7_nm);
    set!(8,    isr8_df,     ist=2);
    set!(9,    isr9_cso);
    set!(10,   isr10_ts);
    set!(11,   isr11_np);
    set!(12,   isr12_ss);
    set!(13,   isr13_gp);
    set!(14,   isr14_pf);
    set!(15,   isr15_rsv);
    set!(16,   isr16_mf);
    set!(17,   isr17_ac);
    set!(18,   isr18_mc,    ist=3);
    set!(19,   isr19_xm);
    set!(20,   isr20_ve);
    set!(21,   isr21_cp);
    set!(0x30, isr_timer);
    set!(0xFF, isr_spurious);

    let ptr = IdtPtr {
        limit: (core::mem::size_of::<[IdtGate; IDT_SIZE]>() - 1) as u16,
        base:  unsafe { IDT.as_ptr() as u64 },
    };
    unsafe {
        core::arch::asm!("lidt [{0}]", in(reg) &ptr, options(nostack));
    }
}
