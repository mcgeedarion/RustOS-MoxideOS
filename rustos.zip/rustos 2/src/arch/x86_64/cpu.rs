//! CPU feature detection (CPUID) and miscellaneous helpers.
use core::arch::x86_64::{__cpuid, __cpuid_count};

/// Returns (vendor_string, max_leaf).
pub fn vendor() -> ([u8; 12], u32) {
    let r = unsafe { __cpuid(0) };
    let mut v = [0u8; 12];
    v[0..4].copy_from_slice(&r.ebx.to_le_bytes());
    v[4..8].copy_from_slice(&r.edx.to_le_bytes());
    v[8..12].copy_from_slice(&r.ecx.to_le_bytes());
    (v, r.eax)
}

/// True if the CPU is Intel ("GenuineIntel").
pub fn is_intel() -> bool {
    vendor().0 == *b"GenuineIntel"
}

/// True if the CPU is AMD ("AuthenticAMD").
pub fn is_amd() -> bool {
    vendor().0 == *b"AuthenticAMD"
}

/// True if SSE4.2 is available.
pub fn has_sse42() -> bool {
    let r = unsafe { __cpuid(1) };
    r.ecx & (1 << 20) != 0
}

/// True if AVX2 is available.
pub fn has_avx2() -> bool {
    let r = unsafe { __cpuid_count(7, 0) };
    r.ebx & (1 << 5) != 0
}

/// True if FSGSBASE instructions are available.
pub fn has_fsgsbase() -> bool {
    let r = unsafe { __cpuid_count(7, 0) };
    r.ebx & (1 << 0) != 0
}

/// Enable SSE + SSE2 (required before using xmm registers in the kernel).
pub fn enable_sse() {
    unsafe {
        core::arch::asm!(
            // clear EM, set MP in CR0
            "mov  rax, cr0",
            "and  rax, ~(1 << 2)",   // clear EM
            "or   rax, (1 << 1)",    // set  MP
            "mov  cr0, rax",
            // set OSFXSR (bit 9) + OSXMMEXCPT (bit 10) in CR4
            "mov  rax, cr4",
            "or   rax, (3 << 9)",
            "mov  cr4, rax",
            out("rax") _,
            options(nostack),
        );
    }
}

/// Enable FSGSBASE instructions (CR4.FSGSBASE = bit 16).
pub fn enable_fsgsbase() {
    unsafe {
        core::arch::asm!(
            "mov rax, cr4",
            "or  rax, (1 << 16)",
            "mov cr4, rax",
            out("rax") _,
            options(nostack),
        );
    }
}

/// `hlt` in a tight loop — permanent halt.
pub fn halt() -> ! {
    loop {
        unsafe { core::arch::asm!("cli; hlt", options(nostack, nomem)); }
    }
}

/// Read the TSC.
#[inline]
pub fn rdtsc() -> u64 {
    let lo: u32;
    let hi: u32;
    unsafe {
        core::arch::asm!("rdtsc", out("eax") lo, out("edx") hi, options(nostack));
    }
    ((hi as u64) << 32) | lo as u64
}
