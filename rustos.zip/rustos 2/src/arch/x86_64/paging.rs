//! x86_64 4-level paging — identity map, higher-half kernel, per-process maps.
//!
//! Two public helpers added for the scheduler / process loader:
//!   map_user_page(cr3, va, pa)    — map one 4 KiB user-accessible page.
//!   install_kernel_entries(cr3)   — copy kernel PML4 entries into a new CR3.

use spin::Once;
use crate::mm::pmm::{self, PAGE_SIZE};

// Page-table entry flags
const PRESENT:  u64 = 1 << 0;
const WRITE:    u64 = 1 << 1;
const USER:     u64 = 1 << 2;  // accessible from ring 3
const HUGE:     u64 = 1 << 7;  // 2 MiB page in PD

fn alloc_pt_page() -> usize {
    let pa = pmm::alloc_page().expect("OOM: page table");
    unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
    pa
}

// ── Boot / global page tables ─────────────────────────────────────────────

#[repr(C, align(4096))]
pub struct PageTable(pub [u64; 512]);

impl PageTable {
    pub const fn zero() -> Self { Self([0u64; 512]) }
    pub fn as_phys(&self) -> u64 { self as *const Self as u64 }
}

static mut PML4:    PageTable = PageTable::zero();
static mut PDPT_LO: PageTable = PageTable::zero();
static mut PD_LO:   PageTable = PageTable::zero();
static mut PDPT_HI: PageTable = PageTable::zero();
static mut PD_HI:   PageTable = PageTable::zero();

static PAGING_INIT: Once<()> = Once::new();

/// Build and activate the early 2 MiB huge-page map.
/// Must be called after ExitBootServices.
pub fn init() {
    PAGING_INIT.call_once(|| unsafe {
        // Identity map: VA 0..1 GiB → PA 0..1 GiB (512 × 2 MiB)
        for i in 0usize..512 {
            PD_LO.0[i] = (i as u64 * 0x20_0000) | HUGE | WRITE | PRESENT;
        }
        PDPT_LO.0[0] = PD_LO.as_phys() | WRITE | PRESENT;
        PML4.0[0]    = PDPT_LO.as_phys() | WRITE | PRESENT;

        // Higher-half: VA 0xFFFF_8000_0000_0000 → PA 0..1 GiB
        // PML4 index 256 = (0xFFFF_8000_0000_0000 >> 39) & 0x1FF
        for i in 0usize..512 {
            PD_HI.0[i] = (i as u64 * 0x20_0000) | HUGE | WRITE | PRESENT;
        }
        PDPT_HI.0[0] = PD_HI.as_phys() | WRITE | PRESENT;
        PML4.0[256]  = PDPT_HI.as_phys() | WRITE | PRESENT;

        let cr3 = PML4.as_phys();
        core::arch::asm!("mov cr3, {0}", in(reg) cr3,
            options(nostack, preserves_flags));
    });
}

/// Copy the kernel higher-half PML4 entries (indices 256..512) into `cr3`.
/// Called when building a new per-process page table so ring-0 handlers
/// can still reach kernel code after a CR3 switch.
pub fn install_kernel_entries(cr3: usize) {
    let dst = cr3 as *mut u64;
    let src = unsafe { PML4.0.as_ptr() };
    for i in 256usize..512 {
        unsafe {
            let entry = src.add(i).read_volatile();
            if entry != 0 {
                dst.add(i).write_volatile(entry);
            }
        }
    }
}

/// Map one 4 KiB user-accessible page in the given PML4 (cr3).
///
/// Allocates intermediate tables (PDPT, PD, PT) on demand.
/// Flags: PRESENT | WRITE | USER.
pub fn map_user_page(cr3: usize, va: usize, pa: usize) {
    map_4k(cr3, va, pa, PRESENT | WRITE | USER);
}

/// Map one 4 KiB kernel page (no USER bit).
pub fn map_kernel_page(cr3: usize, va: usize, pa: usize) {
    map_4k(cr3, va, pa, PRESENT | WRITE);
}

fn map_4k(cr3: usize, va: usize, pa: usize, flags: u64) {
    let pml4_idx = (va >> 39) & 0x1FF;
    let pdpt_idx = (va >> 30) & 0x1FF;
    let pd_idx   = (va >> 21) & 0x1FF;
    let pt_idx   = (va >> 12) & 0x1FF;

    unsafe {
        let pml4 = cr3 as *mut u64;

        let pdpt = ensure_table(pml4.add(pml4_idx));
        let pd   = ensure_table(pdpt.add(pdpt_idx));
        let pt   = ensure_table(pd.add(pd_idx));

        // Leaf PTE
        pt.add(pt_idx).write_volatile((pa as u64 & !0xFFF) | flags);
    }
}

/// Return the child table pointer, allocating a new one if the entry is absent.
unsafe fn ensure_table(entry_ptr: *mut u64) -> *mut u64 {
    let entry = entry_ptr.read_volatile();
    if entry & PRESENT != 0 {
        (entry & !0xFFF) as *mut u64
    } else {
        let child_pa = alloc_pt_page();
        entry_ptr.write_volatile(child_pa as u64 | WRITE | PRESENT | USER);
        child_pa as *mut u64
    }
}

/// Flush a single VA from the TLB.
#[inline]
pub fn flush(va: u64) {
    unsafe {
        core::arch::asm!("invlpg [{0}]", in(reg) va,
            options(nostack, preserves_flags));
    }
}

/// Flush the entire TLB by reloading CR3.
#[inline]
pub fn flush_all() {
    unsafe {
        let cr3: u64;
        core::arch::asm!("mov {0}, cr3", out(reg) cr3,
            options(nostack, preserves_flags));
        core::arch::asm!("mov cr3, {0}", in(reg) cr3,
            options(nostack, preserves_flags));
    }
}

// ── PTE helpers for mmap ──────────────────────────────────────────────────

const PTE_PRESENT:    u64 = 1 << 0;
const PTE_WRITABLE:   u64 = 1 << 1;
const PTE_USER:       u64 = 1 << 2;
const PTE_NX:         u64 = 1 << 63;
const PTE_ADDR_MASK:  u64 = 0x000F_FFFF_FFFF_F000;

unsafe fn current_pml4() -> *mut u64 {
    let cr3: u64;
    core::arch::asm!("mov {}, cr3", out(reg) cr3);
    (cr3 & !0xFFF) as *mut u64
}

unsafe fn ensure_table(entry: *mut u64, user: bool) -> *mut u64 {
    if *entry & PTE_PRESENT == 0 {
        let pa = crate::mm::pmm::alloc_page().expect("OOM: page table");
        core::ptr::write_bytes(pa as *mut u8, 0, 4096);
        let mut flags = PTE_PRESENT | PTE_WRITABLE;
        if user { flags |= PTE_USER; }
        *entry = pa as u64 | flags;
    }
    ((*entry & PTE_ADDR_MASK) as *mut u64)
}

/// Map a single 4 KiB page: VA → PA with given permissions.
pub fn map_page(va: usize, pa: usize, writable: bool, user: bool, exec: bool) {
    let pml4i = (va >> 39) & 0x1FF;
    let pdpti = (va >> 30) & 0x1FF;
    let pdi   = (va >> 21) & 0x1FF;
    let pti   = (va >> 12) & 0x1FF;
    unsafe {
        let pml4 = current_pml4();
        let pdpt = ensure_table(pml4.add(pml4i), user);
        let pd   = ensure_table(pdpt.add(pdpti), user);
        let pt   = ensure_table(pd.add(pdi),     user);
        let mut flags = PTE_PRESENT;
        if writable  { flags |= PTE_WRITABLE; }
        if user      { flags |= PTE_USER; }
        if !exec     { flags |= PTE_NX; }
        *pt.add(pti) = pa as u64 | flags;
        // TLB flush
        core::arch::asm!("invlpg [{0}]", in(reg) va);
    }
}

/// Unmap a single 4 KiB page, returning its physical address (or None).
pub fn unmap_page(va: usize) -> Option<usize> {
    let pml4i = (va >> 39) & 0x1FF;
    let pdpti = (va >> 30) & 0x1FF;
    let pdi   = (va >> 21) & 0x1FF;
    let pti   = (va >> 12) & 0x1FF;
    unsafe {
        let pml4 = current_pml4();
        let e1 = pml4.add(pml4i); if *e1 & PTE_PRESENT == 0 { return None; }
        let pdpt = (*e1 & PTE_ADDR_MASK) as *mut u64;
        let e2 = pdpt.add(pdpti); if *e2 & PTE_PRESENT == 0 { return None; }
        let pd = (*e2 & PTE_ADDR_MASK) as *mut u64;
        let e3 = pd.add(pdi); if *e3 & PTE_PRESENT == 0 { return None; }
        let pt = (*e3 & PTE_ADDR_MASK) as *mut u64;
        let e4 = pt.add(pti); if *e4 & PTE_PRESENT == 0 { return None; }
        let pa = (*e4 & PTE_ADDR_MASK) as usize;
        *e4 = 0;
        core::arch::asm!("invlpg [{0}]", in(reg) va);
        Some(pa)
    }
}

/// Update protection bits on an already-mapped page.
pub fn set_page_prot(va: usize, writable: bool, exec: bool) {
    let pml4i = (va >> 39) & 0x1FF;
    let pdpti = (va >> 30) & 0x1FF;
    let pdi   = (va >> 21) & 0x1FF;
    let pti   = (va >> 12) & 0x1FF;
    unsafe {
        let pml4 = current_pml4();
        let e1 = pml4.add(pml4i); if *e1 & PTE_PRESENT == 0 { return; }
        let pdpt = (*e1 & PTE_ADDR_MASK) as *mut u64;
        let e2 = pdpt.add(pdpti); if *e2 & PTE_PRESENT == 0 { return; }
        let pd = (*e2 & PTE_ADDR_MASK) as *mut u64;
        let e3 = pd.add(pdi); if *e3 & PTE_PRESENT == 0 { return; }
        let pt = (*e3 & PTE_ADDR_MASK) as *mut u64;
        let e4 = pt.add(pti);
        let pa_flags = *e4 & PTE_ADDR_MASK;
        let mut new_flags = PTE_PRESENT | PTE_USER | pa_flags;
        if writable { new_flags |= PTE_WRITABLE; }
        if !exec    { new_flags |= PTE_NX; }
        *e4 = new_flags;
        core::arch::asm!("invlpg [{0}]", in(reg) va);
    }
}

/// Map `va` → `pa` in the given PML4 `cr3` WITHOUT switching the current CR3.
/// Used by the ELF loader to build a new address space while the old one is live.
pub fn map_page_in(cr3: usize, va: usize, pa: usize, writable: bool, user: bool, exec: bool) {
    // Save current CR3
    let old_cr3: usize;
    unsafe { core::arch::asm!("mov {}, cr3", out(reg) old_cr3); }

    if old_cr3 & !0xFFF != cr3 {
        // Switch to target address space temporarily
        unsafe { core::arch::asm!("mov cr3, {}", in(reg) cr3, options(nostack)); }
    }
    map_page(va, pa, writable, user, exec);
    if old_cr3 & !0xFFF != cr3 {
        unsafe { core::arch::asm!("mov cr3, {}", in(reg) old_cr3, options(nostack)); }
    }
}
