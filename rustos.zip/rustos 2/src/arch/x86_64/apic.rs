//! Local APIC initialisation and timer.
//!
//! Supports both x2APIC (MSR-based) and xAPIC (MMIO-based).
//! Timer is programmed in periodic mode at ~10 ms using the TSC-deadline
//! method if available, otherwise a calibrated PIT-backed periodic counter.

use spin::Once;
use crate::arch::x86_64::cpu;

// x2APIC MSRs
const X2APIC_BASE:      u32 = 0x800;
const X2APIC_ID:        u32 = X2APIC_BASE + 0x02;
const X2APIC_EOI:       u32 = X2APIC_BASE + 0x0B;
const X2APIC_SPURIOUS:  u32 = X2APIC_BASE + 0x0F;
const X2APIC_ICR:       u32 = X2APIC_BASE + 0x30;
const X2APIC_LVT_TIMER: u32 = X2APIC_BASE + 0x32;
const X2APIC_INIT_COUNT:u32 = X2APIC_BASE + 0x38;
const X2APIC_CURR_COUNT:u32 = X2APIC_BASE + 0x39;
const X2APIC_DIV_CFG:   u32 = X2APIC_BASE + 0x3E;

// xAPIC MMIO base (identity-mapped)
const XAPIC_BASE: usize = 0xFEE0_0000;

const TIMER_VECTOR:    u8 = 0x30;
const SPURIOUS_VECTOR: u8 = 0xFF;
const TIMER_PERIODIC:  u32 = 1 << 17;
// Divide by 16
const DIVIDE_16: u32 = 0x3;

static APIC_INIT: Once<()> = Once::new();
static mut USE_X2APIC: bool = false;

unsafe fn rdmsr(msr: u32) -> u64 {
    let lo: u32; let hi: u32;
    core::arch::asm!("rdmsr", in("ecx") msr, out("eax") lo, out("edx") hi,
                     options(nostack, nomem));
    (hi as u64) << 32 | lo as u64
}

unsafe fn wrmsr(msr: u32, val: u64) {
    core::arch::asm!("wrmsr", in("ecx") msr,
                     in("eax") (val as u32), in("edx") (val >> 32) as u32,
                     options(nostack, nomem));
}

fn xapic_write(reg: usize, val: u32) {
    unsafe { ((XAPIC_BASE + reg) as *mut u32).write_volatile(val); }
}
fn xapic_read(reg: usize) -> u32 {
    unsafe { ((XAPIC_BASE + reg) as *const u32).read_volatile() }
}

pub fn init() {
    APIC_INIT.call_once(|| unsafe {
        // Enable APIC (IA32_APIC_BASE bit 11)
        let base = rdmsr(0x1B);
        wrmsr(0x1B, base | (1 << 11));

        USE_X2APIC = cpu::has_x2apic();
        if USE_X2APIC {
            // Enable x2APIC (bit 10)
            wrmsr(0x1B, base | (1 << 11) | (1 << 10));
            // Spurious vector register — enable APIC + set spurious vector
            wrmsr(X2APIC_SPURIOUS as u32, 0x100 | SPURIOUS_VECTOR as u64);
            // LVT timer: periodic, vector 0x30
            wrmsr(X2APIC_LVT_TIMER as u32,
                  (TIMER_PERIODIC as u64) | TIMER_VECTOR as u64);
            // Divide by 16
            wrmsr(X2APIC_DIV_CFG as u32, DIVIDE_16 as u64);
            // Initial count — calibrate later; use ~10M cycles as placeholder
            wrmsr(X2APIC_INIT_COUNT as u32, 10_000_000u64);
            let id = rdmsr(X2APIC_ID as u32);
            crate::serial_println!("[apic] x2APIC initialised (id={})", id);
        } else {
            // xAPIC path
            xapic_write(0x0F0, 0x100 | SPURIOUS_VECTOR as u32);
            xapic_write(0x320, TIMER_PERIODIC | TIMER_VECTOR as u32);
            xapic_write(0x3E0, DIVIDE_16);
            xapic_write(0x380, 10_000_000);
            let id = xapic_read(0x020) >> 24;
            crate::serial_println!("[apic] xAPIC initialised (id={})", id);
        }
    });
}

/// Signal end-of-interrupt.  Must be called before any context switch.
pub fn eoi() {
    unsafe {
        if USE_X2APIC {
            wrmsr(X2APIC_EOI, 0);
        } else {
            xapic_write(0x0B0, 0);
        }
    }
}

/// Send a self-IPI on `vector` to force an immediate reschedule.
pub fn send_self_ipi(vector: u8) {
    unsafe {
        if USE_X2APIC {
            // ICR format for self-IPI: dest=self (0), delivery=fixed, vector
            wrmsr(X2APIC_ICR, (0x4000_0000u64) | vector as u64);
        } else {
            // xAPIC: write ICR low (dest shorthand = self = 0b01 << 18 → 0x4_0000)
            xapic_write(0x300, 0x0004_0000 | vector as u32);
        }
    }
}

static TICK_COUNT: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);

pub fn tick_inc() { TICK_COUNT.fetch_add(1, core::sync::atomic::Ordering::Relaxed); }
pub fn ticks() -> u64 { TICK_COUNT.load(core::sync::atomic::Ordering::Relaxed) }
