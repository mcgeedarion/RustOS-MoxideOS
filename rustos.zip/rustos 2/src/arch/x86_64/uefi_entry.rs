//! UEFI entry → kernel_main.
//! After heap is live: PMM → heap → syscall init → proc init → hlt loop.

use uefi::prelude::*;
use uefi::table::boot::MemoryType;
use crate::arch::x86_64::{apic, cpu, gdt, idt, paging, serial, syscall as sc};
use crate::mm::{heap, pmm};

const MAP_BUF_SIZE: usize = 32 * 1024;
const MAX_REGIONS:  usize = 256;

static mut MAP_BUF:     [u8; MAP_BUF_SIZE]      = [0u8; MAP_BUF_SIZE];
static mut MEM_REGIONS: [MemRegion; MAX_REGIONS] = [MemRegion::zero(); MAX_REGIONS];
static mut MEM_COUNT:   usize                    = 0;

#[derive(Clone, Copy, Debug)]
pub struct MemRegion { pub base: u64, pub len: u64, pub kind: RegionKind }
impl MemRegion { const fn zero() -> Self { Self { base:0, len:0, kind: RegionKind::Other } } }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RegionKind { Usable, Reserved, AcpiReclaimable, AcpiNvs, Firmware, Other }

#[entry]
fn efi_main(image: Handle, mut st: SystemTable<Boot>) -> Status {
    st.stdout().reset(false).expect("stdout");
    st.stdout().output_string(cstr16!("rustos x86_64\r\n")).expect("banner");

    let buf = unsafe { &mut MAP_BUF };
    let (_, iter) = st.boot_services().memory_map(buf).expect("mmap1");
    let mut count = 0usize;
    for d in iter {
        if count >= MAX_REGIONS { break; }
        unsafe { MEM_REGIONS[count] = MemRegion { base: d.phys_start,
            len: d.page_count*4096, kind: uefi_kind(d.ty) }; }
        count += 1;
    }
    unsafe { MEM_COUNT = count; }
    let (key, _) = st.boot_services().memory_map(buf).expect("mmap2");
    unsafe { st.unsafe_clone().boot_services().exit_boot_services(image, key); }

    serial::init();
    serial_println!("[uefi] ExitBootServices ({} regions)", unsafe { MEM_COUNT });

    gdt::init();    serial_println!("[gdt]    loaded");
    idt::init();    serial_println!("[idt]    loaded");
    paging::init(); serial_println!("[paging] active");
    cpu::enable_sse();
    if cpu::has_fsgsbase() { cpu::enable_fsgsbase(); }
    let (v, _) = cpu::vendor();
    serial_println!("[cpu] {}", core::str::from_utf8(&v).unwrap_or("?"));
    apic::init();
    unsafe { core::arch::asm!("sti", options(nostack, nomem)); }
    serial_println!("[boot] interrupts enabled");

    kernel_main(unsafe { &MEM_REGIONS[..MEM_COUNT] })
}

fn uefi_kind(ty: MemoryType) -> RegionKind {
    match ty {
        MemoryType::CONVENTIONAL         => RegionKind::Usable,
        MemoryType::ACPI_RECLAIM         => RegionKind::AcpiReclaimable,
        MemoryType::ACPI_NON_VOLATILE    => RegionKind::AcpiNvs,
        MemoryType::BOOT_SERVICES_CODE
        | MemoryType::BOOT_SERVICES_DATA => RegionKind::Firmware,
        _                                => RegionKind::Reserved,
    }
}

pub fn kernel_main(regions: &[MemRegion]) -> ! {
    // PMM
    pmm::init_from_map(regions);
    serial_println!("[pmm] {}/{} MiB",
        pmm::free_pages()*pmm::PAGE_SIZE/(1<<20),
        pmm::total_pages()*pmm::PAGE_SIZE/(1<<20));

    // Heap
    heap::init_from_pmm(1024);
    {
        extern crate alloc; use alloc::vec::Vec;
        let v: Vec<u64> = (0u64..64).map(|i| i*i).collect();
        assert_eq!(v[8], 64);
    }
    serial_println!("[heap] {} KiB OK", heap::ALLOCATOR.0.lock().size()/1024);

    // SYSCALL/SYSRET
    // Use a fresh kernel stack page for the idle SYSCALL stack.
    let idle_kstack = pmm::alloc_page().expect("idle kstack") + pmm::PAGE_SIZE;
    sc::init(idle_kstack as u64);
    serial_println!("[syscall] SYSCALL/SYSRET armed");

    // Block device + filesystem
    crate::drivers::virtio_blk::init();
    crate::fs::mount::mount_root();

    // Network stack
    crate::net::init();

    // Record boot tick for /proc/uptime
    crate::fs::procfs::set_boot_tick(crate::arch::x86_64::apic::ticks());

    // Process scheduler
    crate::proc::init();

    // Halt loop — APIC timer drives the scheduler
    serial_println!("[kernel] scheduler loop (timer ~10 ms)");
    loop { unsafe { core::arch::asm!("hlt", options(nostack, nomem)); } }
}
