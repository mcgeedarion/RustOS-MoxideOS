//! 64-bit Global Descriptor Table.
//!
//! Descriptor layout:
//!   0x00 — null
//!   0x08 — kernel code  (ring 0, 64-bit)
//!   0x10 — kernel data  (ring 0)
//!   0x18 — user code    (ring 3, 64-bit)   ← required for SYSRET / IRET
//!   0x20 — user data    (ring 3)
//!   0x28 — TSS (2 × u64 = 128-bit system descriptor)
//!
//! `set_rsp0(val)` is called by the scheduler on every context switch so
//! that ring-0 entry (via interrupt) uses the new process's kernel stack.

use core::sync::atomic::{AtomicU64, Ordering};
use spin::Once;

// ── Selector constants ────────────────────────────────────────────────────

pub const SEL_KERNEL_CODE: u16 = 0x08;
pub const SEL_KERNEL_DATA: u16 = 0x10;
pub const SEL_USER_CODE:   u16 = 0x18 | 3;  // RPL = 3
pub const SEL_USER_DATA:   u16 = 0x20 | 3;  // RPL = 3
pub const SEL_TSS:         u16 = 0x28;

// ── TSS ───────────────────────────────────────────────────────────────────

/// Minimal 64-bit Task State Segment.
/// Only RSP0 is used — ring-0 stack on interrupts from ring 3.
#[repr(C, packed)]
pub struct Tss {
    _reserved0: u32,
    pub rsp0:   u64,
    pub rsp1:   u64,
    pub rsp2:   u64,
    _reserved1: u64,
    pub ist1:   u64,  // NMI
    pub ist2:   u64,  // #DF
    pub ist3:   u64,  // #MC
    _reserved2: [u64; 5],
    _reserved3: u16,
    pub iobase:  u16,
}

impl Tss {
    pub const fn zero() -> Self {
        Self {
            _reserved0: 0, rsp0: 0, rsp1: 0, rsp2: 0,
            _reserved1: 0,
            ist1: 0, ist2: 0, ist3: 0,
            _reserved2: [0; 5], _reserved3: 0,
            iobase: core::mem::size_of::<Tss>() as u16,
        }
    }
}

// ── GDT storage ──────────────────────────────────────────────────────────

#[repr(C, align(16))]
struct GdtStorage([u64; 8]);

static mut GDT: GdtStorage  = GdtStorage([0u64; 8]);
static mut TSS: Tss          = Tss::zero();

// Scratch IST stacks (4 KiB each — good enough for kernel fault handlers)
static mut NMI_STACK: [u8; 4096] = [0; 4096];
static mut DF_STACK:  [u8; 4096] = [0; 4096];
static mut MC_STACK:  [u8; 4096] = [0; 4096];

static GDT_INIT: Once<()> = Once::new();

// RSP0 is written atomically so it is visible to the next ISR immediately.
static RSP0: AtomicU64 = AtomicU64::new(0);

/// Update RSP0 in the TSS — call this before every context switch.
pub fn set_rsp0(rsp0: u64) {
    RSP0.store(rsp0, Ordering::Release);
    unsafe { TSS.rsp0 = rsp0; }
}

/// Build GDT + TSS, then load them.
pub fn init() {
    GDT_INIT.call_once(|| unsafe {
        // Set up IST stacks in the TSS.
        TSS.ist1 = NMI_STACK.as_ptr().add(4096) as u64;
        TSS.ist2 = DF_STACK.as_ptr().add(4096)  as u64;
        TSS.ist3 = MC_STACK.as_ptr().add(4096)  as u64;

        // Build GDT entries.
        GDT.0[0] = 0;                          // null
        GDT.0[1] = 0x0020_9800_0000_0000u64;   // kernel code (64-bit, DPL=0)
        GDT.0[2] = 0x0000_9200_0000_0000u64;   // kernel data (DPL=0)
        GDT.0[3] = 0x0020_F800_0000_0000u64;   // user   code (64-bit, DPL=3)
        GDT.0[4] = 0x0000_F200_0000_0000u64;   // user   data (DPL=3)

        // TSS descriptor (128-bit system descriptor spanning slots 5+6).
        let tss_base  = &TSS as *const Tss as u64;
        let tss_limit = (core::mem::size_of::<Tss>() - 1) as u64;
        let tss_lo = (tss_limit & 0xFFFF)
            | ((tss_base  & 0x00FF_FFFF) << 16)
            | (0x89u64 << 40)              // present, type=TSS available
            | (((tss_limit >> 16) & 0xF) << 48)
            | (((tss_base >> 24) & 0xFF)  << 56);
        let tss_hi = tss_base >> 32;

        GDT.0[5] = tss_lo;
        GDT.0[6] = tss_hi;

        #[repr(C, packed)]
        struct GdtPtr { limit: u16, base: u64 }
        let ptr = GdtPtr {
            limit: (core::mem::size_of::<GdtStorage>() - 1) as u16,
            base:  GDT.0.as_ptr() as u64,
        };

        core::arch::asm!(
            "lgdt [{0}]",
            // Reload CS via a far return
            "push {cs}",
            "lea  {tmp}, [rip + 1f]",
            "push {tmp}",
            "retfq",
            "1:",
            // Reload data segment registers
            "mov ax, {ds}",
            "mov ds, ax",
            "mov es, ax",
            "mov ss, ax",
            "xor ax, ax",
            "mov fs, ax",
            "mov gs, ax",
            in(reg) &ptr,
            cs  = const SEL_KERNEL_CODE as u64,
            ds  = const SEL_KERNEL_DATA as u64,
            tmp = lateout(reg) _,
            out("ax") _,
            options(nostack),
        );

        // Load the TSS.
        core::arch::asm!(
            "ltr {0:x}",
            in(reg) SEL_TSS,
            options(nostack, nomem),
        );
    });
}
