//! x86_64 syscall entry via the SYSCALL/SYSRET fast-path (Intel SDM §3.4).
//!
//! # Register convention (Linux-compatible ABI)
//!   rax = syscall number (in) / return value (out)
//!   rdi = arg0
//!   rsi = arg1
//!   rdx = arg2
//!   r10 = arg3   (note: Linux uses r10 not rcx — rcx is clobbered by SYSCALL)
//!   r8  = arg4
//!   r9  = arg5
//!
//! # SYSCALL mechanics
//!   CPU saves user RIP  → RCX
//!   CPU saves RFLAGS    → R11
//!   CPU loads RIP from IA32_LSTAR
//!   CPU loads CS/SS from IA32_STAR
//!   Interrupts are disabled (RFLAGS.IF cleared via IA32_FMASK).
//!
//! `syscall_entry` (assembly stub below):
//!   1. Swaps to the kernel stack using IA32_KERNEL_GS_BASE + SWAPGS.
//!   2. Saves the minimal user context (rcx/r11/rsp).
//!   3. Re-enables interrupts so the APIC timer can still preempt.
//!   4. Calls `syscall_rust_handler`.
//!   5. Restores context and executes SYSRET (ring 3, 64-bit).
//!
//! # MSR addresses
//!   IA32_STAR           = 0xC000_0081
//!   IA32_LSTAR          = 0xC000_0082
//!   IA32_FMASK          = 0xC000_0084
//!   IA32_KERNEL_GS_BASE = 0xC000_0102  (kernel stack pointer stored here)

use core::arch::global_asm;
use crate::arch::x86_64::gdt::{SEL_KERNEL_CODE, SEL_KERNEL_DATA, SEL_USER_CODE, SEL_USER_DATA};

// ── MSR helpers ───────────────────────────────────────────────────────────

const IA32_STAR:           u32 = 0xC000_0081;
const IA32_LSTAR:          u32 = 0xC000_0082;
const IA32_FMASK:          u32 = 0xC000_0084;
const IA32_KERNEL_GS_BASE: u32 = 0xC000_0102;

unsafe fn wrmsr(msr: u32, val: u64) {
    let lo = (val & 0xFFFF_FFFF) as u32;
    let hi = (val >> 32) as u32;
    core::arch::asm!("wrmsr", in("ecx") msr, in("eax") lo, in("edx") hi,
                     options(nostack, nomem));
}

// ── Per-CPU kernel-stack scratchpad ──────────────────────────────────────

/// Layout expected by the assembly stub:
///   [+0]  u64  kernel RSP   ← loaded on syscall entry via SWAPGS
///   [+8]  u64  user   RSP   ← saved here so we can restore it on SYSRET
#[repr(C)]
pub struct CpuInfo {
    pub kernel_rsp: u64,
    pub user_rsp:   u64,
}

static mut CPU_INFO: CpuInfo = CpuInfo { kernel_rsp: 0, user_rsp: 0 };

/// Full register frame saved by the syscall entry stub.
/// Passed as `&mut SyscallFrame` to `syscall_rust_handler`.
#[repr(C)]
pub struct SyscallFrame {
    pub r11:    u64,   // saved RFLAGS
    pub rcx:    u64,   // saved user RIP  (return address after SYSRET)
    pub r9:     u64,
    pub r8:     u64,
    pub r10:    u64,   // arg3 (Linux ABI: replaces rcx)
    pub rdx:    u64,   // arg2
    pub rsi:    u64,   // arg1
    pub rdi:    u64,   // arg0
    pub rax:    u64,   // syscall number / return value
    pub rbx:    u64,
    pub rbp:    u64,
    pub r12:    u64,
    pub r13:    u64,
    pub r14:    u64,
    pub r15:    u64,
    pub user_rsp: u64, // saved user RSP
}

// ── Assembly entry stub ───────────────────────────────────────────────────

global_asm!(r#"
.global syscall_entry
syscall_entry:
    # At this point:
    #   rcx = user RIP, r11 = user RFLAGS, rsp = user RSP
    #   interrupts are OFF (IA32_FMASK cleared IF)

    swapgs                              # GS.base now points to CpuInfo
    mov  gs:[8],    rsp                 # save user RSP → CpuInfo.user_rsp
    mov  rsp,       gs:[0]             # load kernel RSP from CpuInfo.kernel_rsp

    # Build SyscallFrame on kernel stack (push in REVERSE field order)
    push  qword ptr gs:[8]              # user_rsp
    push  r15
    push  r14
    push  r13
    push  r12
    push  rbp
    push  rbx
    push  rax                           # syscall number
    push  rdi                           # arg0
    push  rsi                           # arg1
    push  rdx                           # arg2
    push  r10                           # arg3
    push  r8                            # arg4
    push  r9                            # arg5
    push  rcx                           # saved user RIP
    push  r11                           # saved RFLAGS

    # Re-enable interrupts — allow preemption during syscall body.
    sti

    # Call Rust handler: rdi = &mut SyscallFrame
    mov   rdi, rsp
    call  syscall_rust_handler

    # Disable interrupts before restoring user context.
    cli

    # Restore GP registers from frame (rax already has return value).
    pop   r11                           # RFLAGS → r11 (SYSRET restores)
    pop   rcx                           # user RIP → rcx (SYSRET uses)
    pop   r9
    pop   r8
    pop   r10
    pop   rdx
    pop   rsi
    pop   rdi
    pop   rax                           # return value
    pop   rbx
    pop   rbp
    pop   r12
    pop   r13
    pop   r14
    pop   r15
    pop   rsp                           # restore user RSP

    swapgs
    sysretq                             # → ring 3, 64-bit
"#);

extern "C" { fn syscall_entry(); }

// ── Rust handler ──────────────────────────────────────────────────────────

/// Called from `syscall_entry` with interrupts enabled.
/// `frame.rax` holds the syscall number on entry and the return value on exit.
#[no_mangle]
pub extern "C" fn syscall_rust_handler(frame: &mut SyscallFrame) {
    let ret = crate::syscall::handle_x86(frame);
    frame.rax = ret as u64;
    // Deliver any pending signals before returning to user space.
    crate::syscall::check_signals_x86(frame);
}

// ── Initialise SYSCALL/SYSRET ─────────────────────────────────────────────

/// Programme all MSRs for SYSCALL/SYSRET and point IA32_KERNEL_GS_BASE at
/// our per-CPU scratch area.  Called once from `uefi_entry::kernel_main`.
pub fn init(kernel_stack_top: u64) {
    unsafe {
        // IA32_STAR: bits[47:32] = kernel CS (SYSCALL loads CS from here,
        //            SS = CS+8);  bits[63:48] = user CS-16 (SYSRET adds 16).
        // We need: SYSCALL → kernel CS = SEL_KERNEL_CODE (0x08)
        //          SYSRET  → user   CS = SEL_USER_CODE   (0x18|3 = 0x1B)
        // STAR[47:32] = 0x0008  → kernel CS=0x08, SS=0x10
        // STAR[63:48] = 0x0018  → sysret CS=0x18|3, SS=0x20|3
        let star: u64 = ((SEL_USER_CODE as u64 - 16) << 48)
                      | ((SEL_KERNEL_CODE as u64)     << 32);
        wrmsr(IA32_STAR,  star);

        // IA32_LSTAR: RIP to jump to on SYSCALL
        wrmsr(IA32_LSTAR, syscall_entry as u64);

        // IA32_FMASK: bits to clear in RFLAGS on SYSCALL.
        // Clear IF (disable interrupts) + DF (direction flag).
        wrmsr(IA32_FMASK, 0x0000_0200 | 0x0000_0400);

        // IA32_KERNEL_GS_BASE: kernel GS (swapgs swaps user↔kernel GS).
        CPU_INFO.kernel_rsp = kernel_stack_top;
        wrmsr(IA32_KERNEL_GS_BASE, &CPU_INFO as *const CpuInfo as u64);

        // Enable SYSCALL/SYSRET in IA32_EFER (SCE bit 0).
        let mut efer: u64;
        core::arch::asm!("rdmsr", in("ecx") 0xC000_0080u32,
                         out("eax") efer, out("edx") _,
                         options(nostack, nomem));
        efer |= 1; // SCE
        core::arch::asm!("wrmsr", in("ecx") 0xC000_0080u32,
                         in("eax") (efer as u32), in("edx") (efer >> 32) as u32,
                         options(nostack, nomem));
    }
}

/// Update the kernel RSP in the SWAPGS scratchpad — call on every context
/// switch so SYSCALL entries use the new process's kernel stack.
pub fn set_kernel_stack(rsp: u64) {
    unsafe { CPU_INFO.kernel_rsp = rsp; }
}
