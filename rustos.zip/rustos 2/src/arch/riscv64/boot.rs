//! Kernel entry — Sv39 activation, identity-map removal, then rust_main
use core::arch::global_asm;
use crate::arch::riscv64::csr::{
    write_satp, sfence_vma, write_stvec, sstatus_set_sum, enable_timer_interrupt,
};
use crate::mm::vmm_boot;

global_asm!(
    ".section .text.entry",
    ".global _start",
    "_start:",
    "  la   sp, _stack_top",
    "  la   t0, _bss_start",
    "  la   t1, _bss_end",
    "1:",
    "  bge  t0, t1, 2f",
    "  sd   zero, 0(t0)",
    "  addi t0, t0, 8",
    "  j    1b",
    "2:",
    "  call rust_pre_main",
);

#[no_mangle]
pub extern "C" fn rust_pre_main() -> ! {
    crate::mm::pmm::init();

    let boot_satp = vmm_boot::build_boot_kernel_pt();
    unsafe {
        write_stvec(early_trap_handler as usize);
        write_satp(boot_satp);
        sfence_vma();
    }

    // SECURITY: strip identity map now that we are running at higher-half VAs.
    // From this point no PA==VA mapping exists in the kernel page table.
    vmm_boot::remove_identity_map(boot_satp);

    rust_main()
}

#[no_mangle]
pub extern "C" fn rust_main() -> ! {
    crate::mm::heap::init();
    crate::drivers::uart::init();
    crate::drivers::uart::puts("[boot] rustos_kernel\n");

    // Allow S-mode to access user pages during copy_{from,to}_user
    sstatus_set_sum();

    crate::drivers::plic::init();
    crate::drivers::clint::init();
    enable_timer_interrupt();
    crate::drivers::uart::puts("[boot] timer armed\n");

    crate::drivers::virtio_blk::init();
    crate::drivers::virtio_net::init();
    crate::proc::init();

    crate::drivers::uart::puts("[boot] entering shell\n");
    crate::shell::tty::run()
}

#[no_mangle]
extern "C" fn early_trap_handler() -> ! {
    crate::drivers::uart::puts("[early trap] fault before full init\n");
    loop {}
}
