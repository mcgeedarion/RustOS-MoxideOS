//! RISC-V CSR helpers

pub const SATP_MODE_SV39: usize = 8usize << 60;

#[inline(always)]
pub fn make_satp(root_ppn: usize) -> usize {
    SATP_MODE_SV39 | (root_ppn & 0x0000_0FFF_FFFF_FFFF)
}

#[inline(always)]
pub fn satp_ppn(satp: usize) -> usize {
    satp & 0x0000_0FFF_FFFF_FFFF
}

#[inline(always)]
pub fn read_satp() -> usize {
    let v: usize;
    unsafe { core::arch::asm!("csrr {0}, satp", out(reg) v) };
    v
}

#[inline(always)]
pub fn write_satp(val: usize) {
    unsafe { core::arch::asm!("csrw satp, {0}", in(reg) val) };
}

/// Full TLB flush — must follow every SATP write.
#[inline(always)]
pub fn sfence_vma() {
    unsafe { core::arch::asm!("sfence.vma zero, zero") };
}

#[inline(always)]
pub fn read_sepc() -> usize {
    let v: usize;
    unsafe { core::arch::asm!("csrr {0}, sepc", out(reg) v) };
    v
}

#[inline(always)]
pub fn write_sepc(val: usize) {
    unsafe { core::arch::asm!("csrw sepc, {0}", in(reg) val) };
}

#[inline(always)]
pub fn read_stvec() -> usize {
    let v: usize;
    unsafe { core::arch::asm!("csrr {0}, stvec", out(reg) v) };
    v
}

/// Set stvec in Direct mode (bits[1:0] = 0).
#[inline(always)]
pub fn write_stvec(val: usize) {
    // Mask off mode bits to force Direct mode
    let v = val & !0b11;
    unsafe { core::arch::asm!("csrw stvec, {0}", in(reg) v) };
}

#[inline(always)]
pub fn read_sstatus() -> usize {
    let v: usize;
    unsafe { core::arch::asm!("csrr {0}, sstatus", out(reg) v) };
    v
}

#[inline(always)]
pub fn write_sstatus(val: usize) {
    unsafe { core::arch::asm!("csrw sstatus, {0}", in(reg) val) };
}

/// Set sstatus.SUM so S-mode can access user pages (needed for uaccess).
#[inline(always)]
pub fn sstatus_set_sum() {
    unsafe {
        core::arch::asm!(
            "li   t0, (1 << 18)",  // SUM bit
            "csrs sstatus, t0",
            out("t0") _,
        );
    }
}

/// Enable supervisor timer interrupt (sstatus.SIE + sie.STIE).
pub fn enable_timer_interrupt() {
    unsafe {
        // Set sie.STIE (bit 5)
        core::arch::asm!("li t0, 0x20", "csrs sie, t0", out("t0") _);
        // Set sstatus.SIE (bit 1)
        core::arch::asm!("li t0, 0x2",  "csrs sstatus, t0", out("t0") _);
    }
}
