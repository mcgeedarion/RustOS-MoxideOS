//! Trap handler — timer re-arm, syscall dispatch, page faults, process kill
use crate::arch::riscv64::csr;
use crate::mm::vmm;
use crate::drivers::{uart, clint};

#[repr(C)]
pub struct TrapFrame {
    pub regs:       [usize; 32],
    pub sepc:        usize,
    pub sstatus:     usize,
    pub user_satp:   usize,
    pub kernel_satp: usize,
    pub kernel_sp:   usize,
}

#[no_mangle]
pub extern "C" fn trap_handler(tf: &mut TrapFrame) {
    let scause: usize;
    let stval:  usize;
    unsafe {
        core::arch::asm!("csrr {0}, scause", out(reg) scause);
        core::arch::asm!("csrr {0}, stval",  out(reg) stval);
    }

    let is_interrupt = scause >> 63 != 0;
    let code         = scause & !(1usize << 63);

    if is_interrupt {
        match code {
            5 => { // Supervisor timer
                clint::set_timer(clint::TIMER_INTERVAL);
                crate::proc::scheduler::tick();
            }
            9 => { /* PLIC — TODO */ }
            _ => { uart::puts("[trap] unknown interrupt\n"); }
        }
    } else {
        match code {
            12 | 13 | 15 => { // Page fault
                if vmm::handle_page_fault(stval) {
                    csr::sfence_vma();
                    return;
                }
                // Page fault in user process — kill it, don't freeze the kernel
                uart::puts("[trap] user page fault @ ");
                print_hex(stval);
                uart::puts(" — killing process\n");
                crate::proc::scheduler::exit(-11); // SIGSEGV
            }
            8 => { // ecall from U-mode
                crate::syscall::handle(tf);
                tf.sepc += 4;
            }
            2 => { // Illegal instruction in user process
                uart::puts("[trap] illegal instruction — killing process\n");
                crate::proc::scheduler::exit(-4); // SIGILL
            }
            _ => {
                // Unknown exception: if from U-mode (sstatus.SPP==0), kill process;
                // if from S-mode, panic.
                let spp = (tf.sstatus >> 8) & 1;
                if spp == 0 {
                    uart::puts("[trap] unhandled user exception scause=");
                    print_hex(scause);
                    uart::puts(" — killing process\n");
                    crate::proc::scheduler::exit(-1);
                } else {
                    uart::puts("[trap] FATAL kernel exception scause=");
                    print_hex(scause);
                    uart::puts(" stval=");
                    print_hex(stval);
                    uart::putc(b'\n');
                    loop {}
                }
            }
        }
    }

    // Refresh trapframe SATP/ksp from current PCB before userret
    if let Some(procs) = crate::proc::scheduler::current_mut() {
        let pid = crate::proc::scheduler::current_pid();
        if let Some(p) = procs.iter().find(|p| p.pid == pid) {
            tf.user_satp   = p.user_satp;
            tf.kernel_satp = p.kernel_satp;
            tf.kernel_sp   = p.kstack_top;
        }
    }
}

fn print_hex(v: usize) {
    uart::puts("0x");
    for i in (0..16).rev() {
        let n = ((v >> (i * 4)) & 0xF) as u8;
        uart::putc(if n < 10 { b'0' + n } else { b'a' + n - 10 });
    }
}

pub fn install_kernel_page_table(satp: usize) {
    csr::write_satp(satp);
    csr::sfence_vma();
}
