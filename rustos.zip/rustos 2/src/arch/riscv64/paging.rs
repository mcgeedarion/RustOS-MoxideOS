//! RISC-V Sv39 page table entry helpers
pub const PAGE_SIZE:   usize = 4096;
pub const ENTRY_COUNT: usize = 512;

pub type PageTable = [u64; ENTRY_COUNT];

bitflags::bitflags! {
    pub struct PteFlags: u64 {
        const V = 1 << 0; // Valid
        const R = 1 << 1; // Readable
        const W = 1 << 2; // Writable
        const X = 1 << 3; // Executable
        const U = 1 << 4; // User-accessible
        const G = 1 << 5; // Global
        const A = 1 << 6; // Accessed
        const D = 1 << 7; // Dirty
    }
}

/// Build a leaf PTE from a physical page number and flags.
/// Bit[0] (Valid) is always set for leaf PTEs; use V in flags for non-leaf.
pub fn make_pte(ppn: usize, flags: PteFlags) -> u64 {
    ((ppn as u64) << 10) | flags.bits()
}

/// Extract the physical page number from a PTE.
pub fn pte_ppn(pte: u64) -> usize {
    ((pte >> 10) & 0x0FFF_FFFF_FFFF) as usize
}

/// True if the PTE is a leaf (R, W, or X bit set).
pub fn pte_is_leaf(pte: u64) -> bool {
    pte & 0b1110 != 0
}
