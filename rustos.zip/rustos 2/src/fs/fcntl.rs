//! fcntl(2), poll(2), select(2).

extern crate alloc;

// ── fcntl ─────────────────────────────────────────────────────────────────

pub const F_DUPFD:    usize = 0;
pub const F_GETFD:    usize = 1;
pub const F_SETFD:    usize = 2;
pub const F_GETFL:    usize = 3;
pub const F_SETFL:    usize = 4;
pub const F_GETLK:    usize = 5;
pub const F_SETLK:    usize = 6;
pub const F_SETLKW:   usize = 7;
pub const O_CLOEXEC:  usize = 0o2000000;
pub const O_NONBLOCK: usize = 0o4000;

pub fn fcntl(fd: usize, cmd: usize, arg: usize) -> isize {
    match cmd {
        F_GETFD => 0,                           // FD_CLOEXEC not set
        F_SETFD => 0,                           // ignore
        F_GETFL => {
            // Return O_RDWR for stdin/stdout/stderr, O_RDONLY for others
            if fd < 3 { 2 } else { 0 }
        }
        F_SETFL => 0,                           // ignore O_NONBLOCK etc.
        F_DUPFD => {
            // dup the fd starting at arg
            crate::fs::vfs::dup_from(fd, arg)
        }
        F_GETLK | F_SETLK | F_SETLKW => 0,     // advisory locks: always succeed
        _ => -22, // EINVAL
    }
}

// ── poll ──────────────────────────────────────────────────────────────────

/// Linux pollfd struct.
#[repr(C)]
pub struct PollFd { pub fd: i32, pub events: i16, pub revents: i16 }

pub const POLLIN:  i16 = 0x001;
pub const POLLOUT: i16 = 0x004;
pub const POLLERR: i16 = 0x008;
pub const POLLHUP: i16 = 0x010;

pub fn poll(fds_va: usize, nfds: usize, timeout_ms: i32) -> isize {
    if nfds == 0 { return 0; }
    if fds_va == 0 { return -14; }

    let fds = unsafe {
        core::slice::from_raw_parts_mut(fds_va as *mut PollFd, nfds)
    };

    let deadline = if timeout_ms < 0 {
        u64::MAX
    } else {
        crate::arch::x86_64::apic::ticks() + timeout_ms as u64 / 10
    };

    loop {
        let mut ready = 0i32;
        for pfd in fds.iter_mut() {
            pfd.revents = 0;
            if pfd.fd < 0 { continue; }
            let fd = pfd.fd as usize;
            // stdin: check TTY buffer
            if fd == 0 && (pfd.events & POLLIN != 0) {
                // Non-blocking: always report ready (simplified)
                pfd.revents |= POLLIN;
                ready += 1;
            }
            // stdout/stderr: always writable
            if (fd == 1 || fd == 2) && (pfd.events & POLLOUT != 0) {
                pfd.revents |= POLLOUT;
                ready += 1;
            }
            // Regular files: always ready
            if fd > 2 {
                if pfd.events & POLLIN  != 0 { pfd.revents |= POLLIN;  ready += 1; }
                if pfd.events & POLLOUT != 0 { pfd.revents |= POLLOUT; ready += 1; }
            }
        }
        if ready > 0 || crate::arch::x86_64::apic::ticks() >= deadline {
            return ready as isize;
        }
        crate::proc::scheduler::current_yield();
        crate::net::poll();
    }
}

// ── select ────────────────────────────────────────────────────────────────

pub fn select(nfds: usize, readfds: usize, writefds: usize,
              _exceptfds: usize, timeout: usize) -> isize
{
    // Convert fd_sets to pollfd array and call poll
    let mut pfds = alloc::vec::Vec::new();
    for i in 0..nfds.min(64) {
        let word = i / 64;
        let bit  = i % 64;
        let in_read  = readfds  != 0 && unsafe { *((readfds  + word*8) as *const u64) } & (1<<bit) != 0;
        let in_write = writefds != 0 && unsafe { *((writefds + word*8) as *const u64) } & (1<<bit) != 0;
        if in_read || in_write {
            let events = if in_read { POLLIN } else { 0 } | if in_write { POLLOUT } else { 0 };
            pfds.push(PollFd { fd: i as i32, events, revents: 0 });
        }
    }
    let timeout_ms: i32 = if timeout == 0 { 0 } else {
        let secs  = unsafe { *(timeout as *const u64) };
        let usecs = unsafe { *((timeout+8) as *const u64) };
        (secs * 1000 + usecs / 1000) as i32
    };
    let n = poll(pfds.as_mut_ptr() as usize, pfds.len(), timeout_ms);
    // Write back fd_sets
    if readfds != 0 {
        unsafe { *(readfds as *mut u64) = 0; }
        for p in &pfds { if p.revents & POLLIN != 0 {
            let i = p.fd as usize;
            unsafe { *((readfds + (i/64)*8) as *mut u64) |= 1u64 << (i%64); }
        }}
    }
    n
}
