//! Ext2 read-write filesystem driver.
//!
//! Revision 0 and revision 1 (dynamic inode sizes) are supported.
//! Block sizes of 1024, 2048 and 4096 bytes are supported.
//!
//! ## On-disk mutation model
//!
//! All mutations are applied to the in-memory copy (`Ext2Fs::data: Vec<u8>`).
//! After every write the affected blocks are marked dirty and flushed to the
//! VirtIO-blk device via `virtio_blk::write_sectors`.  This makes the disk
//! image durable across reboots.
//!
//! ## Allocation strategy
//!
//! Blocks and inodes are allocated by scanning the per-group bitmaps.
//! The first free bit is used (no attempt at locality yet).
//!
//! ## Concurrency
//!
//! All operations take the global `FS` mutex.  Fine-grained locking is left
//! as a future optimisation.

extern crate alloc;
use alloc::{string::String, vec::Vec};
use spin::Mutex;

// ── On-disk constants ─────────────────────────────────────────────────────

const EXT2_MAGIC:     u16   = 0xEF53;
const EXT2_SB_OFFSET: usize = 1024;
const ROOT_INO:       u32   = 2;
const LOST_FOUND_INO: u32   = 11; // first non-reserved inode

const S_IFMT:   u16 = 0xF000;
const S_IFREG:  u16 = 0x8000;
const S_IFDIR:  u16 = 0x4000;
const S_IFLNK:  u16 = 0xA000;

const EXT2_FT_UNKNOWN:  u8 = 0;
const EXT2_FT_REG_FILE: u8 = 1;
const EXT2_FT_DIR:      u8 = 2;
const EXT2_FT_SYMLINK:  u8 = 7;

// ── On-disk structures ────────────────────────────────────────────────────

#[repr(C)] #[derive(Copy, Clone)]
struct Superblock {
    s_inodes_count:        u32,  // 0
    s_blocks_count:        u32,  // 4
    s_r_blocks_count:      u32,  // 8
    s_free_blocks_count:   u32,  // 12
    s_free_inodes_count:   u32,  // 16
    s_first_data_block:    u32,  // 20
    s_log_block_size:      u32,  // 24  (block_size = 1024 << s_log)
    s_log_frag_size:       u32,  // 28
    s_blocks_per_group:    u32,  // 32
    s_frags_per_group:     u32,  // 36
    s_inodes_per_group:    u32,  // 40
    s_mtime:               u32,  // 44
    s_wtime:               u32,  // 48
    s_mnt_count:           u16,  // 52
    s_max_mnt_count:       u16,  // 54
    s_magic:               u16,  // 56
    s_state:               u16,  // 58
    s_errors:              u16,  // 60
    s_minor_rev_level:     u16,  // 62
    s_lastcheck:           u32,  // 64
    s_checkinterval:       u32,  // 68
    s_creator_os:          u32,  // 72
    s_rev_level:           u32,  // 76
    s_def_resuid:          u16,  // 80
    s_def_resgid:          u16,  // 82
    // Rev 1 extras
    s_first_ino:           u32,  // 84
    s_inode_size:          u16,  // 88
    s_block_group_nr:      u16,  // 90
    _rest:                 [u8; 934],
}

#[repr(C)] #[derive(Copy, Clone)]
struct BlockGroupDesc {
    bg_block_bitmap:      u32,
    bg_inode_bitmap:      u32,
    bg_inode_table:       u32,
    bg_free_blocks_count: u16,
    bg_free_inodes_count: u16,
    bg_used_dirs_count:   u16,
    _pad:                 [u8; 14],
}

#[repr(C)] #[derive(Copy, Clone, Default)]
struct Inode {
    i_mode:        u16,
    i_uid:         u16,
    i_size:        u32,
    i_atime:       u32,
    i_ctime:       u32,
    i_mtime:       u32,
    i_dtime:       u32,
    i_gid:         u16,
    i_links_count: u16,
    i_blocks:      u32,   // 512-byte units
    i_flags:       u32,
    _osd1:         u32,
    i_block:       [u32; 15],
    i_generation:  u32,
    i_file_acl:    u32,
    i_size_high:   u32,   // also i_dir_acl
    i_faddr:       u32,
    _osd2:         [u8; 12],
}

#[repr(C, packed)] #[derive(Copy, Clone)]
struct DirEntry2 {
    inode:     u32,
    rec_len:   u16,
    name_len:  u8,
    file_type: u8,
}

const DIRENT_HDR: usize = core::mem::size_of::<DirEntry2>();

// ── Driver state ──────────────────────────────────────────────────────────

pub struct Ext2Fs {
    pub data:          Vec<u8>,
    block_size:        usize,
    inode_size:        usize,
    inodes_per_group:  u32,
    blocks_per_group:  u32,
    bgdt_block:        u32,
    num_groups:        u32,
    first_ino:         u32,
    dirty_blocks:      Vec<u32>,
}

static FS: Mutex<Option<Ext2Fs>> = Mutex::new(None);

// ── Init / mount ─────────────────────────────────────────────────────────

pub fn init(data: Vec<u8>) -> bool {
    if data.len() < EXT2_SB_OFFSET + core::mem::size_of::<Superblock>() { return false; }
    let sb = read_sb(&data);
    if sb.s_magic != EXT2_MAGIC { return false; }
    let block_size       = 1024usize << sb.s_log_block_size;
    let inode_size       = if sb.s_rev_level >= 1 { sb.s_inode_size as usize } else { 128 };
    let bgdt_block       = if block_size == 1024 { 2u32 } else { 1u32 };
    let blocks_per_group = sb.s_blocks_per_group;
    let total_blocks     = sb.s_blocks_count;
    let num_groups       = (total_blocks + blocks_per_group - 1) / blocks_per_group;
    let first_ino        = if sb.s_rev_level >= 1 { sb.s_first_ino } else { 11 };
    *FS.lock() = Some(Ext2Fs {
        data, block_size, inode_size,
        inodes_per_group: sb.s_inodes_per_group,
        blocks_per_group,
        bgdt_block, num_groups, first_ino,
        dirty_blocks: Vec::new(),
    });
    true
}

pub fn is_mounted()   -> bool { FS.lock().is_some() }

// ── Public read API (unchanged) ───────────────────────────────────────────

pub fn read_file(path: &str) -> Option<Vec<u8>> {
    let mut g = FS.lock(); let fs = g.as_mut()?;
    let ino = fs.resolve(path)?; fs.read_inode_data(ino)
}

pub fn stat(path: &str) -> Option<u32> {
    let mut g = FS.lock(); let fs = g.as_mut()?; fs.resolve(path)
}

pub fn readdir(path: &str) -> Option<Vec<(String, u32)>> {
    let mut g = FS.lock(); let fs = g.as_mut()?;
    let ino = fs.resolve(path)?; fs.list_dir(ino)
}

pub fn read_file_by_ino(ino: u32) -> Option<Vec<u8>> {
    let mut g = FS.lock(); let fs = g.as_mut()?; fs.read_inode_data(ino)
}

pub fn file_size(ino: u32) -> Option<usize> {
    let mut g = FS.lock(); let fs = g.as_mut()?;
    let inode = fs.inode(ino);
    if inode.i_mode & S_IFMT == S_IFREG { Some(inode.i_size as usize) } else { None }
}

// ── Public WRITE API ──────────────────────────────────────────────────────

/// Create or overwrite a regular file. Returns inode number or 0 on error.
pub fn create_file(path: &str, data: &[u8]) -> u32 {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    // Split into parent dir + filename
    let (parent_path, name) = split_path(path);
    let parent_ino = match fs.resolve(parent_path) {
        Some(i) => i,
        None    => { drop(g); mkdir_p(parent_path); return create_file(path, data); }
    };
    // If file already exists, overwrite
    if let Some(existing) = fs.lookup_in_dir(parent_ino, name) {
        fs.write_inode_data(existing, data);
        fs.flush_to_disk();
        return existing;
    }
    // Allocate inode
    let ino = match fs.alloc_inode() { Some(i) => i, None => return 0 };
    let mut inode = Inode::default();
    inode.i_mode = S_IFREG | 0o644;
    inode.i_links_count = 1;
    inode.i_ctime = now();
    inode.i_mtime = now();
    inode.i_atime = now();
    fs.write_inode(ino, &inode);
    fs.write_inode_data(ino, data);
    fs.dir_add_entry(parent_ino, ino, name, EXT2_FT_REG_FILE);
    fs.update_sb_free(-1, 0);
    fs.flush_to_disk();
    ino
}

/// Write data to an existing file (truncate + rewrite).
pub fn write_file(path: &str, data: &[u8]) -> bool {
    create_file(path, data) != 0
}

/// Append data to an existing file.
pub fn append_file(path: &str, data: &[u8]) -> bool {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let ino = match fs.resolve(path) { Some(i) => i, None => { drop(g); return create_file(path, data) != 0; } };
    let mut existing = fs.read_inode_data(ino).unwrap_or_default();
    existing.extend_from_slice(data);
    fs.write_inode_data(ino, &existing);
    fs.flush_to_disk();
    true
}

/// Create a directory (and all parent components). Returns inode or 0.
pub fn mkdir_p(path: &str) -> u32 {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    if let Some(ino) = fs.resolve(path) { return ino; }
    drop(g);
    let (parent, name) = split_path(path);
    if !parent.is_empty() && parent != "/" { mkdir_p(parent); }
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let parent_ino = fs.resolve(if parent.is_empty() { "/" } else { parent }).unwrap_or(ROOT_INO);
    let ino = match fs.alloc_inode() { Some(i) => i, None => return 0 };
    let t = now();
    let mut inode = Inode::default();
    inode.i_mode = S_IFDIR | 0o755;
    inode.i_links_count = 2;
    inode.i_ctime = t; inode.i_mtime = t; inode.i_atime = t;
    fs.write_inode(ino, &inode);
    // Add . and .. entries
    fs.dir_add_entry(ino, ino, ".", EXT2_FT_DIR);
    fs.dir_add_entry(ino, parent_ino, "..", EXT2_FT_DIR);
    fs.dir_add_entry(parent_ino, ino, name, EXT2_FT_DIR);
    fs.flush_to_disk();
    ino
}

/// Unlink a file (decrement link count, free if 0).
pub fn unlink(path: &str) -> bool {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let (parent_path, name) = split_path(path);
    let parent_ino = match fs.resolve(parent_path) { Some(i) => i, None => return false };
    let file_ino   = match fs.lookup_in_dir(parent_ino, name)  { Some(i) => i, None => return false };
    fs.dir_remove_entry(parent_ino, name);
    let mut inode = fs.inode(file_ino);
    if inode.i_links_count > 1 {
        inode.i_links_count -= 1;
        fs.write_inode(file_ino, &inode);
    } else {
        // Free all data blocks
        fs.free_inode_blocks(file_ino);
        inode.i_dtime = now();
        inode.i_links_count = 0;
        fs.write_inode(file_ino, &inode);
        fs.free_inode_bitmap(file_ino);
        fs.update_sb_free(1, 1);
    }
    fs.flush_to_disk();
    true
}

/// Rename / move a file or directory.
pub fn rename(oldpath: &str, newpath: &str) -> bool {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let ino = match fs.resolve(oldpath) { Some(i) => i, None => return false };
    let (old_parent_p, old_name) = split_path(oldpath);
    let (new_parent_p, new_name) = split_path(newpath);
    let old_parent = match fs.resolve(old_parent_p) { Some(i) => i, None => return false };
    let new_parent = match fs.resolve(new_parent_p) { Some(i) => i, None => return false };
    // Remove from old dir, add to new dir
    fs.dir_remove_entry(old_parent, old_name);
    let ft = {
        let inode = fs.inode(ino);
        if inode.i_mode & S_IFMT == S_IFDIR { EXT2_FT_DIR } else { EXT2_FT_REG_FILE }
    };
    fs.dir_add_entry(new_parent, ino, new_name, ft);
    fs.flush_to_disk();
    true
}

/// Truncate a file to `length` bytes.
pub fn truncate(path: &str, length: usize) -> bool {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let ino = match fs.resolve(path) { Some(i) => i, None => return false };
    let mut data = fs.read_inode_data(ino).unwrap_or_default();
    data.resize(length, 0);
    fs.write_inode_data(ino, &data);
    fs.flush_to_disk();
    true
}

/// Create a symbolic link.
pub fn symlink(target: &str, linkpath: &str) -> bool {
    // Store target as file content; mark mode as S_IFLNK
    let ino = create_file(linkpath, target.as_bytes());
    if ino == 0 { return false; }
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let mut inode = fs.inode(ino);
    inode.i_mode = (inode.i_mode & !S_IFMT) | S_IFLNK;
    fs.write_inode(ino, &inode);
    fs.flush_to_disk();
    true
}

/// Read a symlink target.
pub fn readlink(path: &str) -> Option<String> {
    let mut g = FS.lock(); let fs = g.as_mut()?;
    let ino = fs.resolve(path)?;
    let inode = fs.inode(ino);
    if inode.i_mode & S_IFMT != S_IFLNK { return None; }
    let data = fs.read_inode_data(ino)?;
    Some(String::from_utf8_lossy(&data).into_owned())
}

/// Chmod — update inode mode bits.
pub fn chmod(path: &str, mode: u16) -> bool {
    let mut g = FS.lock(); let fs = g.as_mut().unwrap();
    let ino = match fs.resolve(path) { Some(i) => i, None => return false };
    let mut inode = fs.inode(ino);
    inode.i_mode = (inode.i_mode & S_IFMT) | (mode & !S_IFMT);
    fs.write_inode(ino, &inode);
    fs.flush_to_disk();
    true
}

/// Flush all dirty blocks to the VirtIO block device.
pub fn sync() {
    let mut g = FS.lock();
    if let Some(fs) = g.as_mut() { fs.flush_to_disk(); }
}

// ── Internal Ext2Fs methods ───────────────────────────────────────────────

impl Ext2Fs {
    // ── Block I/O helpers ─────────────────────────────────────────────────

    fn blk_off(&self, blk: u32) -> usize { blk as usize * self.block_size }

    fn blk_slice(&self, blk: u32) -> &[u8] {
        let o = self.blk_off(blk); &self.data[o..o+self.block_size]
    }

    fn blk_slice_mut(&mut self, blk: u32) -> &mut [u8] {
        let o = self.blk_off(blk);
        let bs = self.block_size;
        if !self.dirty_blocks.contains(&blk) { self.dirty_blocks.push(blk); }
        &mut self.data[o..o+bs]
    }

    fn read_u32(&self, blk: u32, off: usize) -> u32 {
        u32::from_le_bytes(self.blk_slice(blk)[off..off+4].try_into().unwrap())
    }

    fn write_u32(&mut self, blk: u32, off: usize, val: u32) {
        let b = self.blk_slice_mut(blk);
        b[off..off+4].copy_from_slice(&val.to_le_bytes());
    }

    // ── Superblock / BGDT ─────────────────────────────────────────────────

    fn sb(&self) -> Superblock {
        unsafe { core::ptr::read_unaligned(
            self.data.as_ptr().add(EXT2_SB_OFFSET) as *const Superblock) }
    }

    fn write_sb(&mut self, sb: &Superblock) {
        unsafe { core::ptr::copy_nonoverlapping(
            sb as *const Superblock as *const u8,
            self.data.as_mut_ptr().add(EXT2_SB_OFFSET),
            core::mem::size_of::<Superblock>()) };
        // Mark SB block dirty
        let sb_blk = if self.block_size == 1024 { 1u32 } else { 0u32 };
        if !self.dirty_blocks.contains(&sb_blk) { self.dirty_blocks.push(sb_blk); }
    }

    fn bgd(&self, group: u32) -> BlockGroupDesc {
        let off = self.blk_off(self.bgdt_block)
                + group as usize * core::mem::size_of::<BlockGroupDesc>();
        unsafe { core::ptr::read_unaligned(self.data.as_ptr().add(off) as *const BlockGroupDesc) }
    }

    fn write_bgd(&mut self, group: u32, bgd: &BlockGroupDesc) {
        let off = self.blk_off(self.bgdt_block)
                + group as usize * core::mem::size_of::<BlockGroupDesc>();
        unsafe { core::ptr::copy_nonoverlapping(
            bgd as *const BlockGroupDesc as *const u8,
            self.data.as_mut_ptr().add(off),
            core::mem::size_of::<BlockGroupDesc>()) };
        if !self.dirty_blocks.contains(&self.bgdt_block) {
            self.dirty_blocks.push(self.bgdt_block);
        }
    }

    fn update_sb_free(&mut self, blk_delta: i32, ino_delta: i32) {
        let mut sb = self.sb();
        sb.s_free_blocks_count = (sb.s_free_blocks_count as i32 + blk_delta).max(0) as u32;
        sb.s_free_inodes_count = (sb.s_free_inodes_count as i32 + ino_delta).max(0) as u32;
        self.write_sb(&sb);
    }

    // ── Inode read/write ──────────────────────────────────────────────────

    fn inode_offset(&self, ino: u32) -> usize {
        let ino0  = ino - 1;
        let group = ino0 / self.inodes_per_group;
        let idx   = ino0 % self.inodes_per_group;
        let bgd   = self.bgd(group);
        self.blk_off(bgd.bg_inode_table) + idx as usize * self.inode_size
    }

    fn inode(&self, ino: u32) -> Inode {
        let off = self.inode_offset(ino);
        unsafe { core::ptr::read_unaligned(self.data.as_ptr().add(off) as *const Inode) }
    }

    fn write_inode(&mut self, ino: u32, inode: &Inode) {
        let off = self.inode_offset(ino);
        let tbl_blk = (off / self.block_size) as u32;
        if !self.dirty_blocks.contains(&tbl_blk) { self.dirty_blocks.push(tbl_blk); }
        unsafe { core::ptr::copy_nonoverlapping(
            inode as *const Inode as *const u8,
            self.data.as_mut_ptr().add(off),
            core::mem::size_of::<Inode>()) };
    }

    // ── Block allocation ──────────────────────────────────────────────────

    fn alloc_block(&mut self) -> Option<u32> {
        for g in 0..self.num_groups {
            let bgd = self.bgd(g);
            if bgd.bg_free_blocks_count == 0 { continue; }
            let bitmap_blk = bgd.bg_block_bitmap;
            let bpg = self.blocks_per_group as usize;
            // Scan bitmap
            for byte_i in 0..((bpg + 7) / 8) {
                let off = self.blk_off(bitmap_blk) + byte_i;
                if off >= self.data.len() { break; }
                let byte = self.data[off];
                if byte == 0xFF { continue; }
                for bit in 0..8u32 {
                    if byte & (1 << bit) == 0 {
                        let blk_in_group = byte_i as u32 * 8 + bit;
                        if blk_in_group >= self.blocks_per_group { break; }
                        // Mark allocated
                        self.data[off] |= 1 << bit;
                        if !self.dirty_blocks.contains(&bitmap_blk) {
                            self.dirty_blocks.push(bitmap_blk);
                        }
                        let mut bgd2 = self.bgd(g);
                        bgd2.bg_free_blocks_count -= 1;
                        self.write_bgd(g, &bgd2);
                        let abs_blk = g * self.blocks_per_group + blk_in_group;
                        // Zero the new block
                        let bo = self.blk_off(abs_blk);
                        self.data[bo..bo+self.block_size].fill(0);
                        if !self.dirty_blocks.contains(&abs_blk) { self.dirty_blocks.push(abs_blk); }
                        self.update_sb_free(-1, 0);
                        return Some(abs_blk);
                    }
                }
            }
        }
        None
    }

    fn free_block(&mut self, blk: u32) {
        let g = blk / self.blocks_per_group;
        let bit = (blk % self.blocks_per_group) as usize;
        let bgd = self.bgd(g);
        let bitmap_blk = bgd.bg_block_bitmap;
        let off = self.blk_off(bitmap_blk) + bit / 8;
        self.data[off] &= !(1 << (bit % 8));
        if !self.dirty_blocks.contains(&bitmap_blk) { self.dirty_blocks.push(bitmap_blk); }
        let mut bgd2 = self.bgd(g);
        bgd2.bg_free_blocks_count += 1;
        self.write_bgd(g, &bgd2);
        self.update_sb_free(1, 0);
    }

    // ── Inode allocation ──────────────────────────────────────────────────

    fn alloc_inode(&mut self) -> Option<u32> {
        for g in 0..self.num_groups {
            let bgd = self.bgd(g);
            if bgd.bg_free_inodes_count == 0 { continue; }
            let bitmap_blk = bgd.bg_inode_bitmap;
            let ipg = self.inodes_per_group as usize;
            for byte_i in 0..((ipg + 7) / 8) {
                let off = self.blk_off(bitmap_blk) + byte_i;
                if off >= self.data.len() { break; }
                let byte = self.data[off];
                if byte == 0xFF { continue; }
                for bit in 0..8u32 {
                    if byte & (1 << bit) == 0 {
                        let ino_in_group = byte_i as u32 * 8 + bit;
                        if ino_in_group >= self.inodes_per_group { break; }
                        let ino = g * self.inodes_per_group + ino_in_group + 1;
                        if ino < self.first_ino { continue; } // skip reserved
                        self.data[off] |= 1 << bit;
                        if !self.dirty_blocks.contains(&bitmap_blk) { self.dirty_blocks.push(bitmap_blk); }
                        let mut bgd2 = self.bgd(g);
                        bgd2.bg_free_inodes_count -= 1;
                        self.write_bgd(g, &bgd2);
                        self.update_sb_free(0, -1);
                        return Some(ino);
                    }
                }
            }
        }
        None
    }

    fn free_inode_bitmap(&mut self, ino: u32) {
        let ino0 = ino - 1;
        let g    = ino0 / self.inodes_per_group;
        let bit  = (ino0 % self.inodes_per_group) as usize;
        let bgd  = self.bgd(g);
        let bitmap_blk = bgd.bg_inode_bitmap;
        let off = self.blk_off(bitmap_blk) + bit / 8;
        self.data[off] &= !(1 << (bit % 8));
        if !self.dirty_blocks.contains(&bitmap_blk) { self.dirty_blocks.push(bitmap_blk); }
        let mut bgd2 = self.bgd(g);
        bgd2.bg_free_inodes_count += 1;
        self.write_bgd(g, &bgd2);
    }

    // ── Block mapping (logical → physical) ───────────────────────────────

    fn inode_block(&self, inode: &Inode, n: usize) -> Option<u32> {
        let bpi = self.block_size / 4;
        if n < 12 {
            let b = inode.i_block[n]; if b == 0 { None } else { Some(b) }
        } else if n < 12 + bpi {
            let ind = inode.i_block[12]; if ind == 0 { return None; }
            let b = self.read_u32(ind, (n - 12) * 4);
            if b == 0 { None } else { Some(b) }
        } else if n < 12 + bpi + bpi*bpi {
            let dind = inode.i_block[13]; if dind == 0 { return None; }
            let n2 = n - 12 - bpi;
            let b  = self.read_u32(dind, (n2 / bpi) * 4);
            if b == 0 { return None; }
            let b2 = self.read_u32(b, (n2 % bpi) * 4);
            if b2 == 0 { None } else { Some(b2) }
        } else { None }
    }

    fn set_inode_block(&mut self, inode: &mut Inode, n: usize, blk: u32) {
        let bpi = self.block_size / 4;
        if n < 12 {
            inode.i_block[n] = blk;
        } else if n < 12 + bpi {
            if inode.i_block[12] == 0 {
                let ib = self.alloc_block().expect("no block for indirect");
                inode.i_block[12] = ib;
            }
            let ind = inode.i_block[12];
            self.write_u32(ind, (n - 12) * 4, blk);
        } else {
            let n2 = n - 12 - bpi;
            if inode.i_block[13] == 0 {
                let db = self.alloc_block().expect("no block for dbl-indirect");
                inode.i_block[13] = db;
            }
            let dind = inode.i_block[13];
            let outer_off = (n2 / bpi) * 4;
            let mut ind_blk = self.read_u32(dind, outer_off);
            if ind_blk == 0 {
                ind_blk = self.alloc_block().expect("no block for indirect2");
                self.write_u32(dind, outer_off, ind_blk);
            }
            self.write_u32(ind_blk, (n2 % bpi) * 4, blk);
        }
    }

    // ── Inode data read/write ─────────────────────────────────────────────

    fn read_inode_data(&mut self, ino: u32) -> Option<Vec<u8>> {
        let inode = self.inode(ino);
        if inode.i_mode & S_IFMT != S_IFREG &&
           inode.i_mode & S_IFMT != S_IFLNK &&
           inode.i_mode & S_IFMT != S_IFDIR  { return None; }
        let size = inode.i_size as usize;
        let mut out = Vec::with_capacity(size);
        let mut rem = size;
        let mut bi  = 0usize;
        while rem > 0 {
            let phys  = self.inode_block(&inode, bi)?;
            let chunk = rem.min(self.block_size);
            out.extend_from_slice(&self.blk_slice(phys)[..chunk]);
            rem -= chunk; bi += 1;
        }
        Some(out)
    }

    fn write_inode_data(&mut self, ino: u32, data: &[u8]) {
        let mut inode = self.inode(ino);
        let new_size = data.len();
        // Free any extra blocks if shrinking
        let old_blocks = (inode.i_size as usize + self.block_size - 1) / self.block_size;
        let new_blocks = (new_size              + self.block_size - 1) / self.block_size;
        if old_blocks > new_blocks {
            for bi in new_blocks..old_blocks {
                if let Some(blk) = self.inode_block(&inode, bi) {
                    self.free_block(blk);
                    self.set_inode_block(&mut inode, bi, 0);
                }
            }
        }
        // Write data
        let mut written = 0usize;
        let mut bi = 0usize;
        while written < new_size {
            let blk = if let Some(b) = self.inode_block(&inode, bi) { b }
                      else { let b = self.alloc_block().expect("OOM"); self.set_inode_block(&mut inode, bi, b); b };
            let chunk = (new_size - written).min(self.block_size);
            let blk_data = self.blk_slice_mut(blk);
            blk_data[..chunk].copy_from_slice(&data[written..written+chunk]);
            if chunk < self.block_size { blk_data[chunk..].fill(0); }
            written += chunk; bi += 1;
        }
        inode.i_size   = new_size as u32;
        inode.i_blocks = ((new_blocks * self.block_size + 511) / 512) as u32;
        inode.i_mtime  = now();
        self.write_inode(ino, &inode);
    }

    fn free_inode_blocks(&mut self, ino: u32) {
        let inode = self.inode(ino);
        let blocks = (inode.i_size as usize + self.block_size - 1) / self.block_size;
        for bi in 0..blocks {
            if let Some(blk) = self.inode_block(&inode, bi) { self.free_block(blk); }
        }
    }

    // ── Directory operations ──────────────────────────────────────────────

    fn list_dir(&mut self, ino: u32) -> Option<Vec<(String, u32)>> {
        let inode = self.inode(ino);
        if inode.i_mode & S_IFMT != S_IFDIR { return None; }
        let data = self.read_inode_data(ino)?;
        let mut out = Vec::new();
        let mut pos = 0usize;
        while pos + DIRENT_HDR <= data.len() {
            let de: DirEntry2 = unsafe { core::ptr::read_unaligned(data.as_ptr().add(pos) as *const DirEntry2) };
            if de.rec_len == 0 { break; }
            if de.inode != 0 {
                let ne = pos + DIRENT_HDR;
                let nn = ne + de.name_len as usize;
                if nn <= data.len() {
                    let name = core::str::from_utf8(&data[ne..nn]).unwrap_or("?");
                    out.push((String::from(name), de.inode));
                }
            }
            pos += de.rec_len as usize;
        }
        Some(out)
    }

    fn lookup_in_dir(&mut self, dir_ino: u32, name: &str) -> Option<u32> {
        self.list_dir(dir_ino)?
            .into_iter().find(|(n, _)| n == name).map(|(_, i)| i)
    }

    fn dir_add_entry(&mut self, dir_ino: u32, ino: u32, name: &str, ft: u8) {
        let name_b = name.as_bytes();
        let name_len = name_b.len() as u8;
        let needed = (DIRENT_HDR + name_len as usize + 3) & !3;

        let mut dir_data = self.read_inode_data(dir_ino).unwrap_or_default();
        // Find a gap or append
        let mut pos = 0usize;
        let mut inserted = false;
        while pos + DIRENT_HDR <= dir_data.len() {
            let de: DirEntry2 = unsafe { core::ptr::read_unaligned(dir_data.as_ptr().add(pos) as *const DirEntry2) };
            if de.rec_len == 0 { break; }
            let real_len = (DIRENT_HDR + de.name_len as usize + 3) & !3;
            let avail    = de.rec_len as usize - real_len;
            if de.inode == 0 && de.rec_len as usize >= needed {
                // Reuse deleted entry
                let new_de = DirEntry2 { inode: ino, rec_len: de.rec_len, name_len, file_type: ft };
                unsafe { core::ptr::copy_nonoverlapping(&new_de as *const DirEntry2 as *const u8,
                    dir_data.as_mut_ptr().add(pos), DIRENT_HDR) };
                dir_data[pos+DIRENT_HDR..pos+DIRENT_HDR+name_len as usize].copy_from_slice(name_b);
                inserted = true; break;
            } else if avail >= needed {
                // Split existing entry
                let new_rec_len = (de.rec_len as usize - avail) as u16;
                let split_off   = pos + real_len;
                let split_rec_len = avail as u16;
                // Update existing entry's rec_len
                unsafe { let p = dir_data.as_mut_ptr().add(pos + 4) as *mut u16; *p = new_rec_len; }
                let new_de = DirEntry2 { inode: ino, rec_len: split_rec_len, name_len, file_type: ft };
                unsafe { core::ptr::copy_nonoverlapping(&new_de as *const DirEntry2 as *const u8,
                    dir_data.as_mut_ptr().add(split_off), DIRENT_HDR) };
                if split_off + DIRENT_HDR + name_len as usize <= dir_data.len() {
                    dir_data[split_off+DIRENT_HDR..split_off+DIRENT_HDR+name_len as usize]
                        .copy_from_slice(name_b);
                }
                inserted = true; break;
            }
            pos += de.rec_len as usize;
        }
        if !inserted {
            // Append a new block's worth of directory data
            let rec_len = self.block_size as u16;
            let mut entry = Vec::with_capacity(self.block_size);
            let de = DirEntry2 { inode: ino, rec_len, name_len, file_type: ft };
            let de_bytes = unsafe { core::slice::from_raw_parts(&de as *const DirEntry2 as *const u8, DIRENT_HDR) };
            entry.extend_from_slice(de_bytes);
            entry.extend_from_slice(name_b);
            entry.resize(self.block_size, 0);
            dir_data.extend_from_slice(&entry);
        }
        self.write_inode_data(dir_ino, &dir_data);
    }

    fn dir_remove_entry(&mut self, dir_ino: u32, name: &str) {
        let mut dir_data = match self.read_inode_data(dir_ino) { Some(d) => d, None => return };
        let mut pos = 0usize;
        while pos + DIRENT_HDR <= dir_data.len() {
            let de: DirEntry2 = unsafe { core::ptr::read_unaligned(dir_data.as_ptr().add(pos) as *const DirEntry2) };
            if de.rec_len == 0 { break; }
            if de.inode != 0 && de.name_len as usize == name.len() {
                let ne = pos + DIRENT_HDR;
                let nn = ne + de.name_len as usize;
                if nn <= dir_data.len() && &dir_data[ne..nn] == name.as_bytes() {
                    // Mark inode = 0 (free entry)
                    unsafe { let p = dir_data.as_mut_ptr().add(pos) as *mut u32; *p = 0; }
                    break;
                }
            }
            pos += de.rec_len as usize;
        }
        self.write_inode_data(dir_ino, &dir_data);
    }

    // ── Path resolution ───────────────────────────────────────────────────

    pub fn resolve(&mut self, path: &str) -> Option<u32> {
        let mut ino = ROOT_INO;
        let stripped = path.strip_prefix('/').unwrap_or(path);
        if stripped.is_empty() { return Some(ino); }
        for component in stripped.split('/') {
            if component.is_empty() || component == "." { continue; }
            if component == ".." {
                if let Some(p) = self.lookup_in_dir(ino, "..") { ino = p; }
                continue;
            }
            let entries = self.list_dir(ino)?;
            ino = entries.iter().find(|(n, _)| n == component)?.1;
            // Follow symlink
            let inode = self.inode(ino);
            if inode.i_mode & S_IFMT == S_IFLNK {
                let target = self.read_inode_data(ino)?;
                let target_str = core::str::from_utf8(&target).ok()?;
                // Only handle absolute symlinks for now
                if target_str.starts_with('/') {
                    ino = self.resolve(target_str)?;
                }
            }
        }
        Some(ino)
    }

    // ── VirtIO-blk flush ──────────────────────────────────────────────────

    fn flush_to_disk(&mut self) {
        if self.dirty_blocks.is_empty() { return; }
        let dirty: Vec<u32> = self.dirty_blocks.drain(..).collect();
        for blk in dirty {
            let byte_off = blk as usize * self.block_size;
            let sectors  = self.block_size / 512;
            let lba      = byte_off / 512;
            if byte_off + self.block_size > self.data.len() { continue; }
            crate::drivers::virtio_blk::write_sectors(
                lba as u64,
                &self.data[byte_off .. byte_off + self.block_size],
            );
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────

fn read_sb(data: &[u8]) -> Superblock {
    unsafe { core::ptr::read_unaligned(
        data.as_ptr().add(EXT2_SB_OFFSET) as *const Superblock) }
}

fn split_path(path: &str) -> (&str, &str) {
    let path = path.trim_end_matches('/');
    match path.rfind('/') {
        Some(0) => ("/", &path[1..]),
        Some(i) => (&path[..i], &path[i+1..]),
        None    => ("", path),
    }
}

fn now() -> u32 {
    (crate::arch::x86_64::apic::ticks() / 100) as u32
}
