//! FAT32 filesystem driver stub
pub fn init(_data: &[u8]) -> bool { false }
