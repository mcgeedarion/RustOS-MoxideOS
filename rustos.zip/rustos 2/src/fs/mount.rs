//! Filesystem mount logic.
//!
//! Called from `kernel_main` after VirtIO block is initialised.
//! Reads the first 128 MiB from the block device into a heap buffer and
//! hands it to the ext2 driver.  Falls back gracefully if no block device.

extern crate alloc;
use alloc::vec::Vec;

const MAX_FS_SIZE: usize = 128 * 1024 * 1024; // 128 MiB
const SECTOR_SIZE: usize = 512;

pub fn mount_root() {
    #[cfg(target_arch = "x86_64")]
    {
        // Try to read ext2 from virtio-blk sector 0
        // Read superblock first to check magic + get image size
        let mut sb_buf = alloc::vec![0u8; 2048];
        match crate::drivers::virtio_blk::read_sectors(0, &mut sb_buf) {
            Err(e) => {
                crate::serial_println!("[mount] virtio-blk read failed: {} — ramfs only", e);
                return;
            }
            Ok(()) => {}
        }

        // Check ext2 magic at offset 1024+56
        let magic = u16::from_le_bytes([sb_buf[1080], sb_buf[1081]]);
        if magic != 0xEF53 {
            crate::serial_println!("[mount] disk not ext2 (magic={:#06x}) — ramfs only", magic);
            return;
        }

        // Determine filesystem size from superblock: blocks_count * block_size
        let log_bs = u32::from_le_bytes(sb_buf[1040..1044].try_into().unwrap_or([0;4]));
        let blkcnt = u32::from_le_bytes(sb_buf[1028..1032].try_into().unwrap_or([0;4]));
        let blksz  = 1024usize << log_bs;
        let fs_bytes = (blkcnt as usize * blksz).min(MAX_FS_SIZE);
        let sectors  = (fs_bytes + SECTOR_SIZE - 1) / SECTOR_SIZE;

        crate::serial_println!(
            "[mount] ext2: {} blocks × {} B = {} MiB ({} sectors)",
            blkcnt, blksz, fs_bytes >> 20, sectors,
        );

        let mut buf = alloc::vec![0u8; sectors * SECTOR_SIZE];
        // Copy already-read first 2048 bytes
        buf[..2048].copy_from_slice(&sb_buf);

        // Read the rest in 64-KiB chunks (128 sectors at a time)
        let chunk_secs = 128usize;
        let mut sec = 4usize; // already have sectors 0..3
        while sec < sectors {
            let count = chunk_secs.min(sectors - sec);
            let slice = &mut buf[sec * SECTOR_SIZE .. (sec + count) * SECTOR_SIZE];
            if crate::drivers::virtio_blk::read_sectors(sec as u64, slice).is_err() {
                crate::serial_println!("[mount] read error at sector {} — partial mount", sec);
                break;
            }
            sec += count;
        }

        buf.truncate(fs_bytes);

        if crate::fs::ext2::init(buf) {
            crate::serial_println!("[mount] ext2 mounted (read-only)");
        } else {
            crate::serial_println!("[mount] ext2::init failed — ramfs only");
        }
    }

    #[cfg(target_arch = "riscv64")]
    {
        // RISC-V: no VirtIO PCI — use MMIO path (stub)
        crate::drivers::uart::puts("[mount] RISC-V: ramfs only\n");
    }
}
