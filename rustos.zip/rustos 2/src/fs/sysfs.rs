//! /sys virtual filesystem (sysfs subset).
//!
//! Exposes PCI bus topology and network interface info for tools like
//! `lspci`, `ip`, and `ifconfig` that read sysfs entries.

extern crate alloc;
use alloc::vec::Vec;
use alloc::format;

fn s(v: &mut Vec<u8>, t: &str) { v.extend_from_slice(t.as_bytes()); }

// ── /sys/bus/pci/devices/<domain:bus:dev.fn>/uevent ───────────────────────

fn gen_pci_uevent(vendor: u16, device: u16, class: u32) -> Vec<u8> {
    let mut out = Vec::new();
    s(&mut out, &format!("DRIVER=virtio\nPCI_ID={:04X}:{:04X}\nPCI_SUBSYS_ID=0000:0000\nPCI_CLASS={:06X}\n",
        vendor, device, class));
    out
}

// ── /sys/class/net/<iface>/... ────────────────────────────────────────────

fn gen_net_iface(name: &str) -> Vec<u8> {
    let mut out = Vec::new();
    s(&mut out, &format!("INTERFACE={name}\nIFINDEX=2\n"));
    out
}

fn gen_net_addr() -> Vec<u8> {
    let mac = crate::net::MAC_ADDR;
    let mut out = Vec::new();
    s(&mut out, &format!("{:02x}:{:02x}:{:02x}:{:02x}:{:02x}:{:02x}\n",
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]));
    out
}

fn gen_net_mtu() -> Vec<u8> { b"1500\n".to_vec() }
fn gen_net_operstate() -> Vec<u8> { b"up\n".to_vec() }
fn gen_net_flags() -> Vec<u8> { b"0x1003\n".to_vec() } // IFF_UP|IFF_BROADCAST|IFF_MULTICAST

// ── /sys/kernel/... ───────────────────────────────────────────────────────

fn gen_hostname() -> Vec<u8> { b"rustos\n".to_vec() }
fn gen_ostype()   -> Vec<u8> { b"Linux\n".to_vec() }
fn gen_osrelease() -> Vec<u8> { b"6.1.0-rustos\n".to_vec() }

// ── Directory listings ────────────────────────────────────────────────────

fn dir(entries: &[&str]) -> Vec<u8> {
    let mut out = Vec::new();
    for e in entries { out.extend_from_slice(e.as_bytes()); out.push(b'\n'); }
    out
}

// ── Public API ────────────────────────────────────────────────────────────

pub fn is_sys_path(path: &str) -> bool {
    path == "/sys" || path.starts_with("/sys/")
}

pub fn read(path: &str) -> Option<Vec<u8>> {
    match path {
        "/sys" | "/sys/" => Some(dir(&["bus","class","devices","kernel","power"])),
        "/sys/bus"       => Some(dir(&["pci","platform","virtio"])),
        "/sys/bus/pci"   => Some(dir(&["devices","drivers"])),
        "/sys/bus/pci/devices" =>
            Some(dir(&["0000:00:01.0","0000:00:02.0","0000:00:03.0","0000:00:04.0"])),
        "/sys/bus/pci/devices/0000:00:01.0/uevent" => Some(gen_pci_uevent(0x8086,0x7000,0x060100)),
        "/sys/bus/pci/devices/0000:00:02.0/uevent" => Some(gen_pci_uevent(0x1AF4,0x1001,0x010000)),
        "/sys/bus/pci/devices/0000:00:03.0/uevent" => Some(gen_pci_uevent(0x1AF4,0x1000,0x020000)),
        "/sys/bus/pci/devices/0000:00:04.0/uevent" => Some(gen_pci_uevent(0x1AF4,0x1050,0x030000)),
        "/sys/class"     => Some(dir(&["net","block","tty","mem"])),
        "/sys/class/net" => Some(dir(&["lo","eth0"])),
        "/sys/class/net/eth0" | "/sys/class/net/eth0/" => Some(gen_net_iface("eth0")),
        "/sys/class/net/eth0/address"   => Some(gen_net_addr()),
        "/sys/class/net/eth0/mtu"       => Some(gen_net_mtu()),
        "/sys/class/net/eth0/operstate" => Some(gen_net_operstate()),
        "/sys/class/net/eth0/flags"     => Some(gen_net_flags()),
        "/sys/class/net/lo/address"     => Some(b"00:00:00:00:00:00\n".to_vec()),
        "/sys/class/net/lo/mtu"         => Some(b"65536\n".to_vec()),
        "/sys/class/net/lo/operstate"   => Some(b"unknown\n".to_vec()),
        "/sys/kernel"                   => Some(dir(&["hostname","ostype","osrelease"])),
        "/sys/kernel/hostname"          => Some(gen_hostname()),
        "/sys/kernel/ostype"            => Some(gen_ostype()),
        "/sys/kernel/osrelease"         => Some(gen_osrelease()),
        _ => None,
    }
}
