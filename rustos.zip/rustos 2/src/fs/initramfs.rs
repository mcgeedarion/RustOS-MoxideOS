//! CPIO newc initramfs parser.
//!
//! The kernel embeds a minimal initramfs CPIO archive (newc format) that
//! contains at minimum `/init`. The archive is compiled by
//! `tools/mkinitramfs.sh` and linked as a raw binary section, then
//! referenced via `include_bytes!` here.
//!
//! For builds where no external CPIO is available, the module falls back to
//! a built-in stub that registers a synthetic `/init` ELF directly.
use crate::fs::vfs;

const NEWC_MAGIC_CRC:   &[u8; 6] = b"070702";
const NEWC_MAGIC_NOCRC: &[u8; 6] = b"070701";
const HDR_LEN: usize = 110;

fn parse_hex8(src: &[u8]) -> usize {
    let mut v: usize = 0;
    for &b in &src[..8] {
        v <<= 4;
        v |= match b {
            b'0'..=b'9' => (b - b'0') as usize,
            b'a'..=b'f' => (b - b'a' + 10) as usize,
            b'A'..=b'F' => (b - b'A' + 10) as usize,
            _ => 0,
        };
    }
    v
}

/// Parse a CPIO newc archive and register its files in the VFS.
pub fn load(data: &[u8]) {
    let mut pos: usize = 0;
    loop {
        if pos + HDR_LEN > data.len() { break; }
        let magic = &data[pos..pos + 6];
        if magic != NEWC_MAGIC_NOCRC && magic != NEWC_MAGIC_CRC { break; }

        let namesize = parse_hex8(&data[pos + 94..pos + 102]);
        let filesize = parse_hex8(&data[pos + 54..pos + 62]);

        let name_start = pos + HDR_LEN;
        let name_end   = name_start + namesize;
        if name_end > data.len() { break; }

        let name_bytes = &data[name_start..name_end.saturating_sub(1)];
        let name = match core::str::from_utf8(name_bytes) {
            Ok(s) => s,
            Err(_) => { break; }
        };

        if name == "TRAILER!!!" { break; }

        let data_start = (name_end + 3) & !3;
        let data_end   = data_start + filesize;
        if data_end > data.len() { break; }

        if filesize > 0 {
            vfs::create_file(name, &data[data_start..data_end]);
        }

        pos = (data_end + 3) & !3;
    }
}

/// Minimal ELF64 for RISC-V that runs `ecall` with a7=64 (write), then
/// a7=93 (exit). Produces "Hello from /init\n" on UART via sys_write.
/// Generated with:
///   echo -ne '\x7fELF\x02\x01\x01...' > /init.elf
/// Embedded here as a compile-time constant so the kernel always has
/// something to exec even without an external CPIO image.
///
/// Layout (hand-assembled rv64 ELF):
///   e_entry = 0x1000_0078  (after ELF + phdrs)
///   PT_LOAD: vaddr=0x1000_0000, filesz=covers header+code
///
/// Code:
///   li a0, 1           # fd = stdout
///   la a1, msg         # buf
///   li a2, 17          # len
///   li a7, 64          # SYS_WRITE
///   ecall
///   li a0, 0
///   li a7, 93          # SYS_EXIT
///   ecall
pub static INIT_ELF: &[u8] = &[
    // ELF64 header (64 bytes)
    0x7f, 0x45, 0x4c, 0x46,  // magic
    0x02,                    // EI_CLASS = ELFCLASS64
    0x01,                    // EI_DATA  = ELFDATA2LSB
    0x01,                    // EI_VERSION
    0x00,                    // EI_OSABI
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // padding
    0x02,0x00,               // e_type = ET_EXEC
    0xf3,0x00,               // e_machine = EM_RISCV
    0x01,0x00,0x00,0x00,     // e_version
    // e_entry = 0x0000_0001_0000_0078 (code starts at offset 0x78 in PT_LOAD)
    0x78,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
    // e_phoff = 64 (immediately after ELF header)
    0x40,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    // e_shoff = 0
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,     // e_flags
    0x40,0x00,               // e_ehsize = 64
    0x38,0x00,               // e_phentsize = 56
    0x01,0x00,               // e_phnum = 1
    0x40,0x00,               // e_shentsize
    0x00,0x00,               // e_shnum
    0x00,0x00,               // e_shstrndx

    // Program header (56 bytes, offset 64)
    0x01,0x00,0x00,0x00,     // p_type = PT_LOAD
    0x05,0x00,0x00,0x00,     // p_flags = PF_R|PF_X
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, // p_offset = 0
    // p_vaddr = 0x0000_0001_0000_0000
    0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
    // p_paddr = same
    0x00,0x00,0x00,0x00,0x01,0x00,0x00,0x00,
    // p_filesz = 0x98 (152 bytes: header + phdr + code + msg)
    0x98,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    // p_memsz = same
    0x98,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    // p_align = 0x1000
    0x00,0x10,0x00,0x00,0x00,0x00,0x00,0x00,

    // Code (offset 0x78 = 120 dec): rv64 instructions (little-endian 32-bit)
    // li a0, 1       (addi a0, zero, 1)
    0x13,0x05,0x10,0x00,
    // la a1, msg     (auipc a1, 0; addi a1, a1, 20)
    0x97,0x05,0x00,0x00,  // auipc a1, 0
    0x93,0x85,0x45,0x01,  // addi a1, a1, 20  => points to msg 20 bytes ahead
    // li a2, 17
    0x13,0x06,0x11,0x01,
    // li a7, 64
    0x93,0x08,0x04,0x04,
    // ecall
    0x73,0x00,0x00,0x00,
    // li a0, 0
    0x13,0x05,0x00,0x00,
    // li a7, 93
    0x93,0x08,0xd0,0x05,
    // ecall
    0x73,0x00,0x00,0x00,

    // msg: "Hello from /init\n" (17 bytes, offset 0x90)
    b'H',b'e',b'l',b'l',b'o',b' ',
    b'f',b'r',b'o',b'm',b' ',
    b'/',b'i',b'n',b'i',b't',b'\n',
];
