//! /dev virtual filesystem.
//!
//! Character devices are served entirely in kernel memory — no on-disk
//! representation.  The VFS `open()` function checks `is_dev_path(path)`
//! and dispatches here before trying ext2 or ramfs.
//!
//! Each opened device gets its own `DevFd` backed by a tag enum so that
//! `read`/`write` can dispatch to the correct handler.

extern crate alloc;
use alloc::vec::Vec;
use spin::Mutex;
use core::sync::atomic::{AtomicU64, Ordering};

// ── PRNG (xorshift64) ─────────────────────────────────────────────────────

static PRNG_STATE: AtomicU64 = AtomicU64::new(0xDEAD_BEEF_CAFE_1234);

fn prng_next() -> u64 {
    // Marsaglia xorshift64
    let mut x = PRNG_STATE.load(Ordering::Relaxed);
    x ^= x << 13; x ^= x >> 7; x ^= x << 17;
    // Mix in APIC tick for entropy
    x ^= crate::arch::x86_64::apic::ticks();
    PRNG_STATE.store(x, Ordering::Relaxed);
    x
}

pub fn seed_prng(entropy: u64) {
    PRNG_STATE.fetch_xor(entropy, Ordering::Relaxed);
}

// ── PTY subsystem ─────────────────────────────────────────────────────────

const MAX_PTYS: usize = 16;
const PTY_BUF: usize  = 4096;

struct Pty {
    // master → slave (data written to master appears on slave's stdin)
    m2s: [u8; PTY_BUF], m2s_len: usize,
    // slave → master (data written by slave process appears on master read)
    s2m: [u8; PTY_BUF], s2m_len: usize,
    open: bool,
}

impl Pty {
    const fn new() -> Self { Self { m2s:[0;PTY_BUF],m2s_len:0, s2m:[0;PTY_BUF],s2m_len:0, open:false } }
}

static PTYS: Mutex<[Pty; MAX_PTYS]> = Mutex::new([const { Pty::new() }; MAX_PTYS]);

fn pty_alloc() -> Option<usize> {
    let mut p = PTYS.lock();
    for i in 0..MAX_PTYS { if !p[i].open { p[i].open = true; return Some(i); } }
    None
}

// ── Device tag ────────────────────────────────────────────────────────────

#[derive(Clone, Copy, PartialEq)]
pub enum DevTag {
    Null, Zero, Full, Urandom, Tty,
    PtyMaster(usize), PtySlave(usize),
    Mem,
}

// ── Global dev-fd table ───────────────────────────────────────────────────

#[derive(Clone)]
pub struct DevFd { pub tag: DevTag, pub pos: usize }

const MAX_DEV_FDS: usize = 32;
static DEV_FDS: Mutex<[Option<DevFd>; MAX_DEV_FDS]> = Mutex::new([const { None }; MAX_DEV_FDS]);

fn alloc_dev_fd(fd: DevFd) -> Option<usize> {
    // We store dev fds in a separate table and hand back indices in the
    // range 1000..1031 so they don't collide with VFS fds (0..63).
    let mut tbl = DEV_FDS.lock();
    for i in 0..MAX_DEV_FDS {
        if tbl[i].is_none() { tbl[i] = Some(fd); return Some(1000 + i); }
    }
    None
}

pub fn get_dev_fd(fdno: usize) -> Option<DevFd> {
    if fdno < 1000 || fdno >= 1000 + MAX_DEV_FDS { return None; }
    DEV_FDS.lock()[fdno - 1000].clone()
}

pub fn close_dev_fd(fdno: usize) -> bool {
    if fdno < 1000 || fdno >= 1000 + MAX_DEV_FDS { return false; }
    let slot = fdno - 1000;
    let mut tbl = DEV_FDS.lock();
    if let Some(ref fd) = tbl[slot] {
        if let DevTag::PtyMaster(n) | DevTag::PtySlave(n) = fd.tag {
            PTYS.lock()[n].open = false;
        }
    }
    tbl[slot] = None;
    true
}

// ── open ─────────────────────────────────────────────────────────────────

pub fn open(path: &str) -> Option<usize> {
    let tag = match path {
        "/dev/null"    => DevTag::Null,
        "/dev/zero"    => DevTag::Zero,
        "/dev/full"    => DevTag::Full,
        "/dev/urandom" | "/dev/random" => DevTag::Urandom,
        "/dev/tty" | "/dev/stdin" | "/dev/stdout" | "/dev/stderr" => DevTag::Tty,
        "/dev/mem"     => DevTag::Mem,
        "/dev/ptmx"    => {
            let n = pty_alloc()?;
            // Opening /dev/ptmx gives back a master fd; slave is /dev/pts/N
            // Register slave side in VFS for later open
            let slave_name = alloc::format!("/dev/pts/{}", n);
            let slave_tag  = DevTag::PtySlave(n);
            // Pre-register slave dev fd (opened when shell opens /dev/pts/N)
            let _ = alloc_dev_fd(DevFd { tag: slave_tag, pos: 0 });
            // For symmetry register the slave path in a side-table
            register_pts(n);
            DevTag::PtyMaster(n)
        }
        _ if path.starts_with("/dev/pts/") => {
            let n: usize = path["/dev/pts/".len()..].parse().ok()?;
            DevTag::PtySlave(n)
        }
        _ => return None,
    };
    alloc_dev_fd(DevFd { tag, pos: 0 })
}

static PTS_OPEN: Mutex<[bool; MAX_PTYS]> = Mutex::new([false; MAX_PTYS]);
fn register_pts(n: usize) { if n < MAX_PTYS { PTS_OPEN.lock()[n] = true; } }
pub fn pts_exists(n: usize) -> bool { n < MAX_PTYS && PTS_OPEN.lock()[n] }

// ── read ─────────────────────────────────────────────────────────────────

pub fn read(fdno: usize, buf: &mut [u8]) -> isize {
    let fd = match get_dev_fd(fdno) { Some(f) => f, None => return -9 };
    match fd.tag {
        DevTag::Null   => 0,
        DevTag::Full   => 0,
        DevTag::Zero   => {
            let n = buf.len();
            for b in buf.iter_mut() { *b = 0; }
            n as isize
        }
        DevTag::Urandom => {
            let n = buf.len();
            let mut i = 0;
            while i < n {
                let rnd = prng_next().to_le_bytes();
                let take = 8.min(n - i);
                buf[i..i+take].copy_from_slice(&rnd[..take]);
                i += take;
            }
            n as isize
        }
        DevTag::Tty => {
            let n = crate::drivers::tty::read(buf);
            n as isize
        }
        DevTag::PtyMaster(idx) => {
            let mut p = PTYS.lock();
            let pty = &mut p[idx];
            let n = buf.len().min(pty.s2m_len);
            buf[..n].copy_from_slice(&pty.s2m[..n]);
            pty.s2m.copy_within(n..pty.s2m_len, 0);
            pty.s2m_len -= n;
            n as isize
        }
        DevTag::PtySlave(idx) => {
            let mut p = PTYS.lock();
            let pty = &mut p[idx];
            let n = buf.len().min(pty.m2s_len);
            buf[..n].copy_from_slice(&pty.m2s[..n]);
            pty.m2s.copy_within(n..pty.m2s_len, 0);
            pty.m2s_len -= n;
            n as isize
        }
        DevTag::Mem => {
            // Read from physical memory at fd.pos
            let phys = fd.pos;
            let n = buf.len().min(4096);
            unsafe { core::ptr::copy_nonoverlapping(phys as *const u8, buf.as_mut_ptr(), n); }
            // Update pos
            if let Some(slot) = DEV_FDS.lock().get_mut(fdno - 1000) {
                if let Some(ref mut f) = slot { f.pos += n; }
            }
            n as isize
        }
    }
}

// ── write ─────────────────────────────────────────────────────────────────

pub fn write(fdno: usize, buf: &[u8]) -> isize {
    let fd = match get_dev_fd(fdno) { Some(f) => f, None => return -9 };
    match fd.tag {
        DevTag::Null => buf.len() as isize,
        DevTag::Zero => buf.len() as isize,
        DevTag::Full => -28, // ENOSPC
        DevTag::Urandom => buf.len() as isize, // writes seed PRNG
        DevTag::Tty => {
            for &b in buf { crate::drivers::uart::putc(b); }
            buf.len() as isize
        }
        DevTag::PtyMaster(idx) => {
            let mut p = PTYS.lock();
            let pty = &mut p[idx];
            let n = buf.len().min(PTY_BUF - pty.m2s_len);
            pty.m2s[pty.m2s_len..pty.m2s_len+n].copy_from_slice(&buf[..n]);
            pty.m2s_len += n;
            n as isize
        }
        DevTag::PtySlave(idx) => {
            let mut p = PTYS.lock();
            let pty = &mut p[idx];
            let n = buf.len().min(PTY_BUF - pty.s2m_len);
            pty.s2m[pty.s2m_len..pty.s2m_len+n].copy_from_slice(&buf[..n]);
            pty.s2m_len += n;
            n as isize
        }
        DevTag::Mem => -1, // read-only
    }
}

// ── ioctl on PTY master ───────────────────────────────────────────────────

pub const TIOCGPTN:  usize = 0x80045430; // get PTY number
pub const TIOCSPTLCK:usize = 0x40045431; // lock/unlock PTY

pub fn ioctl(fdno: usize, req: usize, arg: usize) -> isize {
    let fd = match get_dev_fd(fdno) { Some(f) => f, None => return -9 };
    match (fd.tag, req) {
        (DevTag::PtyMaster(n), r) if r == TIOCGPTN => {
            if arg != 0 { unsafe { *(arg as *mut u32) = n as u32; } }
            0
        }
        (DevTag::PtyMaster(_), r) if r == TIOCSPTLCK => 0,
        (DevTag::Tty, _) | (DevTag::PtySlave(_), _) =>
            crate::drivers::tty::ioctl(req, arg),
        _ => -25, // ENOTTY
    }
}

pub fn is_dev_path(path: &str) -> bool {
    path == "/dev" || path.starts_with("/dev/")
}

// ── /dev directory listing ────────────────────────────────────────────────

pub fn readdir() -> Vec<u8> {
    let mut out = alloc::vec::Vec::new();
    for name in &["null","zero","full","urandom","random","tty",
                  "stdin","stdout","stderr","mem","ptmx","pts"] {
        out.extend_from_slice(name.as_bytes()); out.push(b'\n');
    }
    out
}

pub fn seed_prng_word() -> u64 { prng_next() }
