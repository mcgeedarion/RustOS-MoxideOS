//! /proc virtual filesystem.
//!
//! Files are generated lazily on read — there is no on-disk storage.
//! The VFS `open()` function checks if the path starts with "/proc/" and
//! dispatches here instead of ext2/ramfs.
//!
//! Supported entries:
//!
//!   /proc/version         — kernel version string
//!   /proc/uptime          — seconds since boot (two fields)
//!   /proc/meminfo         — free/total physical memory
//!   /proc/cpuinfo         — CPU model + features stub
//!   /proc/<pid>/status    — name, state, PID, PPID, Vmrss
//!   /proc/<pid>/maps      — virtual memory areas (stub)
//!   /proc/<pid>/fd/       — open file descriptors (stub)
//!   /proc/self/status     — same as /proc/<current_pid>/status
//!   /proc/self/maps       — same as /proc/<current_pid>/maps

extern crate alloc;
use alloc::{string::String, vec::Vec};

// ── Boot timestamp ────────────────────────────────────────────────────────

static BOOT_TICK: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);

pub fn set_boot_tick(t: u64) {
    BOOT_TICK.store(t, core::sync::atomic::Ordering::Relaxed);
}

fn uptime_secs() -> u64 {
    let now = crate::arch::x86_64::apic::ticks();
    let boot = BOOT_TICK.load(core::sync::atomic::Ordering::Relaxed);
    now.saturating_sub(boot) / 100  // assuming 100 Hz timer
}

// ── Number formatting (no alloc needed — stack buf) ───────────────────────

fn fmt_usize(mut n: usize, buf: &mut [u8; 20]) -> &[u8] {
    let mut i = 20;
    if n == 0 { buf[19] = b'0'; return &buf[19..]; }
    while n > 0 { i -= 1; buf[i] = b'0' + (n % 10) as u8; n /= 10; }
    &buf[i..]
}

fn push_usize(v: &mut Vec<u8>, n: usize) {
    let mut buf = [0u8; 20];
    v.extend_from_slice(fmt_usize(n, &mut buf));
}

fn push_str(v: &mut Vec<u8>, s: &str) { v.extend_from_slice(s.as_bytes()); }
fn push_line(v: &mut Vec<u8>, k: &str, val: usize) {
    push_str(v, k); push_str(v, ": "); push_usize(v, val); v.push(b'\n');
}

// ── /proc/version ─────────────────────────────────────────────────────────

fn gen_version() -> Vec<u8> {
    let mut out = Vec::new();
    push_str(&mut out,
        "Linux version 6.1.0-rustos (rustos@kernel) \
         (rustc nightly, no GCC) #1 SMP PREEMPT rustos 2026\n");
    out
}

// ── /proc/uptime ──────────────────────────────────────────────────────────

fn gen_uptime() -> Vec<u8> {
    let secs = uptime_secs();
    let mut out = Vec::new();
    push_usize(&mut out, secs as usize);
    push_str(&mut out, ".00 ");
    push_usize(&mut out, secs as usize);  // idle ≈ uptime (single core)
    out.push(b'\n');
    out
}

// ── /proc/meminfo ─────────────────────────────────────────────────────────

fn gen_meminfo() -> Vec<u8> {
    let (total, free) = crate::mm::pmm::stats();
    let mut out = Vec::new();
    push_str(&mut out, "MemTotal:       "); push_usize(&mut out, total / 1024); push_str(&mut out, " kB\n");
    push_str(&mut out, "MemFree:        "); push_usize(&mut out, free  / 1024); push_str(&mut out, " kB\n");
    push_str(&mut out, "MemAvailable:   "); push_usize(&mut out, free  / 1024); push_str(&mut out, " kB\n");
    push_str(&mut out, "Buffers:        0 kB\n");
    push_str(&mut out, "Cached:         0 kB\n");
    out
}

// ── /proc/cpuinfo ─────────────────────────────────────────────────────────

fn gen_cpuinfo() -> Vec<u8> {
    let mut out = Vec::new();
    push_str(&mut out,
        "processor\t: 0\n\
         vendor_id\t: GenuineIntel\n\
         model name\t: QEMU Virtual CPU (rustos)\n\
         cpu MHz\t\t: 2000.000\n\
         cache size\t: 4096 KB\n\
         flags\t\t: fpu vme de pse tsc msr pae mce cx8 apic sep mtrr pge mca \
                    cmov pat pse36 clflush mmx fxsr sse sse2 syscall nx lm\n\n");
    out
}

// ── /proc/<pid>/status ────────────────────────────────────────────────────

fn gen_pid_status(pid: u32) -> Option<Vec<u8>> {
    let pcb = crate::proc::scheduler::find_pcb(pid)?;
    let mut out = Vec::new();
    push_str(&mut out, "Name:\t"); push_str(&mut out, pcb.name()); out.push(b'\n');
    push_str(&mut out, "State:\t"); push_str(&mut out, pcb.state_str()); out.push(b'\n');
    push_str(&mut out, "Pid:\t");  push_usize(&mut out, pid as usize);   out.push(b'\n');
    push_str(&mut out, "PPid:\t"); push_usize(&mut out, pcb.ppid as usize); out.push(b'\n');
    push_str(&mut out, "VmRSS:\t"); push_usize(&mut out, pcb.rss_kb()); push_str(&mut out, " kB\n");
    push_str(&mut out, "Threads:\t1\n");
    Some(out)
}

// ── /proc/<pid>/maps ─────────────────────────────────────────────────────

fn gen_pid_maps(pid: u32) -> Option<Vec<u8>> {
    let _ = crate::proc::scheduler::find_pcb(pid)?;
    // Stub: real implementation would walk the PML4
    let mut out = Vec::new();
    push_str(&mut out,
        "0000000000400000-0000000000401000 r-xp 00000000 00:00 0  [text]\n\
         0000000000401000-0000000000402000 rw-p 00001000 00:00 0  [data]\n\
         00007fff00000000-00007fff00100000 rw-p 00000000 00:00 0  [stack]\n");
    Some(out)
}

// ── Directory listing for /proc/<pid> ────────────────────────────────────

fn gen_pid_dir(pid: u32) -> Option<Vec<u8>> {
    let _ = crate::proc::scheduler::find_pcb(pid)?;
    let mut out = Vec::new();
    push_str(&mut out, "status\nmaps\nfd\n");
    Some(out)
}

// ── /proc directory listing ───────────────────────────────────────────────

fn gen_proc_dir() -> Vec<u8> {
    let mut out = Vec::new();
    push_str(&mut out, "self\nversion\nuptime\nmeminfo\ncpuinfo\n");
    for pid in crate::proc::scheduler::all_pids() {
        push_usize(&mut out, pid as usize);
        out.push(b'\n');
    }
    out
}

// ── Public entry point ────────────────────────────────────────────────────

/// Try to resolve a /proc path and return its content, or None.
pub fn read(path: &str) -> Option<Vec<u8>> {
    if path == "/proc" || path == "/proc/" { return Some(gen_proc_dir()); }
    if path == "/proc/version"  { return Some(gen_version()); }
    if path == "/proc/uptime"   { return Some(gen_uptime()); }
    if path == "/proc/meminfo"  { return Some(gen_meminfo()); }
    if path == "/proc/cpuinfo"  { return Some(gen_cpuinfo()); }

    let rest = path.strip_prefix("/proc/")?;

    // /proc/self → resolve to current PID
    let rest = if rest.starts_with("self") {
        let cur = crate::proc::scheduler::current_pid();
        alloc::format!("{}{}", cur, &rest["self".len()..])
    } else {
        rest.to_string()
    };

    let slash = rest.find('/');
    let pid_str = if let Some(s) = slash { &rest[..s] } else { &rest };
    let pid: u32 = pid_str.parse().ok()?;

    let sub = slash.map(|s| &rest[s+1..]).unwrap_or("");
    match sub {
        "" | "." => gen_pid_dir(pid),
        "status" => gen_pid_status(pid),
        "maps"   => gen_pid_maps(pid),
        "fd"     => Some(b"".to_vec()),
        _        => None,
    }
}

pub fn is_proc_path(path: &str) -> bool {
    path == "/proc" || path.starts_with("/proc/")
}
