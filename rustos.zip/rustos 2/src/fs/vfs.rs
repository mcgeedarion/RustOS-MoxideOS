//! Virtual filesystem — file descriptor table + multi-backend dispatch.
//!
//! Backends (tried in order on open):
//!   1. Ext2 image mounted by `mount_ext2()`
//!   2. In-memory ramfs (initramfs + runtime-created files)
//!
//! File descriptor table:
//!   FDs 0/1/2 are reserved (stdin/stdout/stderr — console I/O).
//!   FDs 3..MAX_FDS are heap-allocated per-process.
//!   The table lives in kernel global space for now; a production kernel
//!   would move it into the PCB.

extern crate alloc;
use alloc::{string::String, vec::Vec};
use spin::Mutex;

// ── Ramfs ─────────────────────────────────────────────────────────────────

pub struct RamfsInode {
    pub name: String,
    pub data: Vec<u8>,
}

static RAMFS: Mutex<Vec<RamfsInode>> = Mutex::new(Vec::new());

pub fn create_file(name: &str, data: &[u8]) {
    let mut ram = RAMFS.lock();
    if let Some(f) = ram.iter_mut().find(|f| f.name == name) {
        f.data = data.to_vec();
    } else {
        ram.push(RamfsInode { name: String::from(name), data: data.to_vec() });
    }
}

/// Lookup in ramfs only — returns a cloned Vec so the lock is released.
pub fn lookup(name: &str) -> Option<Vec<u8>> {
    RAMFS.lock().iter().find(|f| f.name == name).map(|f| f.data.clone())
}

// ── Open flags ────────────────────────────────────────────────────────────

pub const O_RDONLY: u32 = 0;
pub const O_WRONLY: u32 = 1;
pub const O_RDWR:   u32 = 2;
pub const O_CREAT:  u32 = 0o100;
pub const O_TRUNC:  u32 = 0o1000;
pub const O_APPEND: u32 = 0o2000;

// ── File descriptor ───────────────────────────────────────────────────────

#[derive(Clone)]
enum FdBacking {
    Ramfs(String),          // name in RAMFS
    Ext2(u32),              // inode number in ext2
    Pipe(alloc::sync::Arc<Mutex<Vec<u8>>>),
}

#[derive(Clone)]
pub struct Fd {
    pub flags:    u32,
    pub pos:      usize,
    backing:      FdBacking,
    write_buf:    Option<Vec<u8>>,  // Some for writable ramfs fds
}

const MAX_FDS: usize = 64;
static FD_TABLE: Mutex<[Option<Fd>; MAX_FDS]> = Mutex::new([const { None }; MAX_FDS]);

fn alloc_fd(fd: Fd) -> Option<usize> {
    let mut tbl = FD_TABLE.lock();
    for i in 3..MAX_FDS {
        if tbl[i].is_none() {
            tbl[i] = Some(fd);
            return Some(i);
        }
    }
    None
}

// ── open ─────────────────────────────────────────────────────────────────

pub fn open(path: &str, flags: u32) -> Result<usize, i32> {
    // /sys virtual filesystem
    if crate::fs::sysfs::is_sys_path(path) {
        let data = crate::fs::sysfs::read(path).ok_or(-2i32)?;
        let name = alloc::format!("__sys_{}", path);
        create_file(&name, &data);
        let fd = Fd { flags: O_RDONLY, pos: 0, backing: FdBacking::Ramfs(name), write_buf: None };
        return alloc_fd(fd).ok_or(-23);
    }

    // /dev virtual filesystem
    if crate::fs::devfs::is_dev_path(path) {
        if path == "/dev" {
            let data = crate::fs::devfs::readdir();
            let name = alloc::string::String::from("__dev_dir");
            create_file(&name, &data);
            let fd = Fd { flags: O_RDONLY, pos: 0, backing: FdBacking::Ramfs(name), write_buf: None };
            return alloc_fd(fd).ok_or(-23);
        }
        return crate::fs::devfs::open(path).map(|f| f).ok_or(-2).map(|n| n);
    }

    // /proc virtual filesystem
    if crate::fs::procfs::is_proc_path(path) {
        let data = crate::fs::procfs::read(path).ok_or(-2i32)?;
        let name = alloc::format!("__proc_{}", path);
        create_file(&name, &data);
        let fd = Fd { flags: O_RDONLY, pos: 0,
            backing: FdBacking::Ramfs(name), write_buf: None };
        return alloc_fd(fd).ok_or(-23);
    }

    let write = flags & (O_WRONLY | O_RDWR) != 0;
    let creat  = flags & O_CREAT != 0;

    // 1. Try ext2
    if let Some(ino) = crate::fs::ext2::stat(path) {
        let fd = Fd { flags, pos: 0, backing: FdBacking::Ext2(ino), write_buf: None };
        return alloc_fd(fd).ok_or(-23); // ENFILE
    }

    // 2. Try ramfs
    {
        let ram = RAMFS.lock();
        if ram.iter().any(|f| f.name == path) {
            drop(ram);
            let wb = if write { Some(if flags & O_TRUNC != 0 { Vec::new() }
                else { lookup(path).unwrap_or_default() }) } else { None };
            let fd = Fd { flags, pos: 0,
                backing: FdBacking::Ramfs(String::from(path)), write_buf: wb };
            return alloc_fd(fd).ok_or(-23);
        }
    }

    // 3. O_CREAT — create in ramfs
    if creat {
        create_file(path, &[]);
        let wb = Some(Vec::new());
        let fd = Fd { flags, pos: 0,
            backing: FdBacking::Ramfs(String::from(path)), write_buf: wb };
        return alloc_fd(fd).ok_or(-23);
    }

    Err(-2) // ENOENT
}

// ── read ──────────────────────────────────────────────────────────────────

pub fn read(fdno: usize, buf: &mut [u8]) -> isize {
    if crate::fs::devfs::get_dev_fd(fdno).is_some() {
        return crate::fs::devfs::read(fdno, buf);
    }
    let mut tbl = FD_TABLE.lock();
    let fd = match tbl[fdno].as_mut() { Some(f) => f, None => return -9 };
    if fd.flags & O_WRONLY != 0 { return -9; }

    let data: Vec<u8> = match &fd.backing {
        FdBacking::Ramfs(name) => {
            let ram = RAMFS.lock();
            match ram.iter().find(|f| f.name == *name) {
                Some(f) => f.data.clone(),
                None    => return -2,
            }
        }
        FdBacking::Ext2(ino) => {
            match crate::fs::ext2::read_file_by_ino(*ino) {
                Some(d) => d,
                None    => return -5,
            }
        }
        FdBacking::Pipe(p) => p.lock().clone(),
    };

    let available = data.len().saturating_sub(fd.pos);
    let n = buf.len().min(available);
    buf[..n].copy_from_slice(&data[fd.pos..fd.pos + n]);
    fd.pos += n;
    n as isize
}

// ── write ─────────────────────────────────────────────────────────────────

pub fn write(fdno: usize, buf: &[u8]) -> isize {
    if crate::fs::devfs::get_dev_fd(fdno).is_some() {
        return crate::fs::devfs::write(fdno, buf);
    }
    let mut tbl = FD_TABLE.lock();
    let fd = match tbl[fdno].as_mut() { Some(f) => f, None => return -9 };
    if fd.flags & O_RDONLY == 0 && fd.flags & (O_WRONLY | O_RDWR) == 0 { return -9; }

    let n = buf.len();
    match &mut fd.backing {
        FdBacking::Ramfs(name) => {
            if let Some(wb) = fd.write_buf.as_mut() {
                if fd.flags & O_APPEND != 0 { wb.extend_from_slice(buf); }
                else {
                    let end = fd.pos + n;
                    if end > wb.len() { wb.resize(end, 0); }
                    wb[fd.pos..end].copy_from_slice(buf);
                }
                fd.pos += n;
                // Flush back to ramfs
                let name = name.clone();
                let data = wb.clone();
                drop(tbl);
                create_file(&name, &data);
                return n as isize;
            }
        }
        FdBacking::Pipe(p) => { p.lock().extend_from_slice(buf); fd.pos += n; }
        FdBacking::Ext2(_) => return -1, // read-only fs
    }
    -1
}

// ── seek ──────────────────────────────────────────────────────────────────

pub const SEEK_SET: i32 = 0;
pub const SEEK_CUR: i32 = 1;
pub const SEEK_END: i32 = 2;

pub fn seek(fdno: usize, offset: i64, whence: i32) -> isize {
    let mut tbl = FD_TABLE.lock();
    let fd = match tbl[fdno].as_mut() { Some(f) => f, None => return -9 };
    let file_size = match &fd.backing {
        FdBacking::Ramfs(name) => RAMFS.lock().iter().find(|f| f.name == *name).map_or(0, |f| f.data.len()),
        FdBacking::Ext2(ino)   => crate::fs::ext2::file_size(*ino).unwrap_or(0),
        FdBacking::Pipe(_)     => 0,
    };
    let new_pos = match whence {
        SEEK_SET => offset as isize,
        SEEK_CUR => fd.pos as isize + offset as isize,
        SEEK_END => file_size as isize + offset as isize,
        _        => return -22,
    };
    if new_pos < 0 { return -22; }
    fd.pos = new_pos as usize;
    new_pos
}

// ── close ─────────────────────────────────────────────────────────────────

pub fn close(fdno: usize) -> isize {
    if crate::fs::devfs::close_dev_fd(fdno) { return 0; }
    if fdno < 3 { return -9; }
    FD_TABLE.lock()[fdno] = None;
    0
}

// ── fstat ─────────────────────────────────────────────────────────────────

/// Minimal stat — returns file size only (enough for musl fstat).
pub fn fstat(fdno: usize) -> Option<usize> {
    let tbl = FD_TABLE.lock();
    let fd = tbl[fdno].as_ref()?;
    let sz = match &fd.backing {
        FdBacking::Ramfs(name) => RAMFS.lock().iter().find(|f| f.name == *name).map_or(0, |f| f.data.len()),
        FdBacking::Ext2(ino)   => crate::fs::ext2::file_size(*ino).unwrap_or(0),
        FdBacking::Pipe(_)     => 0,
    };
    Some(sz)
}

// ── Socket file descriptors ───────────────────────────────────────────────

use crate::net::tcp::{TcpSocket, State as TcpState};

enum SocketKind { Tcp(TcpSocket) }
static SOCKETS: Mutex<[Option<SocketKind>; 64]> = Mutex::new([const { None }; 64]);

pub fn open_socket() -> Result<usize, i32> {
    let mut tbl = SOCKETS.lock();
    for i in 0..64 {
        if tbl[i].is_none() {
            tbl[i] = Some(SocketKind::Tcp(TcpSocket::new(0)));
            // Allocate a VFS fd pointing to socket slot i
            drop(tbl);
            let fd = Fd { flags: O_RDWR, pos: i, // pos = socket slot
                backing: FdBacking::Ramfs(alloc::format!("__sock_{}", i)),
                write_buf: None };
            return alloc_fd(fd).ok_or(-23);
        }
    }
    Err(-23)
}

fn sock_slot(fd: usize) -> Option<usize> {
    FD_TABLE.lock().get(fd)?.as_ref().map(|f| {
        if let FdBacking::Ramfs(ref n) = f.backing {
            if n.starts_with("__sock_") { n[7..].parse().ok() } else { None }
        } else { None }
    })?
}

pub fn socket_bind(fd: usize, port: u16) -> isize {
    let slot = match sock_slot(fd) { Some(s) => s, None => return -9 };
    let mut socks = SOCKETS.lock();
    if let Some(Some(SocketKind::Tcp(s))) = socks.get_mut(slot) { s.local_port = port; 0 }
    else { -9 }
}

pub fn socket_connect(fd: usize, ip: [u8;4], port: u16) -> isize {
    let slot = match sock_slot(fd) { Some(s) => s, None => return -9 };
    let mut socks = SOCKETS.lock();
    if let Some(Some(SocketKind::Tcp(s))) = socks.get_mut(slot) {
        if s.connect(ip, port) { 0 } else { -111 }
    } else { -9 }
}

pub fn socket_accept(fd: usize) -> isize {
    let slot = match sock_slot(fd) { Some(s) => s, None => return -9 };
    let mut socks = SOCKETS.lock();
    if let Some(Some(SocketKind::Tcp(s))) = socks.get_mut(slot) {
        if s.accept() { fd as isize } else { -11 }
    } else { -9 }
}

pub fn socket_send(fd: usize, data: &[u8]) -> isize {
    let slot = match sock_slot(fd) { Some(s) => s, None => return -9 };
    let mut socks = SOCKETS.lock();
    if let Some(Some(SocketKind::Tcp(s))) = socks.get_mut(slot) {
        if s.send(data) { data.len() as isize } else { -5 }
    } else { -9 }
}

pub fn socket_recv(fd: usize, len: usize) -> Option<alloc::vec::Vec<u8>> {
    let slot = sock_slot(fd)?;
    let mut socks = SOCKETS.lock();
    if let Some(Some(SocketKind::Tcp(s))) = socks.get_mut(slot) {
        let data = s.recv(1000);
        if data.is_empty() { None } else { Some(data[..data.len().min(len)].to_vec()) }
    } else { None }
}

// ── Pipe ─────────────────────────────────────────────────────────────────

pub fn create_pipe() -> Option<(usize, usize)> {
    let buf = alloc::sync::Arc::new(Mutex::new(alloc::vec::Vec::new()));
    let rfd = alloc_fd(Fd { flags: O_RDONLY, pos: 0,
        backing: FdBacking::Pipe(buf.clone()), write_buf: None })?;
    let wfd = alloc_fd(Fd { flags: O_WRONLY, pos: 0,
        backing: FdBacking::Pipe(buf), write_buf: None })?;
    Some((rfd, wfd))
}

// ── dup2 ─────────────────────────────────────────────────────────────────

pub fn dup2(old: usize, new: usize) -> isize {
    if old >= MAX_FDS || new >= MAX_FDS { return -9; }
    let mut tbl = FD_TABLE.lock();
    let entry = match tbl[old].clone() { Some(e) => e, None => return -9 };
    tbl[new] = Some(entry);
    new as isize
}

// ── fd_to_path ────────────────────────────────────────────────────────────

pub fn fd_to_path(fdno: usize) -> Option<alloc::string::String> {
    let tbl = FD_TABLE.lock();
    tbl.get(fdno).and_then(|e| e.as_ref()).map(|fd| match &fd.backing {
        FdBacking::Ramfs(name) => name.clone(),
        FdBacking::Ext2 { path, .. } => path.clone(),
    })
}

// ── resolve_path ──────────────────────────────────────────────────────────

pub fn resolve_path(path: &str) -> alloc::string::String {
    // Resolve symlinks (one level)
    let mut buf = [0u8; 512];
    if crate::fs::vfs_ops::readlink(path, &mut buf) > 0 {
        let end = buf.iter().position(|&b| b==0).unwrap_or(512);
        return core::str::from_utf8(&buf[..end]).unwrap_or(path).into();
    }
    path.into()
}

// ── stat ──────────────────────────────────────────────────────────────────

/// Linux stat64 structure (x86-64, simplified).
#[repr(C)]
pub struct Stat {
    pub st_dev:     u64,
    pub st_ino:     u64,
    pub st_nlink:   u64,
    pub st_mode:    u32,
    pub st_uid:     u32,
    pub st_gid:     u32,
    _pad0:          u32,
    pub st_rdev:    u64,
    pub st_size:    i64,
    pub st_blksize: i64,
    pub st_blocks:  i64,
    pub st_atim:    [u64; 2],
    pub st_mtim:    [u64; 2],
    pub st_ctim:    [u64; 2],
    _pad1:          [u64; 3],
}

pub fn stat(path: &str, stat_va: usize) -> isize {
    if stat_va == 0 { return -14; }
    // Check special paths
    if crate::fs::procfs::is_proc_path(path) ||
       crate::fs::devfs::is_dev_path(path)   ||
       crate::fs::sysfs::is_sys_path(path)   {
        let s = Stat {
            st_dev: 1, st_ino: 1, st_nlink: 1,
            st_mode: 0o040755, st_uid: 0, st_gid: 0, _pad0: 0,
            st_rdev: 0, st_size: 0, st_blksize: 4096, st_blocks: 0,
            st_atim: [0;2], st_mtim: [0;2], st_ctim: [0;2], _pad1: [0;3],
        };
        unsafe { core::ptr::write(stat_va as *mut Stat, s); }
        return 0;
    }
    // Try ramfs
    if let Some(data) = crate::fs::ramfs::read(path) {
        let s = Stat {
            st_dev: 2, st_ino: crate::fs::vfs::path_ino(path),
            st_nlink: 1, st_mode: 0o100644,
            st_uid: 0, st_gid: 0, _pad0: 0,
            st_rdev: 0, st_size: data.len() as i64,
            st_blksize: 4096, st_blocks: ((data.len() + 511) / 512) as i64,
            st_atim: [0;2], st_mtim: [0;2], st_ctim: [0;2], _pad1: [0;3],
        };
        unsafe { core::ptr::write(stat_va as *mut Stat, s); }
        return 0;
    }
    -2 // ENOENT
}

pub fn path_ino(path: &str) -> u64 {
    // Stable hash of the path as inode number
    let mut h = 0xcbf29ce484222325u64;
    for &b in path.as_bytes() { h ^= b as u64; h = h.wrapping_mul(0x100000001b3); }
    h
}

// ── access ────────────────────────────────────────────────────────────────

pub fn access(path: &str, _mode: u32) -> isize {
    // F_OK = 0: check existence
    if crate::fs::procfs::is_proc_path(path) { return 0; }
    if crate::fs::devfs::is_dev_path(path)   { return 0; }
    if crate::fs::sysfs::is_sys_path(path)   { return 0; }
    if crate::fs::ramfs::read(path).is_some() { return 0; }
    -2 // ENOENT
}

pub fn dup_from(old: usize, start: usize) -> isize {
    if old >= MAX_FDS { return -9; }
    let mut tbl = FD_TABLE.lock();
    let entry = match tbl[old].clone() { Some(e) => e, None => return -9 };
    for i in start..MAX_FDS {
        if tbl[i].is_none() { tbl[i] = Some(entry); return i as isize; }
    }
    -24 // EMFILE
}

// ── Ext2-backed VFS write ─────────────────────────────────────────────────

/// sys_write for a file fd — writes to ext2 if path lives there,
/// otherwise updates the ramfs backing copy.
pub fn write_fd(fdno: usize, buf: &[u8]) -> isize {
    // stdout / stderr
    if fdno == 1 || fdno == 2 {
        for &b in buf { crate::arch::x86_64::serial::write_byte(b); }
        return buf.len() as isize;
    }
    if let Some(path) = fd_to_path(fdno) {
        crate::fs::vfs_ops::write_file(&path, buf)
    } else {
        -9 // EBADF
    }
}

/// Unified stat that checks ext2 before ramfs.
pub fn stat_unified(path: &str, stat_va: usize) -> isize {
    // Check ext2
    if crate::fs::ext2::is_mounted() {
        if let Some(ino) = crate::fs::ext2::stat(path) {
            if stat_va == 0 { return 0; }
            let size = crate::fs::ext2::file_size(ino).unwrap_or(0);
            let s = Stat {
                st_dev: 3, st_ino: ino as u64, st_nlink: 1,
                st_mode: 0o100644, st_uid: 0, st_gid: 0, _pad0: 0,
                st_rdev: 0, st_size: size as i64,
                st_blksize: 4096,
                st_blocks: ((size + 511) / 512) as i64,
                st_atim: [0;2], st_mtim: [0;2], st_ctim: [0;2], _pad1: [0;3],
            };
            unsafe { core::ptr::write(stat_va as *mut Stat, s); }
            return 0;
        }
    }
    stat(path, stat_va)
}

/// Open a file: ext2 first, then procfs/devfs/sysfs, then ramfs.
pub fn open_unified(path: &str, flags: usize) -> isize {
    use crate::fs::vfs::{create_file as ramfs_create, alloc_fd, Fd, FdBacking, O_RDONLY, O_WRONLY, O_RDWR, O_CREAT};
    // Ext2
    if crate::fs::ext2::is_mounted() {
        if let Some(data) = crate::fs::ext2::read_file(path) {
            ramfs_create(path, &data); // mirror to ramfs cache
            let fd = Fd { flags: flags & 3, pos: 0, backing: FdBacking::Ramfs(alloc::string::String::from(path)), write_buf: None };
            return alloc_fd(fd).map(|n| n as isize).unwrap_or(-24);
        }
        // O_CREAT: create in ext2
        if flags & O_CREAT != 0 {
            crate::fs::ext2::create_file(path, b"");
            let fd = Fd { flags: flags & 3, pos: 0, backing: FdBacking::Ramfs(alloc::string::String::from(path)), write_buf: None };
            return alloc_fd(fd).map(|n| n as isize).unwrap_or(-24);
        }
    }
    -2 // fall through to caller
}

// ── lseek / get_pos / read_fd ─────────────────────────────────────────────

pub fn lseek(fdno: usize, offset: i64, whence: u32) -> isize {
    let mut tbl = FD_TABLE.lock();
    if fdno >= MAX_FDS { return -9; }
    if let Some(Some(fd)) = tbl.get_mut(fdno) {
        let size = match &fd.backing {
            FdBacking::Ramfs(name) => crate::fs::ramfs::read(name).map(|d| d.len()).unwrap_or(0),
            _ => 0,
        };
        let new_pos = match whence {
            0 => offset as usize,                         // SEEK_SET
            1 => (fd.pos as i64 + offset).max(0) as usize, // SEEK_CUR
            2 => (size as i64 + offset).max(0) as usize,  // SEEK_END
            _ => return -22,
        };
        fd.pos = new_pos;
        return new_pos as isize;
    }
    -9
}

pub fn get_pos(fdno: usize) -> usize {
    let tbl = FD_TABLE.lock();
    tbl.get(fdno).and_then(|e| e.as_ref()).map(|fd| fd.pos).unwrap_or(0)
}

pub fn read_fd(fdno: usize, buf_va: usize, count: usize) -> isize {
    if buf_va == 0 || count == 0 { return 0; }
    let mut tbl = FD_TABLE.lock();
    if fdno >= MAX_FDS { return -9; }
    let fd = match tbl.get_mut(fdno).and_then(|e| e.as_mut()) { Some(f) => f, None => return -9 };
    let data = match &fd.backing {
        FdBacking::Ramfs(name) => {
            match crate::fs::ramfs::read(name) { Some(d) => d, None => return 0 }
        }
        _ => return -9,
    };
    let start = fd.pos.min(data.len());
    let end   = (fd.pos + count).min(data.len());
    let n     = end - start;
    if n > 0 {
        unsafe { core::ptr::copy_nonoverlapping(data.as_ptr().add(start), buf_va as *mut u8, n); }
    }
    fd.pos = end;
    n as isize
}
