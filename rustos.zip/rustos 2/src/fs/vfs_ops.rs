//! Filesystem mutation operations for ramfs.
//!
//! ext2 is mounted read-only; all writes go to the ramfs overlay.
//! The VFS routes mutation calls here after checking the path prefix.

extern crate alloc;
use alloc::{string::String, vec::Vec};
use spin::Mutex;
use crate::fs::ramfs;
use crate::fs::vfs::{create_file, resolve_path};

// ── Symlink table ─────────────────────────────────────────────────────────

struct Symlink { from: String, to: String }
static SYMLINKS: Mutex<Vec<Symlink>> = Mutex::new(Vec::new());

pub fn readlink(path: &str, buf: &mut [u8]) -> isize {
    let links = SYMLINKS.lock();
    if let Some(sl) = links.iter().find(|s| s.from == path) {
        let n = sl.to.len().min(buf.len());
        buf[..n].copy_from_slice(&sl.to.as_bytes()[..n]);
        return n as isize;
    }
    -2 // ENOENT
}

pub fn symlink(target: &str, linkpath: &str) -> isize {
    let mut links = SYMLINKS.lock();
    links.retain(|s| s.from != linkpath); // remove existing
    links.push(Symlink { from: String::from(linkpath), to: String::from(target) });
    0
}

// ── mkdir ─────────────────────────────────────────────────────────────────

pub fn mkdir(path: &str, _mode: u32) -> isize {
    // Create a directory marker file in ramfs: path + "/.dir"
    let marker = alloc::format!("{}/.dir", path);
    create_file(&marker, b"");
    0
}

// ── rmdir ─────────────────────────────────────────────────────────────────

pub fn rmdir(path: &str) -> isize {
    let marker = alloc::format!("{}/.dir", path);
    ramfs::remove(&marker);
    0
}

// ── unlink ────────────────────────────────────────────────────────────────

pub fn unlink(path: &str) -> isize {
    if ramfs::remove(path) { 0 } else { -2 } // ENOENT
}

// ── rename ────────────────────────────────────────────────────────────────

pub fn rename(oldpath: &str, newpath: &str) -> isize {
    if let Some(data) = ramfs::read(oldpath) {
        create_file(newpath, &data);
        ramfs::remove(oldpath);
        0
    } else {
        -2
    }
}

// ── link (hard link — copy in ramfs) ─────────────────────────────────────

pub fn link(oldpath: &str, newpath: &str) -> isize {
    if let Some(data) = ramfs::read(oldpath) {
        create_file(newpath, &data);
        0
    } else {
        -2
    }
}

// ── chmod ─────────────────────────────────────────────────────────────────

pub fn chmod(_path: &str, _mode: u32) -> isize {
    0 // no permission model yet
}

// ── truncate / ftruncate ──────────────────────────────────────────────────

pub fn truncate(path: &str, length: i64) -> isize {
    if let Some(mut data) = ramfs::read(path) {
        data.resize(length as usize, 0);
        create_file(path, &data);
        0
    } else {
        -2
    }
}

pub fn ftruncate(fd: usize, length: i64) -> isize {
    // Look up path from fd, then truncate
    if let Some(path) = crate::fs::vfs::fd_to_path(fd) {
        truncate(&path, length)
    } else {
        -9 // EBADF
    }
}

// ── umask ─────────────────────────────────────────────────────────────────

static UMASK: core::sync::atomic::AtomicU32 = core::sync::atomic::AtomicU32::new(0o022);

pub fn umask(mask: u32) -> u32 {
    UMASK.swap(mask, core::sync::atomic::Ordering::Relaxed)
}

pub fn get_umask() -> u32 {
    UMASK.load(core::sync::atomic::Ordering::Relaxed)
}

// ── Ext2-aware write ops ──────────────────────────────────────────────────
// Paths starting with /etc, /bin, /lib, /usr, /home go to ext2.
// /tmp and /var go to ramfs overlay.

fn is_ext2_path(path: &str) -> bool {
    matches!(path.split('/').nth(1).unwrap_or(""),
        "etc"|"bin"|"lib"|"usr"|"home"|"root"|"sbin"|"opt"|"srv")
}

pub fn write_file(path: &str, data: &[u8]) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(path) {
        if crate::fs::ext2::create_file(path, data) != 0 { 0 } else { -28 } // ENOSPC
    } else {
        crate::fs::vfs::create_file(path, data);
        0
    }
}

pub fn ext2_mkdir(path: &str, _mode: u32) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(path) {
        if crate::fs::ext2::mkdir_p(path) != 0 { 0 } else { -28 }
    } else {
        mkdir(path, _mode)
    }
}

pub fn ext2_unlink(path: &str) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(path) {
        if crate::fs::ext2::unlink(path) { 0 } else { -2 }
    } else {
        unlink(path)
    }
}

pub fn ext2_rename(old: &str, new: &str) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(old) {
        if crate::fs::ext2::rename(old, new) { 0 } else { -2 }
    } else {
        rename(old, new)
    }
}

pub fn ext2_symlink(target: &str, linkpath: &str) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(linkpath) {
        if crate::fs::ext2::symlink(target, linkpath) { 0 } else { -2 }
    } else {
        symlink(target, linkpath)
    }
}

pub fn ext2_truncate(path: &str, length: i64) -> isize {
    if crate::fs::ext2::is_mounted() && is_ext2_path(path) {
        if crate::fs::ext2::truncate(path, length as usize) { 0 } else { -2 }
    } else {
        truncate(path, length)
    }
}
