//! RAM-backed filesystem (wraps vfs)
pub fn mount() { /* no-op: vfs is already in-memory */ }

/// Remove a file by name. Returns true if found and removed.
pub fn remove(name: &str) -> bool {
    let mut store = STORE.lock();
    let before = store.len();
    store.retain(|e| e.name != name);
    store.len() < before
}

/// Read a file's contents (clone). Returns None if not found.
pub fn read(name: &str) -> Option<alloc::vec::Vec<u8>> {
    STORE.lock().iter().find(|e| e.name == name).map(|e| e.data.clone())
}
