//! Simple xorshift64 PRNG seeded from cycle counter
use core::sync::atomic::{AtomicU64, Ordering};

static STATE: AtomicU64 = AtomicU64::new(0x12345678_9abcdef0);

pub fn next_u64() -> u64 {
    let mut x = STATE.load(Ordering::Relaxed);
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    STATE.store(x, Ordering::Relaxed);
    x
}

pub fn seed(val: u64) {
    STATE.store(val, Ordering::SeqCst);
}
