//! Sleeping mutex (wraps spin::Mutex for now)
pub use spin::Mutex;
