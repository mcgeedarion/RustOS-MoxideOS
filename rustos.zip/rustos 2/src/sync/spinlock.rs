//! Spinlock wrapper
pub use spin::Mutex as SpinLock;
