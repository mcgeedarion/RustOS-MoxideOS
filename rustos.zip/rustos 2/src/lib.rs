#![no_std]
#![feature(alloc_error_handler)]

extern crate alloc;

pub use crate::mm::heap::ALLOCATOR;
