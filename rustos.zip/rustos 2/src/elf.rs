//! ELF64 loader for RISC-V user processes
use crate::mm::vmm::{map_page, TRAMPOLINE_VA};
use crate::mm::pmm::{alloc_page, PAGE_SIZE};
use crate::arch::riscv64::paging::PteFlags;

const ELF_MAGIC:   [u8; 4] = [0x7f, b'E', b'L', b'F'];
const ELF_CLASS64: u8  = 2;
const ELF_LE:      u8  = 1;
const ELF_RISCV:   u16 = 0xF3;
const PT_LOAD:     u32 = 1;
const PF_X: u32 = 1;
const PF_W: u32 = 2;
const PF_R: u32 = 4;

#[repr(C, packed)]
struct Elf64Ehdr {
    e_ident: [u8; 16], e_type: u16, e_machine: u16, e_version: u32,
    e_entry: u64, e_phoff: u64, e_shoff: u64, e_flags: u32,
    e_ehsize: u16, e_phentsize: u16, e_phnum: u16,
    e_shentsize: u16, e_shnum: u16, e_shstrndx: u16,
}

#[repr(C, packed)]
struct Elf64Phdr {
    p_type: u32, p_flags: u32,
    p_offset: u64, p_vaddr: u64, p_paddr: u64,
    p_filesz: u64, p_memsz: u64, p_align: u64,
}

pub struct LoadedElf {
    pub entry:    usize,
    pub load_end: usize,
}

/// Load an ELF64 binary from `data` into the page table at `root_pa`.
/// All newly allocated pages are pushed onto `owned` for lifecycle tracking.
pub fn load(
    data: &[u8],
    root_pa: usize,
    owned: &mut alloc::vec::Vec<usize>,
) -> Result<LoadedElf, &'static str> {
    if data.len() < core::mem::size_of::<Elf64Ehdr>() { return Err("ELF too small"); }
    let ehdr = unsafe { &*(data.as_ptr() as *const Elf64Ehdr) };

    if ehdr.e_ident[..4] != ELF_MAGIC  { return Err("bad ELF magic"); }
    if ehdr.e_ident[4]   != ELF_CLASS64 { return Err("not ELF64"); }
    if ehdr.e_ident[5]   != ELF_LE      { return Err("not little-endian"); }
    if { ehdr.e_machine } != ELF_RISCV   { return Err("not RISC-V"); }

    let phoff   = { ehdr.e_phoff }    as usize;
    let phnum   = { ehdr.e_phnum }    as usize;
    let phentsz = { ehdr.e_phentsize} as usize;
    let entry   = { ehdr.e_entry }    as usize;

    if phoff == 0 || phnum == 0 { return Err("no program headers"); }
    if phentsz < core::mem::size_of::<Elf64Phdr>() { return Err("phentsize too small"); }
    let ph_end = phoff.checked_add(phnum * phentsz).ok_or("phdr overflow")?;
    if ph_end > data.len() { return Err("phdr out of bounds"); }

    let mut load_end: usize = 0;

    for i in 0..phnum {
        let ph = unsafe {
            &*(data.as_ptr().add(phoff + i * phentsz) as *const Elf64Phdr)
        };
        if { ph.p_type } != PT_LOAD { continue; }

        let file_off = { ph.p_offset } as usize;
        let vaddr    = { ph.p_vaddr  } as usize;
        let filesz   = { ph.p_filesz } as usize;
        let memsz    = { ph.p_memsz  } as usize;
        let flags    = { ph.p_flags  };

        if memsz == 0  { continue; }
        if vaddr == 0  { return Err("PT_LOAD at VA 0"); }
        if vaddr >= TRAMPOLINE_VA { return Err("PT_LOAD overlaps trampoline"); }
        let file_end = file_off.checked_add(filesz).ok_or("segment overflow")?;
        if file_end > data.len() { return Err("segment out of bounds"); }

        // Build PTE flags — enforce W^X
        let mut pte = PteFlags::U;
        if flags & PF_R != 0 { pte |= PteFlags::R; }
        if flags & PF_W != 0 { pte |= PteFlags::W; }
        if flags & PF_X != 0 { pte |= PteFlags::X; }
        if pte.contains(PteFlags::W | PteFlags::X) { pte.remove(PteFlags::X); }

        let va_start = vaddr & !(PAGE_SIZE - 1);
        let va_end   = (vaddr + memsz + PAGE_SIZE - 1) & !(PAGE_SIZE - 1);
        let mut va   = va_start;
        while va < va_end {
            let pa = alloc_page().ok_or("OOM mapping ELF segment")?;
            unsafe { core::ptr::write_bytes(pa as *mut u8, 0, PAGE_SIZE); }
            owned.push(pa);

            let copy_start = vaddr.max(va);
            let copy_end   = (vaddr + filesz).min(va + PAGE_SIZE);
            if copy_start < copy_end {
                let src_off  = file_off + (copy_start - vaddr);
                let dst_off  = copy_start - va;
                let copy_len = copy_end - copy_start;
                unsafe {
                    core::ptr::copy_nonoverlapping(
                        data.as_ptr().add(src_off),
                        (pa + dst_off) as *mut u8,
                        copy_len,
                    );
                }
            }
            map_page(root_pa, va, pa, pte);
            va += PAGE_SIZE;
        }
        if va_end > load_end { load_end = va_end; }
    }

    if load_end == 0 { return Err("no PT_LOAD segments"); }
    if entry   == 0  { return Err("entry point is 0"); }
    Ok(LoadedElf { entry, load_end })
}
