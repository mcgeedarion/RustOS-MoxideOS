#!/usr/bin/env bash
set -euo pipefail
cargo build --release --target riscv64gc-unknown-none-elf
