# rustos_kernel

A hardened RISC-V (Sv39) kernel written in Rust, targeting the QEMU `virt` machine.

## Features

| Feature | Status |
|---|---|
| Sv39 virtual memory (satp activation at boot) | ✅ Implemented |
| Kernel page-table isolation (KPTI) | ✅ Implemented |
| ELF64 loader (PT_LOAD, W^X, trampoline-guard) | ✅ Implemented |
| Real context switching (switch_context asm) | ✅ Implemented |
| Syscall validation (null, length, UTF-8 checks) | ✅ Implemented |
| Capability-based permissions (`CapSet`) | ✅ Implemented |
| Heap canaries (0xAB alloc / 0xDE free poison) | ✅ Implemented |
| Interactive UART shell + readline | ✅ Implemented |
| sys_write to UART (fd 1/2) | ✅ Implemented |
| sys_exit + scheduler teardown | ✅ Implemented |
| initramfs auto-exec of /init | ✅ Implemented |
| W^X via PMP | 🔧 Stub |
| KASLR | 🔧 Stub |
| Full networking (ipv4::send) | 🔧 Stub |
| ext2 / FAT32 | 🔧 Stub |

## Boot flow

```
_start (asm) → rust_pre_main
  ├─ pmm::init()           # physical page allocator
  ├─ build_boot_kernel_pt() # Sv39: identity + higher-half + trampoline
  ├─ write_satp / sfence.vma
  └─ rust_main
       ├─ heap / drivers / PLIC
       ├─ proc::init() → load initramfs → exec /init via ELF loader
       └─ shell::tty::run() (interactive UART shell)
```

## KPTI design

Each process carries two SATP roots:

- **`kernel_satp`** — full higher-half kernel + user pages + trampoline + trapframe.
- **`user_satp`** — user pages + trampoline + trapframe only (no kernel higher-half).

All traps route through `trampoline.S` (mapped at `0x0000_003f_ffff_f000` in both
page tables). On entry: save regs → switch to `kernel_satp` → `sfence.vma` → Rust
handler. On exit: restore regs → switch to `user_satp` → `sfence.vma` → `sret`.

## Build

```bash
bash build.sh
```

## Run in QEMU

```bash
qemu-system-riscv64 \
  -machine virt -bios none \
  -kernel target/riscv64gc-unknown-none-elf/release/rustos_kernel \
  -nographic
```

## Filesystem

Only **initramfs + in-memory VFS** are functional. ext2 / FAT32 are stubs.

## Networking

All network modules are stubs. UDP header building is implemented; `ipv4::send` is not.
