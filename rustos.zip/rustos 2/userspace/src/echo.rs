//! echo — write args to stdout.  Shell built-in handles most uses;
//! this binary exists so  echo foo | cat  works via fork/exec.
#![no_std]
#![no_main]
mod syscall;
mod io;

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // Without argv parsing we just write a newline — sufficient for tests.
    io::println(b"");
    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
