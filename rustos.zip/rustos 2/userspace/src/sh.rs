//! rustos shell — a small but real interactive POSIX-ish shell.
#![no_std]
#![no_main]

mod syscall;
mod io;

const MAX_ARGS:  usize = 32;
const MAX_TOKS:  usize = 64;
const LINE_SIZE: usize = 512;

// ── Token types ───────────────────────────────────────────────────────────

#[derive(Copy, Clone, PartialEq)]
enum Tok<'a> { Word(&'a [u8]), Pipe, RedirOut(&'a [u8]), RedirIn(&'a [u8]), RedirAppend(&'a [u8]) }

// ── Path helpers ──────────────────────────────────────────────────────────

fn find_in_path(name: &[u8], out: &mut [u8; 128]) -> bool {
    // If name starts with '/' use directly
    if name.first() == Some(&b'/') {
        let len = name.len().min(127);
        out[..len].copy_from_slice(&name[..len]);
        out[len] = 0;
        return true;
    }
    let dirs: &[&[u8]] = &[b"/bin", b"/usr/bin", b"/usr/local/bin"];
    for dir in dirs {
        let dl = dir.len();
        let nl = name.len();
        if dl + 1 + nl >= 128 { continue; }
        out[..dl].copy_from_slice(dir);
        out[dl] = b'/';
        out[dl+1..dl+1+nl].copy_from_slice(name);
        out[dl+1+nl] = 0;
        // Try to open to check existence
        let fd = syscall::open(&out[..dl+1+nl+1], 0 /*O_RDONLY*/);
        if fd >= 0 { syscall::close(fd as usize); return true; }
    }
    false
}

// ── Tokeniser ─────────────────────────────────────────────────────────────

fn tokenise<'a>(line: &'a [u8], toks: &mut [Option<Tok<'a>>; MAX_TOKS]) -> usize {
    let mut i = 0; let mut ntok = 0;
    while i < line.len() && ntok < MAX_TOKS {
        // Skip whitespace
        if line[i] == b' ' || line[i] == b'\t' || line[i] == b'\n' || line[i] == 0 {
            i += 1; continue;
        }
        if line[i] == b'|' {
            toks[ntok] = Some(Tok::Pipe); ntok += 1; i += 1; continue;
        }
        if line[i] == b'>' {
            i += 1;
            let append = if i < line.len() && line[i] == b'>' { i += 1; true } else { false };
            while i < line.len() && (line[i] == b' ' || line[i] == b'\t') { i += 1; }
            let start = i;
            while i < line.len() && line[i] != b' ' && line[i] != b'\t' && line[i] != b'\n' && line[i] != 0 { i += 1; }
            let word = &line[start..i];
            toks[ntok] = Some(if append { Tok::RedirAppend(word) } else { Tok::RedirOut(word) });
            ntok += 1; continue;
        }
        if line[i] == b'<' {
            i += 1;
            while i < line.len() && (line[i] == b' ' || line[i] == b'\t') { i += 1; }
            let start = i;
            while i < line.len() && line[i] != b' ' && line[i] != b'\t' && line[i] != b'\n' && line[i] != 0 { i += 1; }
            toks[ntok] = Some(Tok::RedirIn(&line[start..i])); ntok += 1; continue;
        }
        // Quoted string
        if line[i] == b'"' {
            i += 1;
            let start = i;
            while i < line.len() && line[i] != b'"' { i += 1; }
            toks[ntok] = Some(Tok::Word(&line[start..i])); ntok += 1;
            if i < line.len() { i += 1; }
            continue;
        }
        // Bare word
        let start = i;
        while i < line.len() && line[i] != b' ' && line[i] != b'\t'
            && line[i] != b'|' && line[i] != b'>' && line[i] != b'<'
            && line[i] != b'\n' && line[i] != 0 { i += 1; }
        toks[ntok] = Some(Tok::Word(&line[start..i])); ntok += 1;
    }
    ntok
}

// ── Collect words from tokens into argv ──────────────────────────────────

fn words_to_argv<'a>(toks: &[Option<Tok<'a>>], argv: &mut [*const u8; MAX_ARGS+1]) -> usize {
    let mut n = 0;
    for t in toks.iter().flatten() {
        if n >= MAX_ARGS { break; }
        if let Tok::Word(w) = t { argv[n] = w.as_ptr(); n += 1; }
        else { break; }
    }
    argv[n] = core::ptr::null();
    n
}

// ── Split token stream at Pipe ────────────────────────────────────────────

fn split_pipe<'a>(toks: &[Option<Tok<'a>>], n: usize)
    -> (usize, usize) // (left_end, right_start) or (n, n) if no pipe
{
    for i in 0..n {
        if toks[i] == Some(Tok::Pipe) { return (i, i+1); }
    }
    (n, n)
}

// ── Spawn a command ───────────────────────────────────────────────────────

fn spawn(toks: &[Option<Tok<'_>>], ntok: usize,
         redir_in: Option<&[u8]>, redir_out: Option<(&[u8], bool)>,
         stdin_fd: Option<usize>, stdout_fd: Option<usize>) -> isize
{
    let mut argv: [*const u8; MAX_ARGS+1] = [core::ptr::null(); MAX_ARGS+1];
    let nargs = words_to_argv(toks, &mut argv);
    if nargs == 0 { return 0; }

    let name = unsafe { core::slice::from_raw_parts(argv[0], 64) };
    let end = io::memchr(name, 0).unwrap_or(64);
    let name = &name[..end];

    let mut path_buf = [0u8; 128];
    if !find_in_path(name, &mut path_buf) {
        io::print(b"sh: command not found: "); io::println(name);
        return -1;
    }

    let pid = syscall::fork();
    if pid < 0 { io::println(b"sh: fork failed"); return -1; }
    if pid == 0 {
        // Redirections
        if let Some(path) = redir_in {
            let mut p = [0u8; 256]; let l = path.len().min(255);
            p[..l].copy_from_slice(&path[..l]); p[l] = 0;
            let fd = syscall::open(&p[..l+1], 0);
            if fd < 0 { io::println(b"sh: cannot open input file"); syscall::exit(1); }
            syscall::dup2(fd as usize, 0);
            syscall::close(fd as usize);
        }
        if let Some((path, append)) = redir_out {
            let mut p = [0u8; 256]; let l = path.len().min(255);
            p[..l].copy_from_slice(&path[..l]); p[l] = 0;
            let flags = if append { 0o1|0o2000 } else { 0o1|0o100|0o1000 };
            let fd = unsafe { syscall::syscall3(syscall::SYS_OPEN, p.as_ptr() as usize, flags, 0o644) };
            if fd < 0 { io::println(b"sh: cannot open output file"); syscall::exit(1); }
            syscall::dup2(fd as usize, 1);
            syscall::close(fd as usize);
        }
        if let Some(fd) = stdin_fd  { syscall::dup2(fd, 0); syscall::close(fd); }
        if let Some(fd) = stdout_fd { syscall::dup2(fd, 1); syscall::close(fd); }

        let envp: [*const u8; 1] = [core::ptr::null()];
        syscall::execve(&path_buf[..path_buf.iter().position(|&b| b==0).unwrap_or(128)+1],
                        &argv[..nargs+1], &envp);
        io::println(b"sh: execve failed");
        syscall::exit(127);
    }
    pid
}

// ── Built-in: echo ────────────────────────────────────────────────────────

fn builtin_echo(toks: &[Option<Tok<'_>>]) {
    let mut first = true;
    for t in toks.iter().skip(1).flatten() {
        if let Tok::Word(w) = t {
            if !first { io::print(b" "); }
            io::print(w); first = false;
        }
    }
    io::println(b"");
}

// ── Main shell loop ───────────────────────────────────────────────────────

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // Ensure we have a real terminal — reopen /dev/tty as fd 0 if needed
    {
        let tty = syscall::open(b"/dev/tty\0", 2 /*O_RDWR*/);
        if tty >= 0 {
            syscall::dup2(tty as usize, 0);
            syscall::dup2(tty as usize, 1);
            syscall::dup2(tty as usize, 2);
            syscall::close(tty as usize);
        }
    }
    io::println(b"rustos /bin/sh — type 'exit' to quit");

    let mut line = [0u8; LINE_SIZE];
    let mut exit_code: i32 = 0;

    loop {
        // Prompt
        io::print(b"$ ");
        let n = io::readline(0, &mut line);
        if n == 0 { continue; }

        // Strip trailing newline/whitespace
        let mut end = n;
        while end > 0 && (line[end-1] == b'\n' || line[end-1] == b'\r' || line[end-1] == 0) { end -= 1; }
        let line_s = &line[..end];

        if line_s.is_empty() { continue; }

        // Background?
        let background = line_s.last() == Some(&b'&');
        let line_s = if background { &line_s[..line_s.len()-1] } else { line_s };

        // Tokenise
        let mut toks: [Option<Tok>; MAX_TOKS] = [None; MAX_TOKS];
        let ntok = tokenise(line_s, &mut toks);
        if ntok == 0 { continue; }

        // Extract built-in command name
        let cmd_name = if let Some(Tok::Word(w)) = toks[0] { w } else { continue };

        // Collect redirections from token stream
        let mut redir_out: Option<(&[u8], bool)> = None;
        let mut redir_in:  Option<&[u8]> = None;
        for t in toks[..ntok].iter().flatten() {
            match t {
                Tok::RedirOut(p)    => redir_out = Some((p, false)),
                Tok::RedirAppend(p) => redir_out = Some((p, true)),
                Tok::RedirIn(p)     => redir_in  = Some(p),
                _ => {}
            }
        }

        // ── Built-ins ─────────────────────────────────────────────────────
        if io::bytes_eq(cmd_name, b"exit") {
            let code = if ntok > 1 {
                if let Some(Tok::Word(w)) = toks[1] {
                    let mut v = 0i32;
                    for &b in w { if b >= b'0' && b <= b'9' { v = v*10 + (b-b'0') as i32; } }
                    v
                } else { 0 }
            } else { 0 };
            syscall::exit(code);
        }

        if io::bytes_eq(cmd_name, b"echo") { builtin_echo(&toks[..ntok]); continue; }

        if io::bytes_eq(cmd_name, b"cd") {
            // kernel doesn't track cwd per-process yet; print message
            io::println(b"sh: cd not yet supported by kernel"); continue;
        }

        if io::bytes_eq(cmd_name, b"pwd") { io::println(b"/"); continue; }

        if io::bytes_eq(cmd_name, b"true")  { exit_code = 0; continue; }
        if io::bytes_eq(cmd_name, b"false") { exit_code = 1; continue; }

        // ── Pipe detection ────────────────────────────────────────────────
        let (left_end, right_start) = split_pipe(&toks, ntok);
        let has_pipe = right_start < ntok;

        if has_pipe {
            let mut pipefd: [i32; 2] = [-1, -1];
            if syscall::pipe(&mut pipefd) < 0 { io::println(b"sh: pipe failed"); continue; }

            let p1 = spawn(&toks[..left_end],  left_end,
                           redir_in,  None,
                           None,  Some(pipefd[1] as usize));
            let p2 = spawn(&toks[right_start..ntok], ntok-right_start,
                           None, redir_out,
                           Some(pipefd[0] as usize), None);

            syscall::close(pipefd[0] as usize);
            syscall::close(pipefd[1] as usize);

            if !background {
                let mut st = 0i32;
                if p1 > 0 { syscall::waitpid(p1 as i32, &mut st, 0); }
                if p2 > 0 { syscall::waitpid(p2 as i32, &mut st, 0); exit_code = (st >> 8) & 0xFF; }
            }
        } else {
            let pid = spawn(&toks[..ntok], ntok, redir_in, redir_out, None, None);
            if !background && pid > 0 {
                let mut st = 0i32;
                syscall::waitpid(pid as i32, &mut st, 0);
                exit_code = (st >> 8) & 0xFF;
            }
        }
    }
}

#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
