//! devtest — exercises /dev/null, /dev/zero, /dev/urandom.
#![no_std]
#![no_main]
mod syscall;
mod io;

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // /dev/zero
    let fd = syscall::open(b"/dev/zero\0", 0);
    if fd >= 0 {
        let mut buf = [0xFFu8; 8];
        syscall::read(fd as usize, &mut buf);
        syscall::close(fd as usize);
        io::print(b"/dev/zero: ");
        for b in &buf { io::print_usize(*b as usize); io::print(b" "); }
        io::println(b"");
    }

    // /dev/urandom
    let fd = syscall::open(b"/dev/urandom\0", 0);
    if fd >= 0 {
        let mut buf = [0u8; 8];
        syscall::read(fd as usize, &mut buf);
        syscall::close(fd as usize);
        io::print(b"/dev/urandom: ");
        for b in &buf { io::print_usize(*b as usize); io::print(b" "); }
        io::println(b"");
    }

    // /dev/null write
    let fd = syscall::open(b"/dev/null\0", 1 /*O_WRONLY*/);
    if fd >= 0 {
        let n = syscall::write(fd as usize, b"this goes nowhere");
        syscall::close(fd as usize);
        io::print(b"/dev/null wrote: "); io::print_usize(n as usize); io::println(b" bytes");
    }

    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
