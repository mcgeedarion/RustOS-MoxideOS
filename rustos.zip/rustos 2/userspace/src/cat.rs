//! cat — reads files given as arguments (or stdin) and writes to stdout.
#![no_std]
#![no_main]
mod syscall;
mod io;

const BUF_SIZE: usize = 4096;

fn cat_fd(fd: usize) {
    let mut buf = [0u8; BUF_SIZE];
    loop {
        let n = syscall::read(fd, &mut buf);
        if n <= 0 { break; }
        syscall::write(1, &buf[..n as usize]);
    }
}

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // argv is at [rsp+8], argc at [rsp]; we don't parse argv in no_std easily
    // so we just cat stdin (good enough for pipe usage)
    cat_fd(0);
    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
