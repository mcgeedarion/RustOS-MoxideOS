//! thread_test — exercises clone() + futex() directly (no libc).
//!
//! Spawns 3 threads, each prints its TID, then the main thread joins them
//! using a simple futex-based barrier.
#![no_std]
#![no_main]
mod syscall;
mod io;

const CLONE_VM:      usize = 0x00000100;
const CLONE_FS:      usize = 0x00000200;
const CLONE_FILES:   usize = 0x00000400;
const CLONE_SIGHAND: usize = 0x00000800;
const CLONE_THREAD:  usize = 0x00010000;
const CLONE_SYSVSEM: usize = 0x00040000;
const CLONE_SETTLS:  usize = 0x00080000;
const CLONE_PARENT_SETTID: usize = 0x00100000;
const CLONE_CHILD_CLEARTID:usize = 0x00200000;
const CLONE_CHILD_SETTID:  usize = 0x01000000;

const THREAD_FLAGS: usize = CLONE_VM | CLONE_FS | CLONE_FILES | CLONE_SIGHAND
    | CLONE_THREAD | CLONE_SYSVSEM | CLONE_SETTLS
    | CLONE_PARENT_SETTID | CLONE_CHILD_CLEARTID | CLONE_CHILD_SETTID;

const FUTEX_WAIT: usize = 0;
const FUTEX_WAKE: usize = 1;

// Shared counter: main waits until == NUM_THREADS
static mut DONE: u32 = 0;

// 16 KiB stacks for child threads
static mut STACK1: [u8; 16384] = [0; 16384];
static mut STACK2: [u8; 16384] = [0; 16384];
static mut STACK3: [u8; 16384] = [0; 16384];

unsafe fn spawn_thread(stack: &'static mut [u8; 16384],
                       entry: extern "C" fn() -> !) -> isize
{
    let sp = stack.as_mut_ptr().add(16384) as usize; // top of stack
    // Push entry pointer onto the child stack so _thread_start can call it
    let sp = sp - 8;
    *(sp as *mut usize) = entry as usize;
    unsafe {
        syscall::syscall3(
            56, // SYS_clone
            THREAD_FLAGS,
            sp,
            0, // ptid (ignored)
        )
    }
}

extern "C" fn worker1() -> ! {
    let tid = syscall::getpid();
    io::print(b"thread 1 TID: "); io::print_usize(tid as usize); io::println(b"");
    unsafe {
        // Atomic increment of DONE
        core::arch::asm!("lock xadd [{0}], {1}", in(reg) &raw mut DONE as usize, in(reg) 1u32);
        // Wake main thread
        syscall::syscall3(202, &raw const DONE as usize, FUTEX_WAKE, 3); // FUTEX_WAKE
    }
    syscall::exit(0);
}
extern "C" fn worker2() -> ! {
    let tid = syscall::getpid();
    io::print(b"thread 2 TID: "); io::print_usize(tid as usize); io::println(b"");
    unsafe {
        core::arch::asm!("lock xadd [{0}], {1}", in(reg) &raw mut DONE as usize, in(reg) 1u32);
        syscall::syscall3(202, &raw const DONE as usize, FUTEX_WAKE, 3);
    }
    syscall::exit(0);
}
extern "C" fn worker3() -> ! {
    let tid = syscall::getpid();
    io::print(b"thread 3 TID: "); io::print_usize(tid as usize); io::println(b"");
    unsafe {
        core::arch::asm!("lock xadd [{0}], {1}", in(reg) &raw mut DONE as usize, in(reg) 1u32);
        syscall::syscall3(202, &raw const DONE as usize, FUTEX_WAKE, 3);
    }
    syscall::exit(0);
}

#[no_mangle]
pub extern "C" fn _start() -> ! {
    io::println(b"thread_test: spawning 3 threads");
    unsafe {
        spawn_thread(&mut STACK1, worker1);
        spawn_thread(&mut STACK2, worker2);
        spawn_thread(&mut STACK3, worker3);
        // Wait for all 3 threads via futex
        let mut waited = 0u32;
        while waited < 3 {
            let cur = core::ptr::read_volatile(&DONE);
            if cur >= 3 { break; }
            // FUTEX_WAIT: block while DONE == cur
            syscall::syscall3(202, &raw const DONE as usize, FUTEX_WAIT, cur as usize);
            waited = core::ptr::read_volatile(&DONE);
        }
    }
    io::println(b"thread_test: all threads done");
    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
