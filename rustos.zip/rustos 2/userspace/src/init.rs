//! PID 1 — minimal init process.
//!
//! Responsibilities:
//!   1. Print a banner.
//!   2. Fork + exec /bin/sh as the login shell (with a controlling terminal).
//!   3. Reap any zombie child in a waitpid() loop.
//!   4. If the shell exits, respawn it.
#![no_std]
#![no_main]

mod syscall;
mod io;

#[no_mangle]
pub extern "C" fn _start() -> ! {
    io::println(b"rustos init: PID 1 running");

    loop {
        let pid = syscall::fork();
        if pid == 0 {
            // Child — exec the shell
            let path = b"/bin/sh\0";
            let argv: [*const u8; 2] = [path.as_ptr(), core::ptr::null()];
            let envp: [*const u8; 1] = [core::ptr::null()];
            syscall::execve(path, &argv, &envp);
            // execve failed
            io::println(b"init: exec /bin/sh failed");
            syscall::exit(1);
        } else if pid > 0 {
            // Parent — wait for shell to exit, then respawn
            let mut status: i32 = 0;
            syscall::waitpid(pid as i32, &mut status, 0);
            io::print(b"init: shell exited with status ");
            io::print_usize(((status >> 8) & 0xFF) as usize);
            io::println(b" — respawning");
        } else {
            io::println(b"init: fork failed, halting");
            loop {}
        }
    }
}

#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
