//! Raw syscall wrappers for x86_64 Linux ABI (used by rustos).
//! Calling convention: rax=nr, rdi=a0, rsi=a1, rdx=a2, r10=a3, r8=a4, r9=a5.

#[inline(always)]
pub unsafe fn syscall0(nr: usize) -> isize {
    let ret: isize;
    core::arch::asm!(
        "syscall",
        in("rax") nr,
        out("rax") ret,
        lateout("rcx") _, lateout("r11") _,
        options(nostack),
    );
    ret
}

#[inline(always)]
pub unsafe fn syscall1(nr: usize, a0: usize) -> isize {
    let ret: isize;
    core::arch::asm!(
        "syscall",
        in("rax") nr, in("rdi") a0,
        out("rax") ret,
        lateout("rcx") _, lateout("r11") _,
        options(nostack),
    );
    ret
}

#[inline(always)]
pub unsafe fn syscall2(nr: usize, a0: usize, a1: usize) -> isize {
    let ret: isize;
    core::arch::asm!(
        "syscall",
        in("rax") nr, in("rdi") a0, in("rsi") a1,
        out("rax") ret,
        lateout("rcx") _, lateout("r11") _,
        options(nostack),
    );
    ret
}

#[inline(always)]
pub unsafe fn syscall3(nr: usize, a0: usize, a1: usize, a2: usize) -> isize {
    let ret: isize;
    core::arch::asm!(
        "syscall",
        in("rax") nr, in("rdi") a0, in("rsi") a1, in("rdx") a2,
        out("rax") ret,
        lateout("rcx") _, lateout("r11") _,
        options(nostack),
    );
    ret
}

#[inline(always)]
pub unsafe fn syscall4(nr: usize, a0: usize, a1: usize, a2: usize, a3: usize) -> isize {
    let ret: isize;
    core::arch::asm!(
        "syscall",
        in("rax") nr, in("rdi") a0, in("rsi") a1, in("rdx") a2, in("r10") a3,
        out("rax") ret,
        lateout("rcx") _, lateout("r11") _,
        options(nostack),
    );
    ret
}

// ── Syscall numbers (Linux x86-64 ABI) ───────────────────────────────────
pub const SYS_READ:      usize = 0;
pub const SYS_WRITE:     usize = 1;
pub const SYS_OPEN:      usize = 2;
pub const SYS_CLOSE:     usize = 3;
pub const SYS_FSTAT:     usize = 5;
pub const SYS_LSEEK:     usize = 8;
pub const SYS_MMAP:      usize = 9;
pub const SYS_FORK:      usize = 57;
pub const SYS_EXECVE:    usize = 59;
pub const SYS_EXIT:      usize = 60;
pub const SYS_WAITPID:   usize = 61;
pub const SYS_PIPE:      usize = 22;
pub const SYS_DUP2:      usize = 33;
pub const SYS_GETPID:    usize = 39;
pub const SYS_KILL:      usize = 62;
pub const SYS_OPENAT:    usize = 257;

// ── High-level wrappers ───────────────────────────────────────────────────

pub fn write(fd: usize, buf: &[u8]) -> isize {
    unsafe { syscall3(SYS_WRITE, fd, buf.as_ptr() as usize, buf.len()) }
}

pub fn read(fd: usize, buf: &mut [u8]) -> isize {
    unsafe { syscall3(SYS_READ, fd, buf.as_mut_ptr() as usize, buf.len()) }
}

pub fn open(path: &[u8], flags: usize) -> isize {
    unsafe { syscall2(SYS_OPEN, path.as_ptr() as usize, flags) }
}

pub fn close(fd: usize) -> isize {
    unsafe { syscall1(SYS_CLOSE, fd) }
}

pub fn fork() -> isize {
    unsafe { syscall0(SYS_FORK) }
}

pub fn execve(path: &[u8], argv: &[*const u8], envp: &[*const u8]) -> isize {
    unsafe { syscall3(SYS_EXECVE,
        path.as_ptr() as usize,
        argv.as_ptr() as usize,
        envp.as_ptr() as usize) }
}

pub fn exit(code: i32) -> ! {
    unsafe { syscall1(SYS_EXIT, code as usize); }
    loop {}
}

pub fn waitpid(pid: i32, status: *mut i32, options: usize) -> isize {
    unsafe { syscall3(SYS_WAITPID, pid as usize, status as usize, options) }
}

pub fn pipe(fds: &mut [i32; 2]) -> isize {
    unsafe { syscall1(SYS_PIPE, fds.as_mut_ptr() as usize) }
}

pub fn dup2(old: usize, new: usize) -> isize {
    unsafe { syscall2(SYS_DUP2, old, new) }
}

pub fn getpid() -> isize {
    unsafe { syscall0(SYS_GETPID) }
}
