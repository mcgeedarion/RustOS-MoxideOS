use crate::syscall;

pub fn print(s: &[u8]) { syscall::write(1, s); }
pub fn println(s: &[u8]) { print(s); print(b"\n"); }
pub fn eprint(s: &[u8])  { syscall::write(2, s); }

/// Write a decimal number to stdout.
pub fn print_usize(mut n: usize) {
    let mut buf = [0u8; 20];
    let mut i = 20;
    if n == 0 { print(b"0"); return; }
    while n > 0 {
        i -= 1;
        buf[i] = b'0' + (n % 10) as u8;
        n /= 10;
    }
    print(&buf[i..]);
}

/// Read one line from fd into buf, returns byte count (including newline).
pub fn readline(fd: usize, buf: &mut [u8]) -> usize {
    let mut pos = 0;
    while pos < buf.len() - 1 {
        let mut b = [0u8; 1];
        let n = syscall::read(fd, &mut b);
        if n <= 0 { break; }
        buf[pos] = b[0];
        pos += 1;
        if b[0] == b'\n' { break; }
    }
    buf[pos] = 0;
    pos
}

/// Compare two null-terminated byte slices.
pub fn bytes_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() { return false; }
    a.iter().zip(b.iter()).all(|(x, y)| x == y)
}

/// Find first occurrence of byte in slice, or None.
pub fn memchr(hay: &[u8], needle: u8) -> Option<usize> {
    hay.iter().position(|&b| b == needle)
}
