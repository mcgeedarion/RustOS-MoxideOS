#![no_std]
#![no_main]
mod syscall;
#[no_mangle]
pub extern "C" fn _start() -> ! { syscall::exit(0); }
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
