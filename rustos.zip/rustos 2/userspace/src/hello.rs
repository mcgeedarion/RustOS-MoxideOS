//! Simple hello-world test binary.
#![no_std]
#![no_main]
mod syscall;
mod io;

#[no_mangle]
pub extern "C" fn _start() -> ! {
    io::println(b"Hello from rustos userspace!");
    let pid = syscall::getpid();
    io::print(b"PID: "); io::print_usize(pid as usize); io::println(b"");
    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
