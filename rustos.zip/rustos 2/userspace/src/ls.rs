//! ls — list directory.  For now prints a static stub;
//! full getdents64 support will come with the dentry cache.
#![no_std]
#![no_main]
mod syscall;
mod io;

#[no_mangle]
pub extern "C" fn _start() -> ! {
    io::println(b"bin  dev  etc  proc  tmp");
    syscall::exit(0);
}
#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
