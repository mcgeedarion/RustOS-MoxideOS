#![no_std]
#![no_main]

#[no_mangle]
pub extern "C" fn _start() -> ! {
    // syscall write(1, "Hello\n", 6)
    unsafe {
        core::arch::asm!(
            "li a7, 1",
            "li a0, 1",
            "la a1, msg",
            "li a2, 7",
            "ecall",
            "li a7, 60",
            "li a0, 0",
            "ecall",
        );
    }
    loop {}
}

#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { loop {} }
