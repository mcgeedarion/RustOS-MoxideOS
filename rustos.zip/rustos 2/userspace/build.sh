#!/usr/bin/env bash
# Build all userspace binaries for x86_64-unknown-none.
# Output: userspace/target/x86_64-unknown-none/release/{init,sh,hello,cat,echo,ls}
set -euo pipefail

cd "$(dirname "$0")"

# Ensure rust nightly + target installed
rustup target add x86_64-unknown-none 2>/dev/null || true

cargo build --release --target x86_64-unknown-none

OUT=../disk_root/bin
mkdir -p "$OUT"
for BIN in init sh hello cat echo ls true; do
    SRC="target/x86_64-unknown-none/release/$BIN"
    [ -f "$SRC" ] && cp "$SRC" "$OUT/$BIN" && echo "Installed $OUT/$BIN"
done

echo "Done. Run: bash tools/mkdisk.sh to rebuild disk image."
