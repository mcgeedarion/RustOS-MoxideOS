/* hello_c.c — dynamically linked musl C binary for RustOS
 *
 * Build:
 *   musl-gcc -o hello_c hello_c.c
 *   # OR statically:
 *   musl-gcc -static -o hello_static hello_c.c
 *
 * Install:
 *   cp hello_c    disk_root/bin/
 *   cp hello_static disk_root/bin/
 *   # For dynamic: also copy the musl dynamic linker
 *   cp /lib/x86_64-linux-musl/ld-musl-x86_64.so.1 disk_root/lib/
 *   cp /lib/x86_64-linux-musl/libc.so disk_root/lib/
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

static void *thread_fn(void *arg) {
    printf("Hello from thread %ld (TID=%d)\n", (long)arg, (int)getpid());
    return NULL;
}

int main(int argc, char **argv) {
    printf("=== RustOS dynamic libc test ===\n");
    printf("argc=%d  argv[0]=%s\n", argc, argv[0]);

    /* heap */
    char *buf = malloc(64);
    strcpy(buf, "heap-allocated string");
    printf("malloc: %s\n", buf);
    free(buf);

    /* threads */
    pthread_t t1, t2;
    pthread_create(&t1, NULL, thread_fn, (void*)1);
    pthread_create(&t2, NULL, thread_fn, (void*)2);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    /* file I/O */
    FILE *f = fopen("/tmp/test.txt", "w");
    if (f) { fprintf(f, "written by hello_c\n"); fclose(f); }
    f = fopen("/tmp/test.txt", "r");
    if (f) { char line[64]; fgets(line, sizeof(line), f); printf("read back: %s", line); fclose(f); }

    printf("=== done ===\n");
    return 0;
}
